#!/usr/bin/env node
/**
 * YouTube Scraper - TranscriptAPI v2 REST method
 * Base: https://transcriptapi.com/api/v2
 * No Groq. No proxy. 300 req/min limit. 1 credit per transcript.
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = '/home/himel/.openclaw/workspace/skills/youtube-full';
const QUEUE_FILE = join(BASE, 'bundle-queue.json');
const CHECKPOINT_FILE = join(BASE, 'scraper-checkpoint.json');
const RESULTS_DIR = join(BASE, 'results');

const TAPI_KEY = process.env.TAPI_KEY || process.env.TRANSCRIPTAPI_APIKEY || 'sk_bNIPR0IwmNsItiTDYi1e0EvOdjlrXxygZwVATVMQoso';
const TAPI_BASE = process.env.TAPI_BASE || 'https://api.transcriptapi.com';

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

const RETRYABLE_STATUS = new Set([408, 429, 503]);
const NON_RETRYABLE_STATUS = new Set([401, 402, 404, 422]);

function loadCheckpoint() {
  if (existsSync(CHECKPOINT_FILE)) {
    return JSON.parse(readFileSync(CHECKPOINT_FILE, 'utf8'));
  }
  return {};
}

function saveCheckpoint(cp) {
  writeFileSync(CHECKPOINT_FILE, JSON.stringify(cp, null, 2));
}

async function fetchTranscript(videoInput, maxRetries = 2) {
  const params = new URLSearchParams({
    video_url: videoInput,
    format: 'text',
    include_timestamp: 'false',
    send_metadata: 'true'
  });

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const res = await fetch(`${TAPI_BASE}/transcript?${params}`, {
      headers: { 'Authorization': `Bearer ${TAPI_KEY}` }
    });

    if (res.ok) {
      const raw = await res.text();
      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      const maybeJson = raw.trim();

      if (contentType.includes('application/json') || maybeJson.startsWith('{') || maybeJson.startsWith('[')) {
        return JSON.parse(raw);
      }

      return {
        transcript: raw,
        metadata: {}
      };
    }

    const body = await res.text();
    const detail = body.slice(0, 200);

    if (NON_RETRYABLE_STATUS.has(res.status) || !RETRYABLE_STATUS.has(res.status) || attempt === maxRetries) {
      throw new Error(`TAPI ${res.status}: ${detail}`);
    }

    const retryAfter = Number(res.headers.get('retry-after'));
    const backoffMs = res.status === 429 && Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : Math.min(5000, 1000 * Math.pow(2, attempt));

    await sleep(backoffMs);
  }

  throw new Error('TAPI retry loop exited unexpectedly');
}

async function main() {
  const queue = JSON.parse(readFileSync(QUEUE_FILE, 'utf8'));
  const checkpoint = loadCheckpoint();

  const pending = queue.filter(v => checkpoint[v.videoId] !== 'success');
  console.log(`Queue: ${queue.length} | Done: ${queue.length - pending.length} | Remaining: ${pending.length}`);

  let successCount = 0;
  let failCount = 0;

  for (const video of pending) {
    const { videoId, title } = video;
    console.log(`\n[${videoId}] ${title}`);

    try {
      const data = await fetchTranscript(videoId);
      const transcript = typeof data.transcript === 'string'
        ? data.transcript
        : JSON.stringify(data.transcript);

      if (!transcript || transcript.length < 50) {
        throw new Error('Empty transcript');
      }

      const result = {
        videoId,
        title: data.metadata?.title || title,
        author: data.metadata?.author_name || '',
        url: `https://youtube.com/watch?v=${videoId}`,
        transcript,
        charCount: transcript.length,
        fetchedAt: new Date().toISOString(),
        method: 'transcriptapi-v2-rest'
      };

      writeFileSync(join(RESULTS_DIR, `${videoId}.json`), JSON.stringify(result, null, 2));
      checkpoint[videoId] = 'success';
      saveCheckpoint(checkpoint);

      console.log(`  OK ${transcript.length} chars | ${result.title}`);
      successCount++;

    } catch (err) {
      console.log(`  FAIL ${err.message}`);
      checkpoint[videoId] = `failed: ${err.message}`;
      saveCheckpoint(checkpoint);
      failCount++;
    }

    await sleep(250); // 250ms = ~240 req/min, well under 300/min limit
  }

  console.log(`\n=== DONE: ${successCount} success, ${failCount} failed ===`);
  const totalDone = queue.filter(v => checkpoint[v.videoId] === 'success').length;
  console.log(`Total: ${totalDone}/${queue.length}`);
}

main().catch(console.error);
