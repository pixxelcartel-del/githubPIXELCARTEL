#!/usr/bin/env node
import { writeFileSync } from 'fs';
import { join } from 'path';

const videoInput = process.argv[2];
if (!videoInput) {
  console.error('Usage: node fetch_single_tapi.mjs <video_url_or_id>');
  process.exit(1);
}

const videoId = videoInput.includes('http')
  ? (videoInput.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_-]{11})/) || [])[1]
  : videoInput;

if (!videoId) {
  console.error('Could not determine video id');
  process.exit(1);
}

const TAPI_KEY = process.env.TAPI_KEY || process.env.TRANSCRIPTAPI_APIKEY;
const TAPI_BASE = process.env.TAPI_BASE || 'https://api.transcriptapi.com';
if (!TAPI_KEY) {
  console.error('Missing TAPI_KEY or TRANSCRIPTAPI_APIKEY');
  process.exit(1);
}

const params = new URLSearchParams({
  video_url: `https://youtube.com/watch?v=${videoId}`,
  format: 'text',
  include_timestamp: 'false',
  send_metadata: 'true'
});

const res = await fetch(`${TAPI_BASE}/transcript?${params}`, {
  headers: { Authorization: `Bearer ${TAPI_KEY}` }
});

const raw = await res.text();
if (!res.ok) {
  console.error(`FAIL ${res.status}: ${raw.slice(0, 400)}`);
  process.exit(2);
}

let data;
try {
  data = JSON.parse(raw);
} catch {
  data = { transcript: raw, metadata: {} };
}

const transcript = typeof data.transcript === 'string' ? data.transcript : JSON.stringify(data.transcript);
const result = {
  videoId,
  title: data.metadata?.title || '',
  author: data.metadata?.author_name || '',
  url: `https://youtube.com/watch?v=${videoId}`,
  transcript,
  charCount: transcript.length,
  fetchedAt: new Date().toISOString(),
  method: 'transcriptapi-single-fetch'
};

const out = join('/home/himel/.openclaw/workspace/skills/youtube-full/results', `${videoId}.json`);
writeFileSync(out, JSON.stringify(result, null, 2));
console.log(JSON.stringify({ ok: true, output: out, charCount: transcript.length, title: result.title }, null, 2));
