import fs from 'fs';
import path from 'path';

// Define Paths
const WORKSPACE = '/home/himel/.openclaw/workspace/skills/youtube-full';
const QUEUE_FILE = path.join(WORKSPACE, 'bundle-queue.json');
const CHECKPOINT_FILE = path.join(WORKSPACE, 'scraper-checkpoint.json');
const RESULTS_DIR = path.join(WORKSPACE, 'results');
const OPENCLAW_JSON = '/home/himel/.openclaw/openclaw.json';

// Ensure results dir
if (!fs.existsSync(RESULTS_DIR)) {
  fs.mkdirSync(RESULTS_DIR, { recursive: true });
}

// Read Config
let config;
try {
  config = JSON.parse(fs.readFileSync(OPENCLAW_JSON, 'utf8'));
} catch (e) {
  console.error("Failed to read openclaw.json. Ensure it exists.");
  process.exit(1);
}

const TRANSCRIPT_API_KEY = config.skills?.entries?.transcriptapi?.apiKey;
const GROQ_API_KEY = config.env?.GROQ_API_KEY;

if (!TRANSCRIPT_API_KEY || !GROQ_API_KEY) {
  console.error("Missing TranscriptAPI or Groq API keys in openclaw.json");
  process.exit(1);
}

// Load Checkpoint
let checkpoint = {};
if (fs.existsSync(CHECKPOINT_FILE)) {
  try {
    checkpoint = JSON.parse(fs.readFileSync(CHECKPOINT_FILE, 'utf8'));
  } catch(e) { /* ignore */ }
}

function saveCheckpoint() {
  fs.writeFileSync(CHECKPOINT_FILE, JSON.stringify(checkpoint, null, 2));
}

// Load Queue
let queue = [];
if (fs.existsSync(QUEUE_FILE)) {
  queue = JSON.parse(fs.readFileSync(QUEUE_FILE, 'utf8'));
} else {
  console.error("No bundle-queue.json found. Please create it with { videoId, title, bundle, priority } objects.");
  process.exit(1);
}

async function fetchTranscript(videoId) {
  console.log(`[+] Fetching transcript for ${videoId} via TranscriptAPI...`);
  const url = `https://transcriptapi.com/api/v2/youtube/transcript?video_url=${videoId}&format=text&include_timestamp=false&send_metadata=false`;
  
  try {
    const res = await fetch(url, {
      headers: { "Authorization": `Bearer ${TRANSCRIPT_API_KEY}` }
    });
    
    if (!res.ok) {
      console.warn(`[-] API failed for ${videoId}: ${res.status} ${res.statusText}`);
      return null;
    }
    const data = await res.json();
    if (data && data.transcript) {
      if (typeof data.transcript === 'string') {
        return data.transcript;
      } else if (Array.isArray(data.transcript)) {
        return data.transcript.map(t => t.text).join(" ");
      }
    }
    return null;
  } catch (error) {
    console.error(`[-] Network error for fetchTranscript: ${error.message}`);
    return null;
  }
}

async function runQDE(transcript, title) {
  console.log(`[+] Running QDE via Groq (llama-3.3-70b-versatile) for "${title}"...`);
  
  const systemPrompt = `You are the Quality Detection Engine (QDE) for the PixC intelligence stack.
Analyze the following YouTube video transcript and extract intelligence ONLY fitting into these exactly 8 categories:
1. Techniques & Tactics
2. Platforms & Toolchains
3. Pricing & Budgets
4. Free Resources & Assets
5. Workflows & Automations
6. Quality Frameworks
7. Market Insights
8. Comparisons & Debates

Return ONLY a strict JSON object mapping these 8 keys to arrays of strings. No markdown fencing, no conversational text.`;

  const body = {
    model: "llama-3.3-70b-versatile",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Title: ${title}\n\nTranscript: ${transcript.substring(0, 20000)}` }
    ],
    temperature: 0.2,
    response_format: { type: "json_object" }
  };

  try {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });
    
    if (!res.ok) {
      console.error(`[-] Groq API failed: ${res.status} ${res.statusText}`);
      return null;
    }
    
    const data = await res.json();
    let content = data.choices[0].message.content;
    
    // Strip markdown fences just in case
    content = content.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    return JSON.parse(content);
  } catch (err) {
    console.error(`[-] Error in Groq QDE: ${err.message}`);
    return null;
  }
}

async function runScraper() {
  console.log(`=== Luna Scraping Pipeline (Phase 1B) ===`);
  console.log(`Loaded Queue: ${queue.length} videos`);
  console.log(`Existing Checkpoints: ${Object.keys(checkpoint).length} videos`);
  
  // Sort queue by priority: A -> M (assuming bundle key exists)
  queue.sort((a, b) => {
    if ((a.bundle || "Z") < (b.bundle || "Z")) return -1;
    if ((a.bundle || "Z") > (b.bundle || "Z")) return 1;
    return 0;
  });

  for (const video of queue) {
    const { videoId, title, bundle } = video;
    
    if (!videoId) continue;
    
    // 1. Deduplication Check
    if (checkpoint[videoId]) {
      console.log(`[SKIP] Video ${videoId} already processed (${checkpoint[videoId]}).`);
      continue;
    }
    
    console.log(`\n>>> Processing [Bundle ${bundle || 'Unknown'}] ${videoId} : ${title}`);
    
    // 2. No-Retry fetch transcript
    const transcriptText = await fetchTranscript(videoId);
    
    if (!transcriptText) {
      // Mark as failed so we don't try again and burn credits accidentally
      checkpoint[videoId] = 'failed_transcript';
      saveCheckpoint();
      continue;
    }
    
    // 3. Expanded QDE Extraction
    const qdeResult = await runQDE(transcriptText, title);
    
    if (!qdeResult) {
      checkpoint[videoId] = 'failed_qde';
      saveCheckpoint();
      continue;
    }
    
    // 4. Save Output Data
    const resultPayload = {
      videoId,
      title,
      bundle,
      extractedAt: new Date().toISOString(),
      intelligence: qdeResult
    };
    
    const outPath = path.join(RESULTS_DIR, `${videoId}.json`);
    fs.writeFileSync(outPath, JSON.stringify(resultPayload, null, 2));
    
    // 5. Checkpoint & Resume Save
    checkpoint[videoId] = 'success';
    saveCheckpoint();
    
    console.log(`[SUCCESS] Data saved for ${videoId}`);
    
    // Polite delay for safety (TranscriptAPI limit is 300/min, Groq has varying RPM)
    await new Promise(r => setTimeout(r, 2000));
  }
  
  console.log(`\n=== Scraping Pipeline Completed ===`);
}

runScraper();
