import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { SocksProxyAgent } from 'socks-proxy-agent';
import https from 'https';

const require = createRequire(import.meta.url);

const WORKSPACE = '/home/himel/.openclaw/workspace/skills/youtube-full';
const QUEUE_FILE = path.join(WORKSPACE, 'bundle-queue.json');
const CHECKPOINT_FILE = path.join(WORKSPACE, 'scraper-checkpoint.json');
const RESULTS_DIR = path.join(WORKSPACE, 'results');
const OPENCLAW_JSON = '/home/himel/.openclaw/openclaw.json';

if (!fs.existsSync(RESULTS_DIR)) fs.mkdirSync(RESULTS_DIR, { recursive: true });

const config = JSON.parse(fs.readFileSync(OPENCLAW_JSON, 'utf8'));
const TRANSCRIPT_API_KEY = config.skills?.entries?.transcriptapi?.apiKey;
const GROQ_API_KEY = config.env?.GROQ_API_KEY;

if (!TRANSCRIPT_API_KEY || !GROQ_API_KEY) {
  console.error("Missing TranscriptAPI or Groq keys"); process.exit(1);
}

// SOCKS5 proxy agent via reverse tunnel (Windows PC -> port 1080 on VPS)
const proxyAgent = new SocksProxyAgent('socks5://127.0.0.1:1080');

let checkpoint = {};
if (fs.existsSync(CHECKPOINT_FILE)) {
  try { checkpoint = JSON.parse(fs.readFileSync(CHECKPOINT_FILE, 'utf8')); } catch(e) {}
}
function saveCheckpoint() { fs.writeFileSync(CHECKPOINT_FILE, JSON.stringify(checkpoint, null, 2)); }

const queue = JSON.parse(fs.readFileSync(QUEUE_FILE, 'utf8'));

async function fetchWithProxy(url, options = {}) {
  const { default: nodeFetch } = await import('node-fetch');
  return nodeFetch(url, { ...options, agent: proxyAgent });
}

async function fetchTranscript(videoId) {
  const url = `https://transcriptapi.com/api/v2/youtube/transcript?video_url=${videoId}&format=text&include_timestamp=false&send_metadata=false`;
  try {
    const res = await fetchWithProxy(url, {
      headers: { "Authorization": `Bearer ${TRANSCRIPT_API_KEY}` }
    });
    if (!res.ok) { console.warn(`  transcript ${res.status} for ${videoId}`); return null; }
    const data = await res.json();
    if (!data?.transcript) return null;
    return typeof data.transcript === 'string' ? data.transcript
      : Array.isArray(data.transcript) ? data.transcript.map(t => t.text).join(' ') : null;
  } catch(e) { console.error(`  transcript fetch error: ${e.message}`); return null; }
}

async function runQDE(transcript, title) {
  const systemPrompt = `You are the Quality Detection Engine (QDE) for the PixC intelligence stack.
Analyze the transcript and extract intelligence into these 8 categories:
1. Techniques & Tactics
2. Platforms & Toolchains
3. Pricing & Budgets
4. Free Resources & Assets
5. Workflows & Automations
6. Quality Frameworks
7. Market Insights
8. Comparisons & Debates
Return ONLY a strict JSON object. No markdown, no extra text.`;

  const body = {
    model: "llama-3.3-70b-versatile",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Title: ${title}\n\nTranscript: ${transcript.substring(0, 20000)}` }
    ],
    temperature: 0.2,
    response_format: { type: "json_object" }
  };

  try {
    // Groq is NOT blocked — call directly without proxy
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: "POST",
      headers: { "Authorization": `Bearer ${GROQ_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) { console.error(`  Groq ${res.status}`); return null; }
    const data = await res.json();
    let content = data.choices[0].message.content.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    return JSON.parse(content);
  } catch(e) { console.error(`  QDE error: ${e.message}`); return null; }
}

async function runScraper() {
  console.log(`\n=== Luna Phase 1B Scraper (with proxy) ===`);
  console.log(`Queue: ${queue.length} videos | Checkpointed: ${Object.keys(checkpoint).length}`);

  queue.sort((a, b) => (a.priority || 3) - (b.priority || 3));

  for (const video of queue) {
    const { videoId, title } = video;
    if (!videoId) continue;
    if (checkpoint[videoId] === 'success') {
      console.log(`[SKIP] ${videoId} already done`);
      continue;
    }

    console.log(`\n[${videoId}] ${title?.substring(0,55)}`);

    const transcript = await fetchTranscript(videoId);
    if (!transcript) {
      checkpoint[videoId] = 'failed_transcript';
      saveCheckpoint();
      continue;
    }
    console.log(`  transcript: ${transcript.length} chars`);

    const qde = await runQDE(transcript, title);
    if (!qde) {
      checkpoint[videoId] = 'failed_qde';
      saveCheckpoint();
      continue;
    }

    const payload = { videoId, title, extractedAt: new Date().toISOString(), intelligence: qde };
    fs.writeFileSync(path.join(RESULTS_DIR, `${videoId}.json`), JSON.stringify(payload, null, 2));
    checkpoint[videoId] = 'success';
    saveCheckpoint();
    console.log(`  [OK] saved`);

    await new Promise(r => setTimeout(r, 1500));
  }

  const success = Object.values(checkpoint).filter(v => v === 'success').length;
  console.log(`\n=== Done: ${success}/${queue.length} successful ===`);
}

runScraper();
