#!/usr/bin/env node
/**
 * Phase 1B Scraper — TranscriptAPI REST + QDE scoring
 * Fetches transcripts, runs QDE analysis, saves to results/ and Supabase
 */
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = '/home/himel/.openclaw/workspace/skills/youtube-full';
const MEM  = '/home/himel/.openclaw/workspace/memory/pixc';
const RESULTS_DIR = join(BASE, 'results');
const QUEUE_FILE  = join(BASE, 'bundle-queue.json');
const CHECKPOINT  = join(BASE, 'scraper-checkpoint.json');

mkdirSync(RESULTS_DIR, { recursive: true });

// Load config from openclaw.json
const cfg = JSON.parse(readFileSync('/home/himel/.openclaw/openclaw.json', 'utf8'));
const env = cfg.env;
const TAPI_KEY    = env.TAPI_KEY;
const SUPABASE_URL = env.SUPABASE_URL;
const SUPABASE_KEY = env.SUPABASE_SERVICE_ROLE_KEY;
const OPENROUTER_KEY = env.OPENROUTER_API_KEY;

// Load QDE configs
const QDE_PROMPT    = JSON.parse(readFileSync(join(MEM, 'qde-prompt.json'), 'utf8'));
const RED_FLAGS     = JSON.parse(readFileSync(join(MEM, 'qde-red-flags.json'), 'utf8'));
const GOLD_SIGNALS  = JSON.parse(readFileSync(join(MEM, 'qde-gold-signals.json'), 'utf8'));

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function loadCheckpoint() {
  return existsSync(CHECKPOINT) ? JSON.parse(readFileSync(CHECKPOINT, 'utf8')) : {};
}
function saveCheckpoint(cp) { writeFileSync(CHECKPOINT, JSON.stringify(cp, null, 2)); }

async function fetchTranscript(videoId) {
  const params = new URLSearchParams({
    video_url: videoId, format: 'text',
    include_timestamp: 'false', send_metadata: 'true'
  });
  const r = await fetch(`https://transcriptapi.com/api/v2/youtube/transcript?${params}`, {
    headers: { Authorization: `Bearer ${TAPI_KEY}` }
  });
  if (!r.ok) throw new Error(`TAPI ${r.status}: ${(await r.text()).slice(0, 150)}`);
  return r.json();
}

async function runQDE(transcript, title, videoId) {
  const systemPrompt = QDE_PROMPT.system || QDE_PROMPT.prompt || JSON.stringify(QDE_PROMPT);
  const redFlagsList = Object.entries(RED_FLAGS.flags || RED_FLAGS)
    .map(([k,v]) => `- ${k}: ${typeof v === 'string' ? v : v.description || ''}`)
    .join('\n');
  const goldList = Object.entries(GOLD_SIGNALS.signals || GOLD_SIGNALS)
    .map(([k,v]) => `- ${k}: ${typeof v === 'string' ? v : v.description || ''}`)
    .join('\n');

  const userPrompt = `VIDEO: "${title}" (${videoId})

TRANSCRIPT (first 4000 chars):
${transcript.slice(0, 4000)}

RED FLAGS TO CHECK:
${redFlagsList}

GOLD SIGNALS TO CHECK:
${goldList}

Respond with ONLY valid JSON:
{
  "qde_score": <0-100>,
  "verdict": "HIGH_VALUE" | "MEDIUM_VALUE" | "LOW_VALUE" | "SKIP",
  "red_flags_found": [],
  "gold_signals_found": [],
  "key_techniques": [],
  "summary": "<2 sentence summary>",
  "worth_storing": <true|false>
}`;

  const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${OPENROUTER_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'anthropic/claude-haiku-4-5-20251001',
      max_tokens: 600,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ]
    })
  });

  if (!r.ok) throw new Error(`QDE API ${r.status}`);
  const data = await r.json();
  const raw = data.choices?.[0]?.message?.content || '{}';
  try {
    return JSON.parse(raw.replace(/```json|```/g, '').trim());
  } catch {
    return { qde_score: 0, verdict: 'SKIP', worth_storing: false, summary: 'Parse error' };
  }
}

async function saveToSupabase(record) {
  if (!SUPABASE_URL || SUPABASE_URL.startsWith('${')) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/scraping_runs`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal'
      },
      body: JSON.stringify(record)
    });
  } catch (e) {
    console.log(`  Supabase save failed: ${e.message}`);
  }
}

async function main() {
  const queue = JSON.parse(readFileSync(QUEUE_FILE, 'utf8'));
  const cp = loadCheckpoint();
  const pending = queue.filter(v => cp[v.videoId] !== 'success');

  console.log(`Queue: ${queue.length} | Done: ${queue.length - pending.length} | Remaining: ${pending.length}`);
  console.log(`TAPI key: ${TAPI_KEY ? TAPI_KEY.slice(0,8)+'...' : 'MISSING'}`);
  console.log(`OpenRouter: ${OPENROUTER_KEY ? 'OK' : 'MISSING'}\n`);

  let success = 0, skipped = 0, failed = 0;

  for (const video of pending) {
    const { videoId, title } = video;
    console.log(`[${videoId}] ${title.slice(0, 60)}`);

    try {
      // 1. Fetch transcript
      const data = await fetchTranscript(videoId);
      const transcript = typeof data.transcript === 'string'
        ? data.transcript : JSON.stringify(data.transcript);

      if (!transcript || transcript.length < 100) throw new Error('Empty transcript');
      console.log(`  transcript: ${transcript.length} chars`);

      // 2. QDE scoring
      let qde = { qde_score: 50, verdict: 'MEDIUM_VALUE', worth_storing: true, summary: '' };
      try {
        qde = await runQDE(transcript, title, videoId);
        console.log(`  QDE: ${qde.verdict} (${qde.qde_score}) | ${qde.summary?.slice(0,80)}`);
      } catch (e) {
        console.log(`  QDE failed (using defaults): ${e.message}`);
      }

      // 3. Save result file
      const result = {
        videoId, title: data.metadata?.title || title,
        author: data.metadata?.author_name || '',
        url: `https://youtube.com/watch?v=${videoId}`,
        transcript, charCount: transcript.length,
        qde_score: qde.qde_score,
        verdict: qde.verdict,
        red_flags: qde.red_flags_found || [],
        gold_signals: qde.gold_signals_found || [],
        key_techniques: qde.key_techniques || [],
        summary: qde.summary || '',
        worth_storing: qde.worth_storing,
        fetchedAt: new Date().toISOString(),
        method: 'transcriptapi-v2-qde'
      };
      writeFileSync(join(RESULTS_DIR, `${videoId}.json`), JSON.stringify(result, null, 2));

      // 4. Save to Supabase (only high/medium value)
      if (qde.worth_storing) {
        await saveToSupabase({
          video_id: videoId, title: result.title,
          channel: result.author, transcript_chars: transcript.length,
          qde_score: qde.qde_score, verdict: qde.verdict,
          summary: qde.summary, key_techniques: qde.key_techniques,
          scraped_at: result.fetchedAt
        });
      }

      cp[videoId] = 'success';
      saveCheckpoint(cp);
      success++;

    } catch (err) {
      console.log(`  FAIL: ${err.message}`);
      cp[videoId] = `failed: ${err.message}`;
      saveCheckpoint(cp);
      failed++;
    }

    await sleep(400); // ~150 req/min, well under TAPI 300/min limit
  }

  const totalDone = Object.values(cp).filter(v => v === 'success').length;
  console.log(`\n=== DONE: ${success} success | ${failed} failed | ${skipped} skipped ===`);
  console.log(`Total: ${totalDone}/48`);
}

main().catch(console.error);
