#!/usr/bin/env node
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';

const WORKSPACE = '/home/himel/.openclaw/workspace';
const BASE = join(WORKSPACE, 'skills/youtube-full');
const RESULTS_DIR = join(BASE, 'results');
const PACKS_DIR = join(WORKSPACE, 'research');
mkdirSync(RESULTS_DIR, { recursive: true });
mkdirSync(PACKS_DIR, { recursive: true });

const cfg = JSON.parse(readFileSync('/home/himel/.openclaw/openclaw.json', 'utf8'));
const TAPI_KEY = process.env.TAPI_KEY || cfg.env?.TAPI_KEY || cfg.skills?.entries?.transcriptapi?.apiKey;
const TAPI_BASE = 'https://transcriptapi.com/api/v2';
const TARGETS = [
  'https://youtu.be/6t32nPxeJb8?si=ggwBwgSU2gLNl4Fb',
  'https://youtu.be/bUt1WpDlI6E?si=peB_ke759s5J3-DZ',
  'https://youtu.be/wGtOMkoi35s?si=mNhT69VqPFF2_xW1',
  'https://youtu.be/h6TLo5u_fME?si=HW0UbrPBKW4Z6e4c',
  'https://youtu.be/K0j_ADBkN9I?si=0eSMMK3FS1dJFQZq',
  'https://youtu.be/vXylQqxsGX0?si=npFo-ZA3WjShuprQ',
  'https://youtu.be/n3o8MgaNRE4?si=QLG-7FWg_6wJ-OJh'
];
const RETRYABLE_STATUS = new Set([408, 429, 503]);
const NON_RETRYABLE_STATUS = new Set([401, 402, 404, 422]);

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function nowStamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }
function extractVideoId(input) {
  if (/^[A-Za-z0-9_-]{11}$/.test(input)) return input;
  try {
    const u = new URL(input);
    const v = u.searchParams.get('v');
    if (v && /^[A-Za-z0-9_-]{11}$/.test(v)) return v;
    const seg = u.pathname.split('/').filter(Boolean).pop();
    if (seg && /^[A-Za-z0-9_-]{11}$/.test(seg)) return seg;
  } catch {}
  throw new Error(`Unrecognized YouTube input: ${input}`);
}

async function fetchTranscript(videoUrl, maxRetries = 2) {
  const params = new URLSearchParams({
    video_url: videoUrl,
    format: 'text',
    include_timestamp: 'false',
    send_metadata: 'true'
  });

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const res = await fetch(`${TAPI_BASE}/youtube/transcript?${params}`, {
      headers: { Authorization: `Bearer ${TAPI_KEY}` }
    });

    const raw = await res.text();
    if (res.ok) {
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      const trimmed = raw.trim();
      let parsed;
      if (ct.includes('application/json') || trimmed.startsWith('{') || trimmed.startsWith('[')) {
        parsed = JSON.parse(raw);
      } else {
        parsed = { transcript: raw, metadata: {} };
      }
      return {
        ok: true,
        status: res.status,
        headers: Object.fromEntries(res.headers.entries()),
        data: parsed
      };
    }

    if (NON_RETRYABLE_STATUS.has(res.status) || !RETRYABLE_STATUS.has(res.status) || attempt === maxRetries) {
      return {
        ok: false,
        status: res.status,
        headers: Object.fromEntries(res.headers.entries()),
        error: raw.slice(0, 500)
      };
    }

    const retryAfter = Number(res.headers.get('retry-after'));
    const backoffMs = res.status === 429 && Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : Math.min(5000, 1000 * Math.pow(2, attempt));
    await sleep(backoffMs);
  }
}

async function main() {
  if (!TAPI_KEY) throw new Error('Missing TAPI_KEY');

  const packId = `youtube_qde_pack_${nowStamp()}_tapi_docfix`;
  const packDir = join(PACKS_DIR, packId);
  mkdirSync(packDir, { recursive: true });

  const summary = {
    created_utc: new Date().toISOString(),
    task: 'TranscriptAPI-only rerun after doc-contract fix',
    pack_dir: packDir,
    contract: {
      endpoint: 'https://transcriptapi.com/api/v2/youtube/transcript',
      auth: 'Authorization: Bearer <api_key>',
      accepted_video_url_forms: ['full URL', 'short URL', 'bare 11-char video ID'],
      retryable_statuses: [408, 429, 503],
      non_retryable_statuses: [401, 402, 404, 422],
      failed_requests_cost_credits: 0
    },
    videos: [],
    succeeded: [],
    failed: []
  };

  for (const originalUrl of TARGETS) {
    const videoId = extractVideoId(originalUrl);
    const result = await fetchTranscript(originalUrl, 2);

    if (result.ok) {
      const transcript = typeof result.data.transcript === 'string'
        ? result.data.transcript
        : JSON.stringify(result.data.transcript);
      const record = {
        videoId,
        title: result.data.metadata?.title || '',
        author: result.data.metadata?.author_name || '',
        url: `https://youtube.com/watch?v=${videoId}`,
        source_input: originalUrl,
        transcript,
        charCount: transcript.length,
        fetchedAt: new Date().toISOString(),
        method: 'transcriptapi-v2-rest-docfix',
        headers: {
          'x-cache-status': result.headers['x-cache-status'] || null,
          'x-ratelimit-limit': result.headers['x-ratelimit-limit'] || null,
          'x-ratelimit-remaining': result.headers['x-ratelimit-remaining'] || null,
          'x-ratelimit-reset': result.headers['x-ratelimit-reset'] || null
        }
      };
      writeFileSync(join(RESULTS_DIR, `${videoId}.json`), JSON.stringify(record, null, 2));
      writeFileSync(join(packDir, `${videoId}.json`), JSON.stringify(record, null, 2));
      summary.videos.push({ id: videoId, status: 'success', title: record.title, author: record.author, charCount: record.charCount, artifact_source: join(packDir, `${videoId}.json`) });
      summary.succeeded.push(videoId);
    } else {
      const failure = {
        id: videoId,
        status: result.status,
        url: originalUrl,
        error: result.error,
        retryable: RETRYABLE_STATUS.has(result.status)
      };
      writeFileSync(join(packDir, `${videoId}.error.json`), JSON.stringify(failure, null, 2));
      summary.videos.push(failure);
      summary.failed.push(failure);
    }

    await sleep(250);
  }

  const md = [
    '# TranscriptAPI rerun pack',
    '',
    `Created: ${summary.created_utc}`,
    `Pack dir: ${packDir}`,
    '',
    `Succeeded: ${summary.succeeded.length}`,
    `Failed: ${summary.failed.length}`,
    '',
    '## Results',
    '',
    ...summary.videos.map(v => v.status === 'success'
      ? `- SUCCESS ${v.id} | ${v.title || '(title unavailable)'} | ${v.charCount} chars | ${v.artifact_source}`
      : `- FAIL ${v.id} | HTTP ${v.status} | retryable=${v.retryable} | ${v.error}`)
  ].join('\n');

  writeFileSync(join(packDir, 'pack-summary.json'), JSON.stringify(summary, null, 2));
  writeFileSync(join(packDir, 'pack-summary.md'), md);

  console.log(JSON.stringify({ packDir, succeeded: summary.succeeded, failed: summary.failed }, null, 2));
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
