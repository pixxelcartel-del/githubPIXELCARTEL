#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-$(pwd)}"
INDEX_HTML="$ROOT_DIR/index.html"
OUT_FILE="$ROOT_DIR/bundle.html"

if [[ ! -f "$INDEX_HTML" ]]; then
  echo "missing index.html in $ROOT_DIR" >&2
  exit 1
fi

python3 - "$INDEX_HTML" "$OUT_FILE" <<'PY'
from pathlib import Path
import sys

index_path = Path(sys.argv[1]).resolve()
out_path = Path(sys.argv[2]).resolve()
html = index_path.read_text(encoding="utf-8", errors="replace")
out_path.write_text(html, encoding="utf-8")
print(f"wrote {out_path}")
PY
