#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "usage: $0 <project-name>" >&2
  exit 1
fi

PROJECT_NAME="$1"
TARGET_DIR="$(pwd)/$PROJECT_NAME"

if [[ -e "$TARGET_DIR" ]]; then
  echo "target already exists: $TARGET_DIR" >&2
  exit 1
fi

mkdir -p "$TARGET_DIR/src"

cat >"$TARGET_DIR/package.json" <<JSON
{
  "name": "$PROJECT_NAME",
  "private": true,
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "typescript": "^5.6.3",
    "vite": "^5.4.8"
  }
}
JSON

cat >"$TARGET_DIR/tsconfig.json" <<'EOF_TS'
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "allowJs": false,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "module": "ESNext",
    "moduleResolution": "Node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx"
  },
  "include": ["src"]
}
EOF_TS

cat >"$TARGET_DIR/index.html" <<'EOF_HTML'
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Artifact</title>
    <style>
      :root {
        color-scheme: light;
        font-family: "Segoe UI", sans-serif;
        background: linear-gradient(135deg, #f3efe6, #dfe8f4);
        color: #1e2430;
      }
      body {
        margin: 0;
        min-height: 100vh;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
EOF_HTML

cat >"$TARGET_DIR/src/App.tsx" <<'EOF_APP'
export default function App() {
  return (
    <main style={{ padding: "48px 24px" }}>
      <p style={{ letterSpacing: "0.24em", textTransform: "uppercase", marginBottom: 12 }}>
        Luna Artifact
      </p>
      <h1 style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)", margin: 0 }}>
        Artifact scaffold repaired during VPS cutover
      </h1>
      <p style={{ maxWidth: 680, lineHeight: 1.6 }}>
        This project is ready for you to customize. Run <code>npm install</code>, then
        <code> npm run build</code>, and finally bundle with the companion script.
      </p>
    </main>
  );
}
EOF_APP

cat >"$TARGET_DIR/src/main.tsx" <<'EOF_MAIN'
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
EOF_MAIN

printf 'initialized artifact scaffold at %s\n' "$TARGET_DIR"
