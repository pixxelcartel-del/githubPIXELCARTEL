---
name: n8n-workflow-automation
description: >
  Luna's primary automation layer. Use for ANY task touching external services —
  email, CRM, Supabase, Telegram, scraping, content, lead qualification, invoicing,
  AI pipelines. n8n holds all credentials; Luna never handles raw API keys for
  external services. Two access paths: native MCP (workflow search/execute) and
  MCP gateway (webhook triggers + direct API). Always prefer n8n over calling
  external APIs directly.
---

# n8n Workflow Automation — Luna Skill v2

## WHEN TO USE (triggers)
- Any task hitting an external service (email, CRM, social, Supabase, Telegram)
- Multi-step pipelines (research → analyze → draft → publish)
- Anything needing stored credentials Luna doesn't hold directly
- Lead qualification (Elliot voice agent)
- Meeting logging
- Content generation and scheduling
- File transcription / summarization
- Building new automations programmatically

## ACCESS PATHS

### Path 1 — Native n8n MCP (via OpenClaw mcp.servers.n8n)
Direct access to n8n's built-in MCP server. Use for:
- Searching and discovering existing workflows
- Executing workflows by name/description
- Managing workflow state

Endpoint: `https://n8n.srv1184131.hstgr.cloud/mcp-server/http`
Auth: Bearer `N8N_MCP_TOKEN` (already in openclaw.json env)

### Path 2 — Luna MCP Gateway (port 3456, loopback)
Custom HTTP layer for direct API calls and webhook triggers. Use for:
- Triggering specific webhook workflows
- Health checks and execution history
- Programmatic workflow creation
- Any tool not exposed via native MCP

Endpoint: `http://localhost:3456`
Call format: `POST /call` `{ "tool": "n8n_list_workflows", "input": {} }`

## AVAILABLE TOOLS (Gateway — 24 tools)

### Workflow Management
- `n8n_list_workflows` — all workflows with ID, name, active state
- `n8n_get_workflow` — full workflow detail by ID
- `n8n_execute_workflow` — run any workflow by ID
- `n8n_activate_workflow` — toggle active state
- `n8n_create_workflow` — build new workflow programmatically
- `n8n_get_executions` — execution history (filter by workflow/status)
- `n8n_get_execution_detail` — full node-by-node output for one execution
- `n8n_get_system_health` — n8n health + API status
- `n8n_list_credentials` — credential names/types (values never exposed)

### Webhook Triggers (require matching workflow in n8n)
- `n8n_trigger_webhook` — hit any webhook path with any data
- `n8n_log_meeting` → `luna-meeting-logger`
- `n8n_qualify_lead` → `luna-lead-qualifier` (Elliot)
- `n8n_generate_viral_content` → `luna-viral-content`
- `n8n_send_email` → `luna-send-email`
- `n8n_store_to_supabase` → `luna-supabase-write`
- `n8n_query_supabase` → `luna-supabase-query`
- `n8n_web_scrape` → `luna-web-scrape`
- `n8n_search_and_summarize` → `luna-search-summarize`
- `n8n_schedule_content` → `luna-content-scheduler`
- `n8n_create_crm_record` → `luna-crm-write`
- `n8n_process_file` → `luna-file-processor`
- `n8n_run_ai_pipeline` → `luna-pipeline-{name}`
- `n8n_send_telegram` → `luna-telegram-send`
- `n8n_invoice_send` → `luna-invoice`

## SECURITY RULE (NON-NEGOTIABLE)
ALL external credentials live ONLY in n8n's credential store.
Luna calls n8n → n8n uses stored creds → returns results.
Luna NEVER holds raw API keys for: Gmail, Slack, HubSpot, Airtable, etc.

## n8n INSTANCE
- Public URL: https://n8n.srv1184131.hstgr.cloud
- Local: http://localhost:5678
- UI access: `ssh -N -L 5678:127.0.0.1:5678 himel@100.80.74.21` then open http://localhost:5678
- API key: `N8N_API_KEY` in openclaw.json env
- MCP token: `N8N_MCP_TOKEN` in openclaw.json env

## BUILDING NEW WORKFLOWS
When a needed workflow doesn't exist:
1. Use `n8n_create_workflow` to scaffold it, OR
2. Tell Himel exactly what to build in the n8n UI
3. Provide node-by-node config — don't guess, be precise

## WORKFLOW DESIGN RULES
- Always include error handling nodes
- Always log execution results (write status row to Supabase or a Sheet)
- Use idempotency keys to prevent duplicate runs
- Never put secrets in node parameters — reference credential names only
- Add Telegram notification on failure for any critical workflow

## CREDENTIALS NEEDED IN N8N UI
(Tell Himel to add these — never add programmatically)
- OpenAI → AI generation nodes
- Supabase → read/write luna_memory_vault
- Telegram → bot token `8692962949:AAE1...`
- Gmail/SMTP → email sending
- Bland.ai or Vapi → Elliot outbound calls
- ElevenLabs → voice synthesis
- Firecrawl → web scraping (key in openclaw env)
