#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path

REF_RE = re.compile(r'(?P<path>(?:scripts|references|assets)/[^\s`)"\'<>]+|LICENSE\.txt|README\.md|package\.json)')
FM_RE = re.compile(r'^---\n(.*?)\n---\n', re.S)
KV_RE = re.compile(r'^(name|description):\s*(.+)$', re.M)


def parse_frontmatter(text: str) -> dict:
    match = FM_RE.match(text)
    data = {}
    if not match:
        return data
    for key, value in KV_RE.findall(match.group(1)):
        data[key] = value.strip().strip('"').strip("'")
    return data


def lint_skill(skill_dir: Path) -> dict:
    result = {
        "skill": skill_dir.name,
        "path": str(skill_dir),
        "ok": True,
        "errors": [],
        "references": [],
    }
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        result["ok"] = False
        result["errors"].append("missing SKILL.md")
        return result

    text = skill_md.read_text(encoding="utf-8", errors="replace")
    frontmatter = parse_frontmatter(text)
    if not frontmatter.get("name"):
        result["ok"] = False
        result["errors"].append("missing frontmatter name")
    if not frontmatter.get("description"):
        result["ok"] = False
        result["errors"].append("missing frontmatter description")

    seen = set()
    for ref in REF_RE.findall(text):
        if ref in seen:
            continue
        seen.add(ref)
        exists = (skill_dir / ref).exists()
        result["references"].append({"path": ref, "exists": exists})
        if not exists:
            result["ok"] = False
            result["errors"].append(f"missing referenced path: {ref}")

    return result


def expand_targets(paths, workspace_skills):
    targets = []
    for raw in paths:
        path = Path(raw).expanduser().resolve()
        if path.is_dir() and (path / "SKILL.md").exists():
            targets.append(path)
        elif path.is_dir():
            for child in sorted(path.iterdir()):
                if child.is_dir() and (child / "SKILL.md").exists():
                    targets.append(child.resolve())
    if workspace_skills:
        ws = Path(workspace_skills).expanduser().resolve()
        for child in sorted(ws.iterdir()):
            if child.is_dir() and (child / "SKILL.md").exists():
                targets.append(child.resolve())
    unique = []
    seen = set()
    for target in targets:
        key = str(target)
        if key not in seen:
            seen.add(key)
            unique.append(target)
    return unique


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="*", help="Skill directories or a workspace skills root")
    parser.add_argument("--workspace-skills", help="Workspace skills directory to lint")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    targets = expand_targets(args.paths or [], args.workspace_skills)
    if not targets:
        parser.error("no skill directories found")

    results = [lint_skill(target) for target in targets]
    if args.json:
        print(json.dumps(results, indent=2))
        return

    failing = 0
    for item in results:
        status = "OK" if item["ok"] else "FAIL"
        print(f"{status} {item['skill']} -> {item['path']}")
        for error in item["errors"]:
            print(f"  - {error}")
        failing += 0 if item["ok"] else 1

    if failing:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
