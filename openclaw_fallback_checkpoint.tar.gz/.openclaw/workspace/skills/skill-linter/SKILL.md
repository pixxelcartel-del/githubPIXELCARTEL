---
name: skill-linter
description: Validate workspace skill folders, metadata, and referenced local artifacts before deployment.
---

# Skill Linter

Use this skill when you need to verify that local skills are structurally sound before relying on them in a workspace.

## What it checks

- every selected skill directory contains `SKILL.md`
- frontmatter includes `name` and `description`
- local paths referenced from the skill doc exist when they point at `scripts/`, `references/`, `assets/`, `LICENSE.txt`, `README.md`, or `package.json`

## Commands

Lint every workspace skill:

```bash
python3 scripts/lint_skills.py --workspace-skills ../
```

Lint one skill directory:

```bash
python3 scripts/lint_skills.py ../web-artifacts-builder
```

Use `--json` for machine-readable output.
