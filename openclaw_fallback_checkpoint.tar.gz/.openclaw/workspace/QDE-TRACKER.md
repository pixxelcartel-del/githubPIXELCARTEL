# QDE-TRACKER.md
Updated: 2026-04-16 21:15 UTC
Status: active scoring pass in progress

This tracker was restored from handoff references plus the live QDE scoring doctrine in `memory/pixc/qde-prompt.json`, `memory/pixc/qde-gold-signals.json`, and `memory/pixc/qde-red-flags.json` after the original file was missing from the workspace snapshot.

## Purpose
Track premium web techniques worth integrating into PixC builds. Prioritize techniques that score GOLD or SILVER under the QDE rubric and are directly useful for scroll-driven websites, cinematic landing pages, 3D web, and premium interaction design.

## Status Key
- integrated: `yes` = already used in production or a real build
- integrated: `no` = still available for evaluation/build
- priority: `GOLD`, `SILVER`, `BRONZE`, `TRASH`, or `UNSCORED`
- next_action: `score`, `prototype`, `integrate`, `archive`

## Tracker
| Technique | Category | Priority | Integrated | Why it matters | Next action | Notes |
|---|---|---:|---:|---|---|---|
| CSS scroll-driven animations (`animation-timeline`, `view()`, `scroll()`) | css-native | GOLD | no | Native scroll-linked motion with zero JS overhead, ideal for PixC editorial sections and reveals | prototype | Strong fit for AntiGravity-style sections |
| GSAP + ScrollTrigger (latest) | library-gold | GOLD | no | Battle-tested premium animation stack, strongest bridge for cinematic scroll experiences | integrate | Prototype landed at `research/qde-prototype-gsap-lenis/` on 2026-04-16, ready to promote into a shared PixC section starter |
| Lenis.js smooth scroll | library-gold | GOLD | no | Pairs cleanly with ScrollTrigger for premium-feel scrolling and motion sync | prototype | Scored 86.8 on 2026-04-16, promoted to GOLD for PixC cinematic builds when paired with reduced-motion fallback |
| Three.js / React Three Fiber | library-gold | GOLD | no | Highest visual ceiling for 3D web, hero scenes, and differentiated client work | prototype | High upside, higher implementation cost |
| Framer Motion v10+ | library-gold | SILVER | no | Excellent for React layout transitions, UI motion, and polished product sections | prototype | Scored 84.3 on 2026-04-16, strong module-level default for React sections but not quite above GOLD cutoff |
| CSS `@property` animated custom properties | css-native | GOLD | no | Native typed custom-property animation enables elegant gradients and premium visual systems | score | Strong for premium UI treatments and backgrounds |
| Container queries (`@container`) | css-native | GOLD | no | Makes components responsive to their parent, not just the viewport | prototype | Scored 89.8 on 2026-04-16, promoted to GOLD as a native foundation for reusable PixC sections |
| `:has()` selector | css-native | SILVER | no | Reduces JS for relational UI states and enables cleaner advanced CSS interactions | score | Good architecture win, moderate visual payoff |
| View Transitions API | css-native | SILVER | no | Native page transitions for multi-view experiences and polished navigation | score | Especially relevant for Next.js app-router experiments |
| Motion One / WAAPI | platform-native | SILVER | no | Lean browser-native animation option with low dependency overhead | score | Could beat heavier libs for smaller builds |
| Shader-based effects (GLSL / WebGPU) | advanced-graphics | GOLD | no | Premium ceiling for distortion, particles, noise, and cinematic graphics | archive | Worth keeping, but likely not first implementation target |

## Night Shift Restore Notes — 2026-04-16
- Reconstructed this file because `QDE-TRACKER.md` was referenced in `TASKS.md` and handoff docs but was missing from the workspace.
- Seeded 11 techniques to match the original handoff note that the tracker had been seeded with 11 items.
- Chose techniques from the live QDE gold-signal doctrine so future scoring stays aligned with the existing system.
- Highest-priority build candidate after restore: `GSAP + ScrollTrigger` or native CSS `animation-timeline`.

## Scoring Pass — 2026-04-16 21:15 UTC

### 1) Lenis.js smooth scroll
- Weighted total: `86.8`
- Verdict: `GOLD`
- Gold signals detected: `Lenis.js for smooth scroll`
- Red flags: none
- Why: agency adoption is extremely strong and it pairs directly with ScrollTrigger for the exact cinematic motion PixC wants. Performance stays high if reduced-motion and native scroll fallback are wired correctly.
- Acquisition recommendation: `prototype`

### 2) Framer Motion v10+
- Weighted total: `84.3`
- Verdict: `SILVER`
- Gold signals detected: `Framer Motion (v10+)`
- Red flags: none
- Why: superb for polished React modules and reusable product sections, but more framework-bound and slightly less future-proof than native CSS primitives. Still a high-confidence default for app-like UI motion.
- Acquisition recommendation: `prototype`

### 3) Container queries (`@container`)
- Weighted total: `89.8`
- Verdict: `GOLD`
- Gold signals detected: `Container queries (@container)`
- Red flags: none
- Why: this is now a native layout advantage, not an experiment. It directly improves reusable PixC blocks, component portability, and premium responsiveness without JS weight.
- Acquisition recommendation: `integrate_now`

## Recommended next autonomous pass
1. Promote the `research/qde-prototype-gsap-lenis/` prototype into a shared PixC section starter.
2. Add `@container` to the next reusable PixC section system as a default responsive primitive.
3. Mark integrated=`yes` only after a real implementation lands in a real build, artifact, or reusable component.
