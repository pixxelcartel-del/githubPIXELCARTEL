-- ============================================================
-- LUNA SUPABASE TABLES
-- Run in: Supabase Dashboard → SQL Editor
-- Project: jjpqiskuksqdstopdgib
-- ============================================================

-- Meeting logs (luna-meeting-logger)
create table if not exists meeting_logs (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  attendees text,
  summary text not null,
  outcome text,
  date timestamptz default now(),
  logged_by text default 'luna',
  created_at timestamptz default now()
);

-- Leads (luna-lead-qualifier)
create table if not exists leads (
  id uuid default gen_random_uuid() primary key,
  lead_name text not null,
  lead_company text,
  phone text,
  lead_request text,
  call_id text,
  status text default 'called',
  qualified boolean,
  notes text,
  created_at timestamptz default now()
);

-- Content log (luna-viral-content, luna-pipeline-content)
create table if not exists content_log (
  id uuid default gen_random_uuid() primary key,
  topic text,
  platform text,
  pipeline text,
  hooks text,
  output text,
  created_at timestamptz default now()
);

-- Content schedule (luna-content-scheduler)
create table if not exists content_schedule (
  id uuid default gen_random_uuid() primary key,
  platform text not null,
  content text not null,
  schedule_time timestamptz not null,
  media_url text,
  status text default 'scheduled',
  posted_at timestamptz,
  created_at timestamptz default now()
);

-- CRM contacts
create table if not exists crm_contacts (
  id uuid default gen_random_uuid() primary key,
  name text,
  email text,
  company text,
  phone text,
  source text default 'luna',
  tags text[],
  notes text,
  created_at timestamptz default now()
);

-- CRM deals
create table if not exists crm_deals (
  id uuid default gen_random_uuid() primary key,
  contact_id uuid references crm_contacts(id),
  title text,
  value numeric,
  currency text default 'USD',
  stage text default 'lead',
  source text default 'luna',
  notes text,
  created_at timestamptz default now()
);

-- CRM notes
create table if not exists crm_notes (
  id uuid default gen_random_uuid() primary key,
  contact_id uuid references crm_contacts(id),
  content text,
  source text default 'luna',
  created_at timestamptz default now()
);

-- Research log (luna-pipeline-research)
create table if not exists research_log (
  id uuid default gen_random_uuid() primary key,
  topic text,
  report text,
  sources jsonb,
  created_at timestamptz default now()
);

-- Tasks (morning-brief, night-shift)
create table if not exists tasks (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  description text,
  status text default 'pending',
  priority text default 'medium',
  assigned_to text default 'luna',
  due_date timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Cost log (cost-audit)
create table if not exists cost_log (
  id uuid default gen_random_uuid() primary key,
  date date default current_date,
  provider text,
  model text,
  tokens_used integer,
  cost_usd numeric,
  weekly_pct numeric,
  notes text,
  created_at timestamptz default now()
);

-- Luna memory vault (general purpose)
create table if not exists luna_memory_vault (
  id uuid default gen_random_uuid() primary key,
  category text,
  key text,
  value text,
  metadata jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Enable RLS but allow service role full access
alter table meeting_logs enable row level security;
alter table leads enable row level security;
alter table content_log enable row level security;
alter table content_schedule enable row level security;
alter table crm_contacts enable row level security;
alter table crm_deals enable row level security;
alter table crm_notes enable row level security;
alter table research_log enable row level security;
alter table tasks enable row level security;
alter table cost_log enable row level security;
alter table luna_memory_vault enable row level security;

-- Service role bypass policy for all tables
do $$
declare
  t text;
begin
  foreach t in array array[
    'meeting_logs','leads','content_log','content_schedule',
    'crm_contacts','crm_deals','crm_notes','research_log',
    'tasks','cost_log','luna_memory_vault'
  ] loop
    execute format(
      'create policy if not exists "service_role_all" on %I for all to service_role using (true) with check (true)', t
    );
  end loop;
end $$;

-- Confirm
select table_name from information_schema.tables
where table_schema = 'public'
order by table_name;
