-- ============================================================
-- LUNA SUPABASE TABLES (FIXED)
-- Run in: Supabase Dashboard → SQL Editor
-- Project: jjpqiskuksqdstopdgib
-- ============================================================

-- Meeting logs (luna-meeting-logger)
create table if not exists public.meeting_logs (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  attendees text,
  summary text not null,
  outcome text,
  date timestamptz default now(),
  logged_by text default 'luna',
  created_at timestamptz default now()
);

-- Leads (luna-lead-qualifier)
create table if not exists public.leads (
  id uuid default gen_random_uuid() primary key,
  lead_name text not null,
  lead_company text,
  phone text,
  lead_request text,
  call_id text,
  status text default 'called',
  qualified boolean,
  notes text,
  created_at timestamptz default now()
);

-- Content log (luna-viral-content, luna-pipeline-content)
create table if not exists public.content_log (
  id uuid default gen_random_uuid() primary key,
  topic text,
  platform text,
  pipeline text,
  hooks text,
  output text,
  created_at timestamptz default now()
);

-- Content schedule (luna-content-scheduler)
create table if not exists public.content_schedule (
  id uuid default gen_random_uuid() primary key,
  platform text not null,
  content text not null,
  schedule_time timestamptz not null,
  media_url text,
  status text default 'scheduled',
  posted_at timestamptz,
  created_at timestamptz default now()
);

-- CRM contacts
create table if not exists public.crm_contacts (
  id uuid default gen_random_uuid() primary key,
  name text,
  email text,
  company text,
  phone text,
  source text default 'luna',
  tags text[],
  notes text,
  created_at timestamptz default now()
);

-- CRM deals
create table if not exists public.crm_deals (
  id uuid default gen_random_uuid() primary key,
  contact_id uuid references public.crm_contacts(id),
  title text,
  value numeric,
  currency text default 'USD',
  stage text default 'lead',
  source text default 'luna',
  notes text,
  created_at timestamptz default now()
);

-- CRM notes
create table if not exists public.crm_notes (
  id uuid default gen_random_uuid() primary key,
  contact_id uuid references public.crm_contacts(id),
  content text,
  source text default 'luna',
  created_at timestamptz default now()
);

-- Research log (luna-pipeline-research)
create table if not exists public.research_log (
  id uuid default gen_random_uuid() primary key,
  topic text,
  report text,
  sources jsonb,
  created_at timestamptz default now()
);

-- Tasks (morning-brief, night-shift)
create table if not exists public.tasks (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  description text,
  status text default 'pending',
  priority text default 'medium',
  assigned_to text default 'luna',
  due_date timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Cost log (cost-audit)
create table if not exists public.cost_log (
  id uuid default gen_random_uuid() primary key,
  date date default current_date,
  provider text,
  model text,
  tokens_used integer,
  cost_usd numeric,
  weekly_pct numeric,
  notes text,
  created_at timestamptz default now()
);

-- Luna memory vault (general purpose)
create table if not exists public.luna_memory_vault (
  id uuid default gen_random_uuid() primary key,
  category text,
  key text,
  value text,
  metadata jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Enable RLS
alter table public.meeting_logs enable row level security;
alter table public.leads enable row level security;
alter table public.content_log enable row level security;
alter table public.content_schedule enable row level security;
alter table public.crm_contacts enable row level security;
alter table public.crm_deals enable row level security;
alter table public.crm_notes enable row level security;
alter table public.research_log enable row level security;
alter table public.tasks enable row level security;
alter table public.cost_log enable row level security;
alter table public.luna_memory_vault enable row level security;

-- Service role full-access policies
-- Postgres does not support CREATE POLICY IF NOT EXISTS, so we guard manually.
do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'meeting_logs' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.meeting_logs
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'leads' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.leads
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'content_log' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.content_log
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'content_schedule' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.content_schedule
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'crm_contacts' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.crm_contacts
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'crm_deals' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.crm_deals
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'crm_notes' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.crm_notes
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'research_log' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.research_log
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'tasks' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.tasks
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'cost_log' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.cost_log
      for all to service_role using (true) with check (true);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'luna_memory_vault' and policyname = 'service_role_all'
  ) then
    create policy "service_role_all" on public.luna_memory_vault
      for all to service_role using (true) with check (true);
  end if;
end $$;

-- Confirm
select table_name
from information_schema.tables
where table_schema = 'public'
  and table_name in (
    'meeting_logs','leads','content_log','content_schedule',
    'crm_contacts','crm_deals','crm_notes','research_log',
    'tasks','cost_log','luna_memory_vault'
  )
order by table_name;
