# Luna Memory Architecture

Generated: 2026-04-14T22:07:43Z

## Canonical Architecture

- OpenClaw version: `OpenClaw 2026.4.14 (323493f)`
- Active memory plugin slot: `memory-core`
- Memory backend: `qmd`
- QMD command: `/home/himel/.openclaw/bin/qmd-openclaw`
- QMD search mode: `search`
- QMD session indexing: `True`
- QMD vector status before consolidation: ready.

## Important Decision

`memory-core` is the canonical memory plugin. The mem0 fork remains disabled for rollback only. Do not re-enable mem0 unless intentionally rolling back from official memory-core.

## QMD Runtime Constraint

The VPS does not have a working Vulkan stack for `node-llama-cpp`. QMD must run with `QMD_LLAMA_GPU=off` through `/home/himel/.openclaw/bin/qmd-openclaw` to avoid Vulkan/CMake startup failures.

## Dreaming

Dreaming is configured under `plugins.entries.memory-core.config.dreaming` with schedule `0 3 * * *` and timezone `Asia/Dhaka`. If logs show cron reconciliation unavailable, fix the OpenClaw cron/task service rather than switching memory plugins.

## Legacy Source Handling

- Pinecone indexes: `luna-memory`
- Disabled mem0 extensions: `@tensakulabs/openclaw-mem0 1.0.5`
- Previous memory/build database candidates inventoried: `257`
