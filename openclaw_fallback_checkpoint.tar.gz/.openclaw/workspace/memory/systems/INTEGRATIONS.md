# Luna Integration Memory

Generated: 2026-04-14T22:07:43Z

## Validated Integration Map

| Integration | Ready | Memory note |
| --- | --- | --- |
| OpenClaw gateway | True | 2026.4.14 on 127.0.0.1:18789 |
| QMD | True | Active memory backend; CPU-forced via QMD_LLAMA_GPU=off |
| Ollama | True | Local model service expected at 127.0.0.1:11435 |
| n8n | True | 28 workflows via official API |
| Supabase | True | REST reachable; 0 DB tables/views inventoried |
| Pinecone | True | luna-memory |
| Qdrant | True | code_snippets, luna_memory, memories, pixc_builds, agent_outputs, openclaw-mem0, luna-mem0, tutorials, memory_migrations, luna_learnings, market_intel, design_assets |
| GitHub | True | GITHUB_TOKEN present; gh authenticated as luxurioupotato in prior validation |
| Firecrawl | True | MCP configured with FIRECRAWL_API_KEY |
| Context7 | True | MCP configured with @upstash/context7-mcp |
| Playwright | True | MCP configured with @playwright/mcp@latest; Puppeteer MCP is deprecated/not target |
| OpenRouter | True | Fallback/provider key present |
| Neo4j | True | Graph env configured; import only current graph facts after read-only validation |

## Integration Policy

- Use official OpenClaw `memory-core` + QMD as canonical memory.
- Use n8n for automations and webhook workflows, not as the canonical long-term memory store.
- Treat Pinecone `luna-memory`, disabled mem0/Qdrant collections, Supabase tables, Neo4j graph data, and old SQLite stores as legacy or source systems until a specific active dependency is proven.
- Never write secret values into memory. Store env var names only.
- Playwright MCP is Luna's supported browser automation path. Puppeteer MCP is not part of the target stack because the available package is deprecated and failed validation.
