# Luna NotebookLM Memory

Generated: 2026-04-15 Asia/Dhaka

## Role

NotebookLM is Luna's grounded research and source-library layer. Use it for source-backed notebooks, domain libraries, research reports, audio overviews, source Q&A, and multi-notebook project knowledge. It is not Luna's canonical memory store; canonical memory remains OpenClaw `memory-core` + QMD.

## Official Behavior To Respect

- Google NotebookLM notebooks are independent source collections. NotebookLM cannot answer across multiple notebooks at the same time.
- Standard NotebookLM limits are 100 notebooks with up to 50 sources per notebook; Pro/expanded plans raise this to 500 notebooks with up to 300 sources per notebook.
- NotebookLM can use uploaded PDFs, websites/URLs, Google Docs/Slides, YouTube, audio, and copied text as sources depending on platform/account support.
- Outputs such as reports, study guides, briefing docs, audio overviews, quizzes, and slide-like artifacts should be grounded in the notebook's sources.

## Local Setup

- Local skill path: `C:\Users\himel\.claude\skills\notebooklm`
- Local CLI: `C:\Users\himel\.claude\skills\notebooklm\scripts\nlm.py`
- Local auth state: `C:\Users\himel\.notebooklm\storage_state.json`
- Local MCP server: `node C:\Users\himel\.claude\skills\notebooklm\server\index.js`
- Claude Desktop config: `%APPDATA%\Claude\claude_desktop_config.json`, server key `notebooklm`
- Local scheduled tasks: `LunaNotebookLMRefresh`, `LunaNotebookLMLibraryBackup`

## VPS Setup

- VPS skill path: `~/.claude/skills/notebooklm`
- VPS CLI: `~/.claude/skills/notebooklm/scripts/nlm.py`
- VPS auth state: `~/.notebooklm/storage_state.json`
- VPS auth refresh cron: every 3 days at 05:30
- VPS library backup cron: daily at 04:00

## MCP Tools

Claude Desktop NotebookLM MCP exposes 15 tools:

- `nlm_list`
- `nlm_library_list`
- `nlm_library_add`
- `nlm_library_activate`
- `nlm_create`
- `nlm_ask`
- `nlm_add_url`
- `nlm_add_file`
- `nlm_add_text`
- `nlm_sources`
- `nlm_generate_report`
- `nlm_generate_audio`
- `nlm_research`
- `nlm_artifacts`
- `nlm_auth_status`

## Operating Rules

- Treat pasted `--- NLM OUTPUT ---` blocks as live NotebookLM state and act on them.
- Use one notebook per domain/project when source count or focus would otherwise become messy.
- Keep NotebookLM source libraries indexed in `library.json`, but put durable strategic facts into QMD memory after validation.
- Never store Google cookies or auth state in QMD memory, reports, GitHub, or n8n.
- After local Google login creates `storage_state.json`, sync it to the VPS and verify both `auth-status` and `list` locally and remotely.
- If NotebookLM auth fails, rerun local `python nlm.py login`; the watcher `C:\Users\himel\.claude\watch_notebooklm_auth_sync.ps1` will sync automatically when the auth file appears.
