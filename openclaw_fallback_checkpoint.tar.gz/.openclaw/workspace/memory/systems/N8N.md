# Luna n8n Automation Memory

Generated: 2026-04-14T22:07:43Z
Source: official n8n API at `n8n.srv1184131.hstgr.cloud`. Secrets and credential values are intentionally excluded.

## Current Role

n8n is Luna's active automation layer for scheduled briefs, autonomous thought loops, Supabase read/write endpoints, content pipelines, Telegram sends, research, scraping, CRM writes, cost audits, lead qualification, voiceover, and file/meeting processing.

## Verified State

- n8n API reachable: `True`
- Active Luna workflows discovered: `28` of `28`
- Tags returned by API: `0`
- Recent execution samples captured: `50`
- Execution sample mostly shows `luna-autonomous-thought` and `luna-supabase-query` running successfully every 5 minutes.

## Workflow Catalog

| Name | Active | Nodes | Triggers | Recent | Success | Failed |
| --- | --- | --- | --- | --- | --- | --- |
| luna-ai-intel | True | 4 | Daily 9am BDT | 0 | 0 | 0 |
| luna-autonomous-thought | True | 10 | Every 5 Minutes | 24 | 24 | 0 |
| luna-content-engine | True | 11 | Webhook | 0 | 0 | 0 |
| luna-content-full-pipeline | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-content-scheduler | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-cost-audit | True | 4 | Daily 8am BDT | 0 | 0 | 0 |
| luna-crm-write | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-file-processor | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-invoice | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-lead-qualifier | True | 5 | Webhook, Respond | 0 | 0 | 0 |
| luna-meeting-logger | True | 5 | Webhook, Respond | 0 | 0 | 0 |
| luna-mood-persist | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-morning-brief | True | 4 | Daily 7am BDT | 0 | 0 | 0 |
| luna-night-shift | True | 4 | Daily 11pm BDT | 1 | 1 | 0 |
| luna-performance-tracker | True | 5 | Webhook, Respond | 0 | 0 | 0 |
| luna-pipeline-content | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-pipeline-research | True | 5 | Webhook, Respond | 0 | 0 | 0 |
| luna-pipeline-saas | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-search-summarize | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-send-email | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-supabase-query | True | 3 | Webhook, Respond | 25 | 25 | 0 |
| luna-supabase-write | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-telegram-send | True | 3 | Webhook, Respond | 0 | 0 | 0 |
| luna-thought-miner | True | 7 | Webhook | 0 | 0 | 0 |
| luna-trend-analysis | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-viral-content | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-voiceover | True | 4 | Webhook, Respond | 0 | 0 | 0 |
| luna-web-scrape | True | 3 | Webhook, Respond | 0 | 0 | 0 |

## Operational Rules

- Treat workflow definitions as operational automation, not conversation memory.
- Store workflow purpose, trigger shape, endpoint role, and recent health in QMD memory.
- Do not store n8n credentials, API keys, webhook secrets, or request tokens.
- Before modifying workflows, export them through the official n8n API and preserve a redacted copy in the latest consolidation backup.
