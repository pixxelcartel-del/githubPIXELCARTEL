# AI Intel — 2026-04-03 00:30 UTC

## 1. Gemma 4 has been released
- Source: r/LocalLLaMA
- Score: 103
- URL: https://reddit.com/r/LocalLLaMA/comments/1salgre/gemma_4_has_been_released/

## 2. The Claude Code leak accidentally published the first complete blueprint for production AI agents. Here's what it tells us about where this is all going.
- Source: r/artificial
- Score: 100
- URL: https://reddit.com/r/artificial/comments/1s9jprb/the_claude_code_leak_accidentally_published_the/

## 3. Gemma 4 is efficient with thinking tokens, but it will also happily reason for 10+ minutes if you prompt it to do so.
- Source: r/LocalLLaMA
- Score: 100
- URL: https://reddit.com/r/LocalLLaMA/comments/1sav9wg/gemma_4_is_efficient_with_thinking_tokens_but_it/

## 4. AMA on our DevDay Launches
- Source: r/OpenAI
- Score: 100
- URL: https://reddit.com/r/OpenAI/comments/1o1j23g/ama_on_our_devday_launches/

## 5. The next release will have ik_llama.cpp support!
- Source: r/Oobabooga
- Score: 100
- URL: https://reddit.com/r/Oobabooga/comments/1s48ry0/the_next_release_will_have_ik_llamacpp_support/

## 6. [P] PhAIL (phail.ai) – an open benchmark for robot AI on real hardware. Best model: 5% of human throughput, needs help every 4 minutes.
- Source: r/MachineLearning
- Score: 98
- URL: https://reddit.com/r/MachineLearning/comments/1sajdwr/p_phail_phailai_an_open_benchmark_for_robot_ai_on/

## 7. LinearARD: Linear-Memory Attention Distillation for RoPE Restoration
- Source: ArXiv
- Score: 98
- URL: https://arxiv.org/abs/2604.00004

## 8. [P] Gemma 4 running on NVIDIA B200 and AMD MI355X from the same inference stack, 15% throughput gain over vLLM on Blackwell
- Source: r/MachineLearning
- Score: 97
- URL: https://reddit.com/r/MachineLearning/comments/1saot07/p_gemma_4_running_on_nvidia_b200_and_amd_mi355x/

## 9. Stanford CS 25 Transformers Course (OPEN TO ALL | Starts Tomorrow)
- Source: r/MachineLearning
- Score: 90
- URL: https://reddit.com/r/MachineLearning/comments/1sa3cf0/stanford_cs_25_transformers_course_open_to_all/

## 10. Gemma 4 1B, 13B, and 27B spotted
- Source: r/LocalLLaMA
- Score: 90
- URL: https://reddit.com/r/LocalLLaMA/comments/1sakdd2/gemma_4_1b_13b_and_27b_spotted/
