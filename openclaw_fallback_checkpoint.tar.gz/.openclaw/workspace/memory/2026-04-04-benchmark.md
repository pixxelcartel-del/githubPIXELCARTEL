# Luna Benchmark Report
Generated: 2026-04-04 00:00 UTC
Sessions analyzed: 5

## Session: a4de3449...
Messages scored: 1 | Avg score: 69%

## Session: a60fa4f1...
Messages scored: 1 | Avg score: 69%

## Session: 6a62a189...
Messages scored: 5 | Avg score: 94%

## Session: 9e317e66...
Messages scored: 1 | Avg score: 69%

## Session: 9e770dfa...
Messages scored: 1 | Avg score: 69%

## OVERALL SCORE: 83% (9 messages)

## Top Violations (most frequent first)
  - no_markdown (5x): No bullet points / bold / backticks in chat
  - short_response (5x): Max 8 lines for complex, 4 for casual

## Suggested SOUL.md Patches
  Priority fix: [no_markdown] — No bullet points / bold / backticks in chat
  Suggested addition to SOUL.md enforcement section:
  > HARD RULE: No bullet points / bold / backticks in chat — violated 5x in last benchmark

---