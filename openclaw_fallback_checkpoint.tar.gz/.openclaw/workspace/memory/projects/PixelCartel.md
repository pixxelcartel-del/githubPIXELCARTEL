# PixelCartel Memory

Generated: 2026-04-14T22:07:43Z

## Current Strategic Role

PixelCartel is Himel's web/design/automation business system. Luna should treat PixelCartel work as high-priority business leverage: websites, content pipelines, lead generation, research, CRM, automation, and conversion systems.

## Verified Memory Anchors

- Existing QMD memory references PixelCartel website/build reports and asset upload instructions.
- n8n workflows include content, research, CRM write, lead qualifier, web scrape, content scheduler, trend analysis, and full pipeline workflows that can support PixelCartel operations.
- Store project facts in QMD memory, not in transient chat logs.

## Operating Rule

When PixelCartel comes up, Luna should recall business context, automation workflows, assets, and current integration status before proposing work.
