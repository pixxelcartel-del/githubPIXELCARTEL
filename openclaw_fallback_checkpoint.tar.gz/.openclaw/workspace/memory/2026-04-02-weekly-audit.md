# WEEKLY FORENSIC AUDIT — April 2, 2026
# Model: Opus 4.6 | Scope: Full system integrity

---

## EXECUTIVE SUMMARY

System is partially functional with several critical mismatches that will cause silent failures.
The March 27 n8n workflow import + Supabase migration left behind hardcoded stale references in multiple workflows.
Agent hierarchy is clean. Model routing is now correct. Memory/infra services are healthy.
The build is NOT complete — there are 7 blocking issues that must be resolved before Luna can operate reliably.

---

## 1. INFRASTRUCTURE HEALTH

| Service | Status | Notes |
|---------|--------|-------|
| Docker | ALL UP | n8n 26h, traefik 4d, mission-control 5d, ollama/neo4j/qdrant 10d |
| n8n API | HEALTHY | HTTP 200, auth gate working |
| Supabase (new) | HEALTHY | fkqrdxukeejoomlzqirw responding, tasks table reachable |
| Supabase (old) | DEAD | jjpqiskuksqdstopdgib does not resolve — NXDOMAIN |
| Ollama | HEALTHY | phi3.5, nomic-embed-text, llama3.2:3b loaded |
| Qdrant | HEALTHY | 10 collections active |
| Neo4j | HEALTHY | Community 5.26.23, bolt + HTTP endpoints up |
| Tailscale | OK | VPS at 100.80.74.21 |

---

## 2. CRITICAL ISSUES (must fix)

### CRIT-001: n8n workflows still have HARDCODED dead Supabase URLs + keys
**Severity: P0 — actively broken**
Workflows luna-pipeline-content, luna-viral-content (and likely others) have the OLD Supabase URL and OLD service_role key hardcoded directly in their HTTP request nodes.
Example from luna-viral-content node "Log to Supabase":
  URL: https://jjpqiskuksqdstopdgib.supabase.co/rest/v1/content_log
  apikey: eyJ...the old dead key...
These workflows will silently fail on any Supabase write.
luna-morning-brief was already updated to fkqrdxukeejoomlzqirw and uses $env — but others were not.
**Fix: Batch-update all 20 workflows to use the new Supabase URL + $env references instead of hardcoded keys.**

### CRIT-002: MEMORY.md references stale Supabase project
**Severity: P1 — causes confusion and incorrect automation**
MEMORY.md still says:
  Supabase: luna_memory_vault (project jjpqiskuksqdstopdgib, URL https://jjpqiskuksqdstopdgib.supabase.co)
This is the dead project. Live project is fkqrdxukeejoomlzqirw.
**Fix: Update MEMORY.md Supabase references to the live project.**

### CRIT-003: Content engine tables mismatch
**Severity: P1 — content automation will fail**
MEMORY.md Content Automation Engine section says tables are:
  content_ideas, content_scripts, content_assets, content_published, content_performance
But the SQL that was actually run created DIFFERENT tables:
  meeting_logs, leads, content_log, content_schedule, crm_contacts, crm_deals, crm_notes, research_log, tasks, cost_log, luna_memory_vault
The content engine tables (content_ideas, etc.) DO NOT EXIST in the new Supabase project.
**Fix: Either create the missing content engine tables in the new project, or update MEMORY.md to reflect the actual schema.**

### CRIT-004: GitHub PAT exposed in crontab
**Severity: P1 — security**
The nightly backup cron has the GitHub PAT inline:
  GITHUB_TOKEN=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
Should be moved to a secure credential file.
**Fix: Move PAT to ~/.config/luna-github/token or env file, reference from cron.**

### CRIT-005: TOOLS.md and SOUL.md still reference legacy agent names
**Severity: P2 — causes dispatch confusion**
TOOLS.md routing matrix still says:
  Code/engineering → Atlas via sessions_spawn
  Content/marketing → Nova via sessions_spawn
  Research/intel → Cipher via sessions_spawn
  Strategy → Oracle via sessions_spawn
SOUL.md also references Atlas/Nova/Cipher/Oracle in various places.
Live allowed agents are: ernest, sun-tzu, elon, mark, a.
**Fix: Update TOOLS.md and SOUL.md routing references to match the live Phase-1 roster.**

### CRIT-006: Model routing docs are stale
**Severity: P2 — causes wrong model assumptions**
MEMORY.md Infrastructure section says:
  Models: openai-codex/gpt-5.4 (primary, free via Plus sub)
SOUL.md MODEL ROUTING section says:
  Default: GPT-5.4 for direct chat with Himel (free via subscription)
Live config now has: anthropic/claude-opus-4-6 for luna/main.
**Fix: Update MEMORY.md and SOUL.md to reflect current model routing reality.**

### CRIT-007: n8n MCP duplicate entries
**Severity: P3 — cosmetic but confusing**
MCP config has both "n8n" and "n8n-gateway" pointing to the same localhost:3456.
**Fix: Consolidate to one entry.**

---

## 3. AGENT HIERARCHY

| Agent | Model | Workspace | Tools | Status |
|-------|-------|-----------|-------|--------|
| luna/main | opus-4-6 | ~/.openclaw/workspace | full (minus gateway/canvas/nodes/process) | CLEAN |
| ernest | haiku | workspace-main | read-only + memory + sessions | CLEAN |
| sun-tzu | sonnet | workspace-sun-tzu | read-only + memory + sessions (can spawn elon/mark/a) | CLEAN |
| elon | sonnet | workspace-elon | exec + read/write/edit + memory + sessions | CLEAN |
| mark | sonnet | workspace-mark | exec + read/write/edit + memory + sessions | CLEAN |
| a | sonnet | workspace-a | exec + read + memory + sessions (no write/edit) | CLEAN |

Dispatch routing in AGENTS.md matches openclaw.json allowAgents.
sun-tzu can sub-dispatch to elon/mark/a — pipeline orchestration is properly configured.
Ernest is read-only compression agent — correct.
A is security/audit with no write access — correct.

**Verdict: Agent hierarchy is correctly configured and matches AGENTS.md.**

---

## 4. AUTOMATIONS (Crons)

| Cron | Schedule | Status | Notes |
|------|----------|--------|-------|
| Nightly backup | 2am BDT | ACTIVE | PAT exposed inline (CRIT-004) |
| Memory maintenance | 3am BDT | ACTIVE | OK |
| Heartbeat | Every 4h (8,12,16,20,0) | ACTIVE | OK |
| Workspace sync | Every 30min | ACTIVE | Syncs legacy→main |
| Luna benchmark | Every 6h | ACTIVE | OK |
| Luna autopatch | Every 6h offset | ACTIVE | OK |
| Luna AI intel | 12:30am BDT | ACTIVE | OK |
| n8n webhook restore | @reboot + 6h | ACTIVE | OK |
| Personality sync | Every 5min | ACTIVE | High frequency — consider reducing |

**Note: luna-sync-personality.sh runs every 5 minutes. That's aggressive. Consider 15-30 min.**

---

## 5. n8n WORKFLOWS (20 total)

All 20 workflows are marked active in the n8n API.
Key finding: some use $env.SUPABASE_SERVICE_ROLE_KEY (correct), but several have HARDCODED old keys/URLs (broken).

Workflows confirmed using NEW Supabase ref (fkqrdxukeejoomlzqirw):
- luna-morning-brief ✓

Workflows with HARDCODED OLD Supabase ref (jjpqiskuksqdstopdgib):
- luna-pipeline-content ✗
- luna-viral-content ✗
- (others not inspected in detail but likely affected)

**Fix required: Batch update all Supabase-referencing workflows to use $env or the new URL.**

---

## 6. SKILLS

Installed in ~/.openclaw/skills/ (11):
ai-humanizer, clawddocs, content-automation-engine, luna-core-agent, luna-memory-system,
n8n-workflow-automation, qmd, theme-factory, web-artifacts-builder, web-search-exa, xurl

Installed in ~/.openclaw/workspace/skills/ (15):
3d-animation-creator, ai-humanizer, apg, clawddocs, image-generator, luna-core-agent,
n8n-workflow-automation, seo-strategy, skill-creator, theme-factory, web-artifacts-builder,
web-search-exa, website-intelligence, xurl, youtube-full

**Issue: Duplicate skills across two directories. Some only in workspace/skills, some only in skills/.
Consider consolidating to one canonical location.**

---

## 7. MCP SERVERS

| Server | URL | Status |
|--------|-----|--------|
| exa | https://mcp.exa.ai/mcp | Remote — needs EXA_API_KEY in env |
| n8n | http://127.0.0.1:3456/mcp | Local — duplicate with n8n-gateway |
| n8n-gateway | http://localhost:3456/mcp | Local — duplicate with n8n |
| transcriptapi | https://transcriptapi.com/mcp | Remote — needs TAPI_KEY |

**Fix: Remove n8n duplicate. Verify EXA_API_KEY and TAPI_KEY are set in env.**

---

## 8. MEMORY INTEGRITY

Daily logs: Present through April 2, 2026
MEMORY.md: Exists but has stale references (CRIT-002, CRIT-006)
Learnings: ERRORS.md (1.5KB), LEARNINGS.md (1.3KB), BENCHMARK.md (28KB), PATCHES.md (10.7KB)
Qdrant collections: 10 active (design_assets, luna_memory, market_intel, luna_learnings, agent_outputs, tutorials, code_snippets, memories, pixc_builds, memory_migrations)
Neo4j: Running and reachable
Ollama embeddings: nomic-embed-text loaded

**Memory system is structurally healthy but contains stale data in curated files.**

---

## 9. SESSION FORENSICS

From the pasted prior session context:
- Session was on gpt-5.4 before this audit
- Previous session attempted Opus override and was blocked by policy
- The config edit in this session fixed the model allowlist
- Prior n8n restore work (March 27) left workflows in a partially-wired state
- Multiple Atlas dispatches timed out during the March 27 restore
- The SQLite READONLY error during n8n restart was likely caused by permission issues during Atlas's Docker container manipulation

**Key lesson: Atlas subagent runs kept timing out because the 5-minute limit was too short for Docker+n8n manipulation tasks. Consider increasing runTimeoutSeconds for infra tasks to 600-900s.**

---

## 10. PHASED REMEDIATION PLAN

### Phase 1: Data integrity (do first, blocks everything)
1. Fix all n8n workflows with hardcoded old Supabase URLs/keys → batch update to new ref
2. Update MEMORY.md Supabase references to live project
3. Decide on content engine tables (create missing ones or update docs)
4. Verify n8n container has correct SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in its runtime env

### Phase 2: Security (do second)
5. Move GitHub PAT from crontab to secure credential file
6. Audit and rotate any other exposed secrets in workspace files
7. Reduce personality sync cron from 5min to 15-30min

### Phase 3: Documentation alignment (do third)
8. Update TOOLS.md routing matrix to Phase-1 agent names
9. Update SOUL.md routing references to Phase-1 agent names
10. Update MEMORY.md model routing to reflect current Opus-4-6 primary
11. Consolidate duplicate skills directories

### Phase 4: Verification (do last)
12. Smoke-test 3 Supabase-dependent workflows end-to-end
13. Verify scheduled workflows fire correctly (morning-brief, cost-audit, night-shift, ai-intel)
14. Confirm MCP servers are reachable
15. Run full qmd reindex after doc updates

---

## AUDIT COMPLETE
Generated: April 2, 2026 23:17 UTC
Model: anthropic/claude-opus-4-6
Next weekly audit: April 9, 2026
