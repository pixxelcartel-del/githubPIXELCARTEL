# Scroll-Triggered Asset Generation Doctrine

Date: 2026-04-02
Owner: Luna
Source basis:
- TZUTe7s11-I
- nhibi9TRgNc
- csOEsfiBfvo
- pending fetch: ZfYvv-0l9NA

## What the scraped tutorials are actually teaching

### 1. Plan from references first, not from blank prompts
Use:
- mood boards
- benchmark websites
- Dribbble / Awwwards / Spline community references
- extracted brand cues

### 2. Asset generation is staged
The correct sequence is:
- extract brand / visual direction
- create image prompts first
- generate 2D/hero visuals first
- then generate motion/3D layer from approved image direction
- only then wire into site sections

### 3. Anti-gravity / cloud-code style lesson
The real leverage is not just raw generation.
It is building reusable skills/SOPs that:
- generate prompts
- place assets into known slots
- publish automatically
- reuse the same pipeline across projects

### 4. Spline / 3D lesson
Use 3D only where it increases perceived premium quality.
Do not overuse it.
For premium sites:
- 1 hero motion moment
- 1 process/capability accent
- restrained motion everywhere else

### 5. Scroll-triggered build lesson
The website should have pre-decided motion slots before asset generation completes.
Structure first, assets second, motion wiring third.
This avoids redesign loops.

## Required pipeline for scroll-triggered asset generation
1. Benchmark extraction
2. Brand/mood board extraction
3. Asset prompt sheet
4. Two image generations
5. One motion generation based on approved image direction
6. Structural site integration into pre-wired slots
7. Performance/lighthouse audit
8. Deploy

## Minimum skills/SOPs implied by the tutorials
- asset-prompt-sheet generator
- scroll-triggered asset generation runner
- spline/3d reference routing SOP
- anti-gravity style website build SOP
- deploy/publish SOP

## Routing implications
- Sun Tzu: planning sequence, benchmark extraction, routing decisions
- Mark: site structure, layout, asset slotting, final visual integration
- Elon: generation runners, automation, deployment plumbing
- A: security/perf/compliance audit
- Ernest: compressed handoff summaries

## Do not do
- do not generate motion before still direction is approved
- do not redesign site structure after asset generation unless absolutely necessary
- do not use generic AI fluff copy as a substitute for benchmarked layout decisions
