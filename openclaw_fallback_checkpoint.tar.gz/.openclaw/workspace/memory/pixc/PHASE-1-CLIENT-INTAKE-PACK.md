# Phase 1 — PixC Client Intake Pack

## 1) Short Intake Message

Hi — I’ll handle the research, planning, and build flow for your new website.

To get started fast, send me the items below. Once I have them, I’ll run Phase 1: brand extraction, competitor analysis, build brief, and a proposed direction. I will stop for approval before the final build starts.

Please send:
- business name
- current website URL (or say “no site yet”)
- what you sell
- who you sell to
- your main goal for the website
- your preferred call to action
- logo + brand assets if you have them
- any colors / style references you like
- whether you want a scroll animation / 3D hero section

Once that’s in, I’ll take it from there.

---

## 2) Complete Intake Questionnaire

### A. Business Basics
- Business / brand name
- Main contact name
- Best contact channel
- Industry / niche
- Location / service area
- Do you already have a live website? If yes, share the URL.
- If no website exists, do you have a deck, brochure, Notion page, Google Doc, or pasted copy I can use as source material?

### B. Offer + Audience
- What exactly do you sell?
- What is the primary offer you want this website to push?
- Who is the target customer?
- What problem do you solve for them?
- Why do clients choose you over alternatives?
- What is the single most important action you want visitors to take?
- Secondary CTA, if any?

### C. Website Goal
- What is the main job of this site?
  - book calls
  - generate leads
  - drive quote requests
  - sell a product
  - validate premium positioning
  - showcase work
  - other
- What would make this project a win in 30 days?
- What would make it a win in 90 days?

### D. Brand Assets
- Logo file available? SVG preferred, PNG acceptable
- Brand colors, if any
- Fonts, if any
- Brand guidelines, if any
- Tagline / headline currently used
- Any photography, videos, testimonials, case studies, or before/after assets available?
- Any competitor or inspiration sites you love?
- Any sites or styles you do not want copied?

### E. Messaging + Trust Signals
- Core value proposition in one sentence
- Top 3 services / products to highlight
- Testimonials available?
- Review platform links available? Google, Trustpilot, G2, etc.
- Certifications, awards, memberships, guarantees, partner badges?
- FAQs you want answered on the site?

### F. Content + Pages
- What pages do you already know you need?
- Do you have existing copy that must stay?
- Do you want me to rewrite the copy if the market data shows a better direction?
- Any legal pages required? Privacy, terms, disclaimers
- Do you need blog / SEO pages now, or later?

### G. Technical / Ops
- Domain already owned?
- Hosting preference? Vercel, Netlify, VPS, or no preference
- Existing analytics / tracking required?
- Existing CRM / forms / booking system to connect?
- Email / contact form destination
- Any platform or stack constraints?

---

## 3) Fast-Path Intake for Warm Leads

If speed matters, send just this:
- business name
- website URL or source doc
- offer
- target customer
- city / service area
- main CTA
- logo
- preferred style / vibe
- 2 competitor sites
- whether you want a premium animated hero
- any non-negotiables

That is enough to start Phase 1 research and planning.

---

## 4) Exact Inputs Needed Before Website-Intelligence Starts

These are the minimum required inputs before the research + build brief flow starts:
- client / brand name
- current website URL or alternate content source
- niche / market
- target audience
- primary business goal
- primary CTA
- logo or confirmation that none exists yet
- baseline brand direction: colors, vibe, references, or “open to recommendation”
- preferred pages or confirmation that site architecture should be recommended from research

Without these, the research can begin loosely, but the build brief will be weaker and likely create rework.

---

## 5) Exact Inputs Needed Before 3D Animation Work Starts

These are required before scroll-animation / 3D hero production starts:
- brand / product name
- logo file if available
- accent color
- background color
- overall vibe: premium tech, luxury, playful, minimal, bold, etc.
- content source: URL or pasted copy
- whether testimonials should be included
- whether confetti should be included
- whether card-scanner / particle section should be included

### If Using a Video File
- video file itself
- confirmation that the first frame is on a white background
- confirmation the clip is short enough for scroll control
- confirmation whether the site should use 350vh baseline scroll height or be adjusted toward 500vh cinematic / 250vh tighter

### If Generating Assets Instead of Using a Video
- object / subject to animate
- whether this is a product deconstruction or a before/after transformation
- desired hero direction
- desired end-state direction
- important components / details / before-after elements to preserve
- final preferred generation defaults:
  - image generation: Higgsfield, 16:9, 2K, 4 generations
  - video generation: Kling 3.0, 1080p

---

## 6) Exact Inputs Needed Before Image-Generator / AntiGravity Asset Work Starts

- what object or subject is being visualized?
- is this a product with internal components, or a transformation / service outcome?
- what should Prompt A show? assembled / before state
- what should Prompt B show? exploded / after state
- what material / visual details must remain consistent?
- what angle should the object be shown from?
- what brand cues should be preserved?
- any forbidden elements? text, logos, clutter, non-white background, etc.

If the client cannot answer this clearly, default to a simpler premium hero instead of forcing a weak 3D concept.

---

## 7) Internal Luna Intake Notes

Before moving from intake into execution, confirm:
- Is the source content real and sufficient?
- Is the CTA clear?
- Is the target audience specific?
- Is there enough trust material to make the site believable?
- Is the client asking for animation because it helps conversion, or just because it looks cool?
- Is the 3D concept actually aligned with the business?
- Is there enough visual input to avoid wasting generations on guesswork?

If 3 or more of those are weak, hold the build and tighten intake first.

---

## 8) Approval Checkpoint Message

Before the build starts, the client must approve the strategy direction.

Use this:

I’ve finished the research and build brief.

Next I’ll move into the actual website build, but this is the checkpoint where direction changes are still cheap. Please review the proposed structure, design direction, messaging, and CTA strategy. Once you approve it, I’ll proceed into the build.

Reply with one of these:
- Approved — build it
- Approved with edits — followed by your changes
- Hold — I want to adjust direction first

No final build starts before this approval.

---

## 9) Copy-Paste Client Intake Template

Hi — to build this properly, send me the following in one message if possible:

- Business name
- Website URL or source doc
- What you sell
- Who you sell to
- Main goal of the website
- Primary CTA
- Service area / location
- Logo and brand assets
- Preferred colors / vibe / references
- Testimonials / reviews / proof
- Top competitors or similar sites
- Whether you want a premium animated / scroll-driven hero
- Any non-negotiables

After that, I’ll do the research, competitor analysis, and build brief first.
I’ll stop for your approval before the full website build starts.
