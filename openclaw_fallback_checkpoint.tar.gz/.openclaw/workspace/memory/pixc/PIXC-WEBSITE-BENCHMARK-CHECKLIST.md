# PixC Website — Final Output Benchmark Checklist
Date: 2026-04-05 | Version: 1.0
Owner: Luna | Used by: Mark (build), Elon (tech audit), Sun Tzu (final approval)
Pass threshold: >98% (≥49/50 checks passing before deploy is permitted)

---

## SECTION A — Performance (10 points)
- [ ] Lighthouse Performance score ≥ 95 (desktop)
- [ ] Lighthouse Performance score ≥ 90 (mobile)
- [ ] LCP (Largest Contentful Paint) < 2.5s
- [ ] CLS (Cumulative Layout Shift) < 0.1
- [ ] FID / INP < 200ms
- [ ] Total page weight < 2MB uncompressed
- [ ] Images in WebP format with lazy loading
- [ ] Fonts preloaded with display:swap
- [ ] No render-blocking scripts in <head>
- [ ] TTFB < 600ms on Vercel edge

## SECTION B — SEO (10 points)
- [ ] Single H1 per page, logical H2/H3 hierarchy
- [ ] Meta title: 50–60 chars, includes "PixC"
- [ ] Meta description: 150–160 chars, includes CTA
- [ ] robots.txt present and correct (index,follow)
- [ ] sitemap.xml present with canonical URL
- [ ] canonical <link> tag in <head>
- [ ] OG tags complete (title, description, image, url)
- [ ] Twitter card tags complete
- [ ] All images have descriptive alt text
- [ ] No broken internal links

## SECTION C — Design Quality (10 points)
- [ ] AntiGravity 5-Dimension framework applied (Pattern, Style, Color, Motion, Copy)
- [ ] Dark mode, #050816 background or equivalent
- [ ] WCAG AA contrast ratio ≥ 4.5:1 on all body text
- [ ] Consistent spacing: 8px grid system
- [ ] No more than 2 font families
- [ ] No more than 3 primary colors
- [ ] All animations use transform/opacity only (GPU)
- [ ] Animations ≤ 300ms for UI interactions
- [ ] prefers-reduced-motion media query implemented
- [ ] No hamburger menu on desktop

## SECTION D — Mobile & Accessibility (10 points)
- [ ] Fully responsive: 320px → 1920px
- [ ] Mobile CTA visible above fold
- [ ] Touch targets minimum 44×44px
- [ ] No horizontal scroll on mobile
- [ ] Focus states visible on all interactive elements
- [ ] No auto-playing audio/video
- [ ] Form inputs have associated <label> elements
- [ ] Skip navigation link present
- [ ] Semantic HTML: nav, main, section, footer used correctly
- [ ] Schema markup present (Organization or LocalBusiness)

## SECTION E — Content & Trust (10 points)
- [ ] PixC logo in header and footer (real asset, not placeholder)
- [ ] Himel founder photo in Founder section (real asset)
- [ ] No lorem ipsum anywhere
- [ ] Hero headline is specific and benefit-driven
- [ ] Social proof present (numbers, stats, or testimonials)
- [ ] Services clearly described with concrete deliverables
- [ ] Process section with 4+ clear steps
- [ ] FAQ section with ≥5 real objection-handling answers
- [ ] CTA with email capture or contact mechanism
- [ ] Founder/personal trust section humanizes the brand

---

## Scoring
50 checks total. Each = 1 point.
- 50/50 → PERFECT — deploy immediately
- 49/50 → PASS — deploy with note
- 48/50 → CONDITIONAL — fix 2 issues, re-check
- ≤47/50 → FAIL — do not deploy, return to build phase

## Automated Checks (run by Elon via Lighthouse CI)
Sections A + B can be auto-checked via:
  npx lighthouse-ci autorun --url=<preview_url>
Manual checks: Sections C, D, E (Mark + Sun Tzu visual review)

## Final Approval Gate
Sun Tzu reviews checklist score. If ≥49/50 → approves deploy.
If <49/50 → routes specific failures back to Mark/Elon for fix.
Luna reports final score to Himel via Telegram before deploying.
