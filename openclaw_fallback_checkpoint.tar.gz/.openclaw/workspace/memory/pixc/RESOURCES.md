# PixC Resources Tracking

## Purpose
This document is the master indexed resource ledger for PixC and Luna's ultimate modular workflow.
It tracks tutorials, free resources, extracted lessons, where they fit into the workflow, what we adopted, what we rejected, what needs manual download, and how each item improves the current build.

## Operating Rules
- Never let tutorial knowledge stay isolated to one task.
- Merge overlapping tutorials into one best-practice approach per module.
- Track every free resource with source link and intended use.
- Record whether the resource was downloaded, extracted, needs manual action, or is blocked.
- For every useful finding, map it to a module or phase of the workflow.
- Prefer the strongest approach across all tutorials, not the first one we saw.

## Ultimate Modular Workflow Modules
| Module ID | Module | Purpose |
|---|---|---|
| M01 | Intake & Qualification | collect client/business context and required inputs |
| M02 | Site / Brand Extraction | scrape current site, assets, colors, copy, structure |
| M03 | Competitor Intelligence | benchmark top performers and identify patterns |
| M04 | Build Brief & Approval Gate | define structure, messaging, design direction, hard stop |
| M05 | Asset Generation | create prompt sets, images, video transitions, 3D assets |
| M06 | Website Build | implement approved site |
| M07 | QA / Audit | UIUX, SEO, accessibility, performance |
| M08 | Client Portal / Ops | manage changes, requests, approvals, maintenance |
| M09 | Lead Gen / Prospecting | analyze sites/leads and spot opportunities |
| M10 | Knowledge Capture | collect prompts, screenshots, resources, reusable patterns |
| M11 | Automation / Tooling | turn repeated workflows into skills/modules |
| M12 | Business Opportunities | capture adjacent monetization or passive income opportunities |

## Tutorial Index
Purpose: canonical inventory of tutorial/video/course inputs. This starter index preserves current queue state while aligning to the canonical resource system schema.

| tutorial_id | source_key | title | creator | url | cluster_id | primary_module_candidates | stage_focus | format | status | duplicate_of | synthesis_priority | evidence_confidence | key_claim | extraction_state | last_reviewed_utc | notes |
|---|---|---|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|
| tut-youtube-qihxly1eab4 | QiHXlY1EaB4 | Title pending metadata fetch | unknown | https://youtu.be/QiHXlY1EaB4 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-k0j-adbkn9i | K0j_ADBkN9I | Title pending metadata fetch | unknown | https://youtu.be/K0j_ADBkN9I | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-c3-4llqyt8o | C3-4llQYT8o | Title pending metadata fetch | unknown | https://youtu.be/C3-4llQYT8o | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-hj-dwefabss | HJ-dwefABss | Title pending metadata fetch | unknown | https://youtu.be/HJ-dwefABss | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-eh8jdttkida | eH8JdttKIdA | Title pending metadata fetch | unknown | https://youtu.be/eH8JdttKIdA | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from deduplicated queue; prior raw duplicate already collapsed at intake level. |
| tut-youtube-zejxi2mahj0 | ZeJXI2MAhj0 | Title pending metadata fetch | unknown | https://youtu.be/ZeJXI2MAhj0 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-n3o8mganre4 | n3o8MgaNRE4 | Title pending metadata fetch | unknown | https://youtu.be/n3o8MgaNRE4 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-vxylqqxsgx0 | vXylQqxsGX0 | Title pending metadata fetch | unknown | https://youtu.be/vXylQqxsGX0 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-ud7prxjcry0 | uD7prXJCRY0 | Title pending metadata fetch | unknown | https://youtu.be/uD7prXJCRY0 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-1ai7palkz4w | 1aI7pAlkz4w | Title pending metadata fetch | unknown | https://youtu.be/1aI7pAlkz4w | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-wq0duoteaau | wQ0duoTeAAU | Title pending metadata fetch | unknown | https://youtu.be/wQ0duoTeAAU | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-wqh1htka6qg | wqH1hTkA6qg | Title pending metadata fetch | unknown | https://youtu.be/wqH1hTkA6qg | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-tdgiwn0flk8 | tDGiWn0flK8 | Title pending metadata fetch | unknown | https://youtu.be/tDGiWn0flK8 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-tzute7s11-i | TZUTe7s11-I | Title pending metadata fetch | unknown | https://youtu.be/TZUTe7s11-I | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-cnf7uvff11y | cNf7uVff11Y | Title pending metadata fetch | unknown | https://youtu.be/cNf7uVff11Y | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-rp6-d6snyxy | rp6_d6sNYXY | Title pending metadata fetch | unknown | https://youtu.be/rp6_d6sNYXY | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-sk-ssnyj758 | SK_sSNyJ758 | Title pending metadata fetch | unknown | https://youtu.be/SK_sSNyJ758 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-rzar-s4kio | _rZAR-s4KIo | Title pending metadata fetch | unknown | https://youtu.be/_rZAR-s4KIo | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-g-zzj8wgnca | g_zZj8WGncA | Title pending metadata fetch | unknown | https://youtu.be/g_zZj8WGncA | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-q0tgutj6vis | q0TgUtj6vIs | Title pending metadata fetch | unknown | https://youtu.be/q0TgUtj6vIs | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-r2-1c-t6f34 | r2-1c_T6F34 | Title pending metadata fetch | unknown | https://youtu.be/r2-1c_T6F34 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-itkkogd3ycm | iTKkoGd3YcM | Title pending metadata fetch | unknown | https://youtu.be/iTKkoGd3YcM | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-csoesfibfvo | csOEsfiBfvo | Title pending metadata fetch | unknown | https://youtu.be/csOEsfiBfvo | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-nhibi9trgnc | nhibi9TRgNc | Title pending metadata fetch | unknown | https://youtu.be/nhibi9TRgNc | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-vpzdfa0t7w | _vPzDfA0t7w | Title pending metadata fetch | unknown | https://youtu.be/_vPzDfA0t7w | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-bhphwvsrto0 | bhPHwVsrTo0 | Title pending metadata fetch | unknown | https://youtu.be/bhPHwVsrTo0 | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |
| tut-youtube-ktagjnwvimq | KtAGjnWViMQ | Title pending metadata fetch | unknown | https://youtu.be/KtAGjnWViMQ | clu-needs-metadata | mod-resource-ingestion-and-synthesis | M10, M11 | video | queued |  | 3 | low | Unknown until metadata/title/description/transcript review. | none | 2026-03-29T22:54:00Z | Imported from raw queue; pending topic classification. |

## Free Resource Index
This section tracks free templates, prompts, repos, docs, tools, asset packs, and guides discovered from tutorials or direct research.

| resource_id | name | resource_type | is_free | source_origin | direct_link | related_tutorial_ids | module_ids | intended_use | adaptation_summary | status | access_method | license_or_usage_notes | manual_action_required | linked_manual_queue_id | last_validated_utc | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Manual-Download Queue
This section tracks items Luna identified but cannot fetch, unlock, or complete without Himel.

| queue_id | item_name | linked_resource_id | linked_tutorial_id | source_link | blocker_type | why_it_matters | luna_attempted | required_himel_action | priority | downstream_module_ids | status | requested_utc | resolved_utc | resolution_notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Screenshot Extraction Queue
This section tracks visual-only tutorial moments where useful knowledge is shown on screen but not captured in text.

| queue_id | tutorial_id | timestamp_range | visible_item_type | visible_content_summary | reason_capture_needed | extraction_method | target_module_ids | priority | status | extracted_result | created_utc | completed_utc | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Workflow Adaptation Log
This section records how raw tutorial/resource knowledge is translated into PixC workflow defaults, module rules, or operating changes.

| adaptation_id | topic | source_tutorial_ids | source_resource_ids | target_module_ids | previous_default | evaluated_options | chosen_approach | decision | why_chosen | tradeoffs | implementation_rule | confidence | supersedes_adaptation_id | created_utc | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| wal-scroll-pacing-defaults-v1 | Scroll pacing defaults | tut-jack-roberts-antigravity-basics |  | mod-premium-scroll-hero-system | Not previously normalized in this ledger. | Tutorial-derived pacing ranges for tighter vs baseline vs cinematic scroll systems. | 350vh baseline, 500vh cinematic, 250vh tighter. | adopted | Already captured as an active default in existing notes and aligned to premium scroll hero execution. | Exact pacing may need future review against additional tutorials. | Use 350vh as baseline, 500vh for cinematic sequences, and 250vh for tighter scroll sections unless later synthesis replaces it. | medium |  | 2026-03-29T22:54:00Z | Preserved from existing adopted defaults. |
| wal-image-generation-defaults-v1 | Image generation defaults | tut-jack-roberts-antigravity-basics |  | mod-prompted-asset-generation | Not previously normalized in this ledger. | Existing recorded generation settings. | Higgsfield, 16:9, 2K, 4 generations. | adopted | Already captured as a current best default in existing notes. | Tool-specific and may be superseded by stronger evidence later. | Default image generation to Higgsfield at 16:9, 2K, 4 generations unless cluster synthesis updates the rule. | medium |  | 2026-03-29T22:54:00Z | Preserved from existing adopted defaults. |
| wal-video-generation-defaults-v1 | Video generation defaults | tut-jack-roberts-antigravity-basics |  | mod-prompted-asset-generation | Not previously normalized in this ledger. | Existing recorded video generation settings. | Kling 3.0 at 1080p. | adopted | Already captured as a current best default in existing notes. | Tool-specific and may be superseded by stronger evidence later. | Default video generation to Kling 3.0 at 1080p unless cluster synthesis updates the rule. | medium |  | 2026-03-29T22:54:00Z | Preserved from existing adopted defaults. |
| wal-client-change-handling-defaults-v1 | Client change handling defaults | tut-jack-roberts-antigravity-basics |  | mod-client-portal-change-model | Not previously normalized in this ledger. | Existing recorded post-launch handling model. | Portal model preferred. | adopted | Existing ledger already selected the portal model. | Specific implementation details are not yet fully defined here. | Prefer a portal-based client change-request model until stronger operational synthesis replaces it. | medium |  | 2026-03-29T22:54:00Z | Preserved from existing adopted defaults. |
| wal-final-audit-defaults-v1 | Final audit defaults | tut-jack-roberts-antigravity-basics |  | mod-uiux-pro-max-qa | Not previously normalized in this ledger. | Existing recorded QA gate. | UIUX Pro Max mandatory. | adopted | Existing ledger already treats this as mandatory. | Audit standard details still need deeper synthesis. | Apply UIUX Pro Max as a mandatory final audit gate for relevant PixC outputs unless superseded later. | medium |  | 2026-03-29T22:54:00Z | Preserved from existing adopted defaults. |

## Opportunity Log
This section captures adjacent monetization, automation, tooling, service, or product opportunities discovered during resource analysis.

| opportunity_id | title | trigger_source | category | description | why_it_matters | estimated_value | setup_cost | related_module_ids | recommended_next_step | owner | status | created_utc | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Module Mapping
This section ties source tutorials/resources/adaptations to reusable PixC modules.

| mapping_id | module_id | module_name | module_lifecycle | source_type | source_id | source_role | contribution_type | extracted_pattern | adopted_for_pixc | adoption_notes | superseded_by_module_id | last_updated_utc |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| map-wal-scroll-pacing-defaults-v1-mod-premium-scroll-hero-system | mod-premium-scroll-hero-system | Premium Scroll Hero System | candidate | adaptation | wal-scroll-pacing-defaults-v1 | primary | scroll-pacing | 350vh baseline, 500vh cinematic, 250vh tighter. | true | Preserved from existing adopted defaults; needs broader synthesis against future tutorial cluster evidence. |  | 2026-03-29T22:54:00Z |
| map-wal-image-generation-defaults-v1-mod-prompted-asset-generation | mod-prompted-asset-generation | Prompted Asset Generation | candidate | adaptation | wal-image-generation-defaults-v1 | primary | image-generation-defaults | Higgsfield, 16:9, 2K, 4 generations. | true | Preserved from existing adopted defaults; subject to later cluster review. |  | 2026-03-29T22:54:00Z |
| map-wal-video-generation-defaults-v1-mod-prompted-asset-generation | mod-prompted-asset-generation | Prompted Asset Generation | candidate | adaptation | wal-video-generation-defaults-v1 | secondary | video-generation-defaults | Kling 3.0 at 1080p. | true | Preserved from existing adopted defaults; subject to later cluster review. |  | 2026-03-29T22:54:00Z |
| map-wal-client-change-handling-defaults-v1-mod-client-portal-change-model | mod-client-portal-change-model | Client Portal Change Model | candidate | adaptation | wal-client-change-handling-defaults-v1 | primary | change-request-model | Portal model preferred. | true | Preserved from existing adopted defaults; implementation detail still incomplete. |  | 2026-03-29T22:54:00Z |
| map-wal-final-audit-defaults-v1-mod-uiux-pro-max-qa | mod-uiux-pro-max-qa | UIUX Pro Max QA | candidate | adaptation | wal-final-audit-defaults-v1 | primary | final-audit-gate | UIUX Pro Max mandatory. | true | Preserved from existing adopted defaults; QA standard still needs fuller definition. |  | 2026-03-29T22:54:00Z |

## Current Core Adopted Defaults
| Topic | Current Best Default | Source / Rationale |
|---|---|---|
| Image generation | Higgsfield, 16:9, 2K, 4 generations | Preserved from existing ledger; normalized into `wal-image-generation-defaults-v1` |
| Video generation | Kling 3.0 at 1080p | Preserved from existing ledger; normalized into `wal-video-generation-defaults-v1` |
| Scroll pacing | 350vh baseline, 500vh cinematic, 250vh tighter | Preserved from existing ledger; normalized into `wal-scroll-pacing-defaults-v1` |
| Client change handling | portal model preferred | Preserved from existing ledger; normalized into `wal-client-change-handling-defaults-v1` |
| Final audit | UIUX Pro Max mandatory | Preserved from existing ledger; normalized into `wal-final-audit-defaults-v1` |

## Cluster Notes
Starter cluster routing converted from the triage batch into canonical `clu-` naming. These are provisional until metadata is fetched.

| cluster_id | cluster_name | theme | target_module_ids | priority | reason_this_cluster_matters |
|---|---|---|---|---|---|
| clu-website-build-design-systems | Website Build / Design Systems | likely high-value for PixC build quality and implementation | mod-website-build-stack-selection | high | Likely to improve implementation quality and downstream build consistency. |
| clu-asset-generation-3d-visual-prompting | Asset Generation / 3D / Visual Prompting | directly affects hero assets, AntiGravity outputs, image/video generation | mod-premium-scroll-hero-system, mod-3d-video-frame-sequence, mod-prompted-asset-generation | high | Directly impacts Phase 1 asset quality and premium visual output. |
| clu-scraping-research-competitive-intel | Scraping / Research / Competitive Intel | strengthens discovery, benchmarking, and automation | mod-brand-and-site-extraction, mod-competitor-intelligence-reporting, mod-resource-ingestion-and-synthesis | high | Improves research quality, benchmarking, and system leverage. |
| clu-qa-seo-audit | QA / SEO / Audit | directly improves deliverable quality and conversion readiness | mod-uiux-pro-max-qa | high | Protects output quality and final approval readiness. |
| clu-automation-tooling-agent-workflows | Automation / Tooling / Agent Workflows | improves throughput and reusable system leverage | mod-resource-ingestion-and-synthesis | medium | Helps turn repeated work into durable system capability. |
| clu-client-ops-portal-cms-change-requests | Client Ops / Portal / CMS / Change Requests | supports client management model and post-build workflow | mod-client-portal-change-model | medium | Important for post-launch process quality and change handling. |
| clu-outreach-lead-gen-bad-site-detection | Outreach / Lead Gen / Bad Site Detection | useful for demand generation after PixC core system is stable | mod-opportunity-capture | medium | Useful for pipeline growth once core delivery workflow is stable. |
| clu-socials-content-systems | Socials / Content Systems | second-priority lane per routing guidance | mod-opportunity-capture | low | Lower priority unless strong cross-system leverage appears. |
| clu-business-models-monetization-opportunity | Business Models / Monetization / Opportunity | capture adjacent scalable income or productized service ideas | mod-opportunity-capture | medium | Preserves scalable adjacent ideas discovered during research. |
| clu-needs-metadata | Misc / Needs Metadata | temporary holding bucket when topic cannot be safely inferred | mod-resource-ingestion-and-synthesis | high | Required intake bucket before real classification and synthesis. |

## Planned Next Actions
1. Run a metadata/title/description/resource-link pass across all queued tutorials.
2. Reclassify each `tut-youtube-*` row out of `clu-needs-metadata` once topic evidence exists.
3. Add free-resource rows immediately when tutorial descriptions or transcripts reveal links.
4. Create manual-download and screenshot queue entries only when real blockers or visual-only dependencies are observed.
5. Promote synthesized tutorial findings into adaptation log entries and module mappings instead of storing competing parallel notes.
