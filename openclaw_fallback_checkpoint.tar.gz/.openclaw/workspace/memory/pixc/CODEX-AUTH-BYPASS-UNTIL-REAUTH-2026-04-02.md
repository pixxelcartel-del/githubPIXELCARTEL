# Codex Auth Bypass Until Re-Auth

Date: 2026-04-02
Status: temporary live workaround

## Root cause
Fresh delegated runs are currently failing because OpenAI Codex OAuth refresh is broken.
Observed live error:
- refresh_token_reused
- OAuth token refresh failed for openai-codex

## Secondary issue
Legacy fallback entries like openai-codex:default and openai-codex:orangeducky01+gg are being treated as model candidates in fallback logs, which creates noisy invalid fallback attempts.

## Temporary runtime workaround
Until Codex is re-authenticated:
- delegated execution lanes should avoid Codex-primary startup
- Sonnet becomes the temporary live primary for Elon and Mark
- Haiku remains the cheap fallback
- direct main chat can remain on GPT-5.4

## Intended steady state after re-auth
- Sonnet for planning/orchestration/research/analysis/decision work
- Codex for direct coding/debugging/implementation
- Haiku for cheap background work

## Resume rule
Use the temporary Sonnet-primary workaround now so the phase sequence can continue.
After Codex re-auth, restore Elon/Mark Codex-primary live routing if still desired.
