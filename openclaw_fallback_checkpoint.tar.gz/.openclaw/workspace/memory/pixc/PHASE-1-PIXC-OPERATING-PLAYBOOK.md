# PHASE 1 — PixC Website Delivery Operating Playbook

**Purpose:** Execution-grade operating system for Luna to deliver Phase 1 PixC websites from intake to handoff using Luna/OpenClaw-native workflows.

**Scope:** Planning + delivery workflow only. Do not start building until the approval checkpoint is cleared.

**Phase 1 objective:** Turn PixC website projects into a repeatable, premium, research-backed, fast-delivery pipeline that produces animated, high-conversion websites with clear approval gates, strong QA, and post-launch client control via portal.

---

## 0. Core Operating Rules

1. **Research first. Never design blind.** Every site begins with brand extraction + competitor analysis.
2. **Approval checkpoint is mandatory.** No asset generation or build starts before the brief is explicitly approved.
3. **Use Luna-native automation, not manual tutorial behaviors.** Replace actions like “drag folder into AntiGravity” with structured prompts, generated files, scripted extraction, and saved deliverables.
4. **Default build quality = premium.** Apple/Stripe/Awwwards feel; never template-grade.
5. **Animation must stay performant.** Transform/opacity only, reduced-motion support always, no decorative excess.
6. **Portal is the preferred client change model.** Do not default to retainer-only or full CMS handoff.
7. **UIUX Pro Max audit is mandatory at the end of every site.** No exceptions.

---

## 1. Standard Delivery Architecture

For each client, create a project workspace:

```text
memory/pixc/clients/[client-slug]/
├── intake/
│   └── 01-intake.md
├── research/
│   ├── 01-client-brand.md
│   ├── 02-competitor-analysis.md
│   ├── 03-build-brief.md
│   └── 04-quality-audit.md
├── assets/
│   ├── copy/
│   ├── images/
│   ├── video/
│   ├── sequence/
│   └── prompts/
├── site/
├── portal/
├── handoff/
└── competitive-analysis.html
```

**Naming standard:** lowercase kebab-case for folder and file names.

---

## 2. Intake Protocol

### 2.1 Intake Data Luna Must Collect

Capture these in `intake/01-intake.md`:

- Client name
- Business type / offer
- Primary website goal
- Primary CTA
- Secondary CTA
- Target audience
- Geography / service area
- Budget band
- deadline / launch target
- Existing website URL
- Brand assets available (logo, fonts, colors, photos, videos)
- Whether 3D scroll asset is desired
- Whether portal access is needed post-launch
- Whether testimonials/case studies exist
- Whether copy exists or must be generated
- Any compliance constraints
- Any reference sites the client likes or hates

### 2.2 Intake Decision Logic

After intake, Luna classifies project into one of three build types:

1. **Research-led premium brochure site** — default
2. **Scroll-stop hero / AntiGravity site** — when a cinematic hero animation is central to value
3. **3D/video-driven showcase site** — when the client has or needs motion-first product storytelling

### 2.3 Immediate Output

At intake completion, Luna writes:

- project scope summary
- recommended build type
- known missing inputs
- risk flags
- next step = research

---

## 3. Research Protocol

Use `website-intelligence` as the backbone.

### 3.1 Brand Extraction

Luna must:

1. scrape/map the current client website
2. extract:
   - logo sources
   - primary/secondary/accent colors
   - fonts
   - tone of voice
   - headline/tagline/value proposition
   - existing page structure
   - reusable content blocks
3. save to `research/01-client-brand.md`

### 3.2 Competitor Analysis

Luna must:

1. identify top 10 niche competitors
2. score each using the 8 criteria:
   - search visibility
   - review quality
   - visual design
   - mobile responsiveness
   - content depth
   - social proof
   - CTA strategy
   - page speed
3. deep-scrape top 5 competitors
4. extract:
   - positioning patterns
   - visual patterns
   - content architecture
   - conversion patterns
   - SEO gaps
5. save to `research/02-competitor-analysis.md`
6. generate `competitive-analysis.html` as client-facing artifact

### 3.3 SEO Direction

Use `seo-strategy` logic inside the build brief even if a full audit is not commissioned.

Luna must extract:

- primary keyword targets
- secondary keywords
- 20–40 LSI keywords
- competitor heading patterns
- content gaps and trust terms
- location modifiers if relevant

These feed the homepage and core page copy structure.

---

## 4. Build Brief Protocol

This is the master planning document. Save to `research/03-build-brief.md`.

### 4.1 The Brief Must Lock

#### A. Design Direction
Using the AntiGravity 5-Dimensions Framework:

1. **Pattern & Layout**
   - choose exact page pattern by business type
2. **Style & Aesthetic**
   - choose one dominant visual style only
3. **Color & Theme**
   - define refined palette with hex values
4. **Typography**
   - heading/body pair
5. **Animations & Interactions**
   - exact motion rules, hover style, reveal style, scroll behavior

#### B. Site Architecture
Define:

- exact pages
- purpose of each page
- section order per page
- nav structure
- footer structure
- primary and secondary CTA placement

#### C. Copy Framework
Define:

- 3 homepage headline options
- positioning statement
- section-level content direction
- proof requirements
- trust signal plan
- SEO keyword placement plan

#### D. Asset Plan
Define whether the project needs:

- standard brand imagery
- generated static visuals
- generated video assets
- AntiGravity sequence
- 3D scroll sequence from source video

#### E. Build Stack Recommendation
Choose one:

- **Next.js 14 + Tailwind + Framer Motion + Canvas** for premium AntiGravity builds
- **HTML/CSS/JS + GSAP/ScrollTrigger** for lighter premium builds
- **Canvas-based video-sequence site** for 3D animation creator workflows

#### F. Constraints / Do-Not-Do
Include anti-pattern list relevant to this client.

---

## 5. Hard Stop Approval Gate

After the brief is done, Luna must stop and request approval.

### Required approval message structure

Luna presents:

- chosen build direction
- page architecture
- visual direction
- animation direction
- content/SEO strategy
- asset plan
- delivery model (including portal)

Then ask exactly:

**“This is the locked build brief. Once approved, I’ll move into asset generation and build execution. Ready to build?”**

### Rules

- No image generation before approval
- No video generation before approval
- No code build before approval
- If client requests major changes, update `03-build-brief.md` first, then ask again

---

## 6. Asset Generation Protocol

Only starts after approval.

### 6.1 Decide Asset Mode

#### Mode A — Static brand/site imagery
Use when a premium site is needed without cinematic hero sequence.

#### Mode B — AntiGravity 3-asset pipeline
Use when a deconstruction/transformation hero is central.

#### Mode C — 3D scroll video pipeline
Use when a source video or generated video will drive frame-sequence scrolling.

---

### 6.2 AntiGravity Asset Workflow

Use `image-generator` methodology but package it as Luna-native execution.

#### Luna must generate and save three prompt files:

- `assets/prompts/prompt-a-assembled.md`
- `assets/prompts/prompt-b-deconstructed.md`
- `assets/prompts/prompt-c-transition-video.md`

#### Prompt standards

- images: **16:9 default**
- Higgsfield defaults: **16:9, 2K, 4 generations**
- video generation default: **Kling 3.0, 1080p**
- white-background source generation when using image-generator methodology
- consistent camera angle, lighting, and materials across prompts

#### Asset requirements

1. **Start frame / assembled**
2. **End frame / exploded or transformed**
3. **Transition video**

#### Luna-native replacement for manual AntiGravity actions

Instead of manual folder drag/drop:

1. store approved prompt set in `/assets/prompts/`
2. generate or coordinate external generations using those locked prompts
3. save final files to:
   - `assets/images/start-frame.*`
   - `assets/images/end-frame.*`
   - `assets/video/transition.*`
4. if video is approved for scroll use, extract frames into `assets/sequence/`
5. normalize naming: `frame_0001.jpg` onward
6. ensure background color consistency with site canvas background

---

### 6.3 3D Animation Creator Workflow

Use when the hero depends on a motion file.

#### Intake fields required before this path

- brand name
- logo
- accent color
- background color
- vibe
- content source
- optional testimonials
- optional card scanner / confetti

#### Video standards

- default model: **Kling 3.0**
- output target: **1080p**
- first frame should be clean and usable as opening scroll state
- frame extraction target: **60–150 frames**
- JPEG over PNG for sequences

#### Scroll tuning defaults

- **350vh** baseline
- **500vh** for slower/cinematic feel
- **250vh** for faster/tighter feel

Luna must record chosen scroll height in the brief and QA notes.

---

## 7. Website Build Protocol

Only begins after approved brief + approved or locked asset plan.

### 7.1 Build Decision Tree

#### Use Next.js + Canvas when:
- AntiGravity sequence is core to the site
- multiple scrollytelling beats are needed
- premium cinematic hero is the value anchor

#### Use HTML/CSS/JS + GSAP when:
- speed matters more than framework overhead
- hero is animated but not canvas-heavy
- brochure site with premium motion is sufficient

#### Use pure canvas sequence site when:
- 3D/video-driven product story is the core experience

---

### 7.2 Build Standards

Every build must include:

- semantic HTML5
- one H1 per page
- metadata and OG tags
- schema markup
- WCAG AA contrast
- reduced-motion support
- mobile-safe interactions
- no hover-only critical UX
- optimized media
- clear file organization

### 7.3 Visual Standards

Luna must enforce:

- one dominant style system
- max 3 primary colors
- max 2 font families
- premium button hover states
- premium card hover states
- purposeful reveal animations
- no long interaction transitions (>300ms)
- no blocking intro gimmicks

### 7.4 Scroll / Motion Standards

- animate only transform/opacity where possible
- use will-change selectively
- debounce scroll work
- use requestAnimationFrame for draw loops
- do not sacrifice clarity for spectacle

### 7.5 Content Injection Rules

Use real copy only:

- client copy
- scraped brand copy
- Luna-written approved copy
- competitor-informed but original content

Never ship lorem ipsum.

---

## 8. QA Protocol

Save findings to `research/04-quality-audit.md`.

### 8.1 QA Layers

#### Layer 1 — Functional QA

Check:

- all nav links
- CTA links/forms
- mobile menu behavior
- frame sequence load
- sticky sections
- breakpoints
- portal links

#### Layer 2 — Visual QA

Check:

- typography consistency
- spacing consistency
- section transitions
- color consistency
- asset edge quality
- background blend with canvas/sequence
- no ugly empty states

#### Layer 3 — Performance QA

Check:

- image weight
- sequence file sizes
- lazy loading
- no render-blocking excess
- no layout shift
- motion smoothness

#### Layer 4 — SEO QA

Check:

- title/meta presence
- heading hierarchy
- keyword placement
- alt text
- schema markup
- robots/sitemap readiness
- OG image and sharing tags

#### Layer 5 — Accessibility QA

Check:

- keyboard access
- focus states
- contrast
- tap target size
- reduced motion handling

#### Layer 6 — UIUX Pro Max Audit

Mandatory final pass on every site:

- confirm the selected design language is executed consistently
- confirm visual sophistication exceeds template grade
- confirm hierarchy, spacing, rhythm, and CTA clarity
- confirm site feels intentional at every breakpoint
- if the audit fails, fix before handoff

---

## 9. Portal Setup Protocol

**Preferred model:** client portal instead of retainer-only or handing over a full CMS by default.

### 9.1 Portal Purpose

Portal gives the client controlled post-launch editing/request capability without degrading the site system.

### 9.2 Portal Setup Must Include

- project summary
- page list
- approved assets repository
- copy repository
- change request intake area
- maintenance/change SLA notes
- launch links
- credentials/instructions if appropriate

### 9.3 Luna’s Delivery Positioning

Frame portal as:

- easier than a CMS
- safer for quality control
- faster for ongoing updates
- structured for premium service

### 9.4 Portal Handoff Package

Store in `/portal/` and `/handoff/`:

- current production URLs
- page inventory
- editable content zones
- change request workflow
- maintenance notes
- support contact path

---

## 10. Handoff Protocol

Handoff is not just “site done.” It must include operational clarity.

### 10.1 Handoff Deliverables

- final approved site build
- audit summary
- launch/readme notes
- portal access/setup
- asset archive
- copy archive
- known limitations
- recommended next optimization steps

### 10.2 Handoff Message Structure

Luna should summarize:

1. what was built
2. what makes it strategically stronger than the previous site / competitor set
3. what assets were created
4. QA completed
5. portal access / next-step workflow
6. what future iteration opportunities exist

---

## 11. Operating Prompt Templates for Luna

### 11.1 Research kickoff prompt

```text
Start a PixC Phase 1 website project.
Create the client workspace, ingest intake data, extract the client brand from their current site, map site structure, identify the top 10 competitors, score them across the 8 website-intelligence criteria, deep-analyze the top 5, extract SEO direction including primary/secondary/LSI keywords, and produce:
- research/01-client-brand.md
- research/02-competitor-analysis.md
- competitive-analysis.html
Then draft research/03-build-brief.md using the AntiGravity 5-Dimensions framework.
Do not start the build.
```

### 11.2 Build brief synthesis prompt

```text
Using the completed research, produce a build brief that locks:
- design direction
- typography
- color system
- animation system
- page architecture
- CTA strategy
- content framework
- asset plan
- recommended stack
- anti-patterns to avoid
Make it decisive, client-ready, and execution-grade.
Stop after the brief and prepare an approval summary.
```

### 11.3 AntiGravity prompt-generation prompt

```text
Generate the approved PixC hero asset prompt set for this project.
Create:
- assembled start-frame prompt
- deconstructed/transformed end-frame prompt
- transition video prompt
Use 16:9 defaults.
For Higgsfield, default to 2K and 4 generations.
For video generation, default to Kling 3.0 at 1080p.
Save prompts into assets/prompts/ and list the intended output filenames.
Do not start site code yet.
```

### 11.4 3D scroll asset prompt

```text
Prepare a 3D scroll-animation asset workflow for this site.
Lock brand name, logo, accent color, background color, vibe, and content source.
If using video generation, default to Kling 3.0 at 1080p.
Define target frame extraction count and recommended scroll height:
- 350vh baseline
- 500vh slower/cinematic
- 250vh faster/tighter
Output the chosen settings and save the asset workflow plan.
```

### 11.5 Final QA prompt

```text
Run final PixC QA across functional, visual, performance, SEO, accessibility, and UIUX Pro Max layers.
Output a pass/fail report with fixes required before handoff.
No handoff if any critical item fails.
```

---

## 12. Completion Criteria

A Phase 1 website project is only considered complete when all are true:

- intake captured
- brand extraction complete
- competitor analysis complete
- build brief approved
- assets generated or approved
- site built
- QA passed
- UIUX Pro Max audit passed
- portal prepared
- handoff package prepared

If any of those are missing, the project is not done.

---

## 13. Short Implementation Checklist

- [ ] Create client workspace and intake file
- [ ] Run brand extraction on current site
- [ ] Run top-10 competitor analysis and deep-scrape top 5
- [ ] Extract SEO direction including 20–40 LSI terms
- [ ] Generate competitive-analysis.html
- [ ] Write build brief using 5-Dimensions framework
- [ ] Pause for explicit approval: “Ready to build?”
- [ ] Generate approved asset prompts/files
- [ ] Build using the correct stack for the project type
- [ ] Run full QA
- [ ] Run mandatory UIUX Pro Max audit
- [ ] Set up portal as preferred change model
- [ ] Prepare handoff package
- [ ] Do not start next phase until all boxes above are closed
