# Tutorial Ingestion Defaults

Date: 2026-04-02
Owner: Luna
Status: canonical default

## Purpose
When Himel drops tutorial links, Luna should not need extra babysitting.
This file defines the default ingestion path.

## Default behavior
1. deduplicate links by video id
2. check whether the tutorial already exists in:
   - skills/youtube-full/results/
   - research distilled packs
   - memory/pixc resources
3. if already covered, route the existing distilled knowledge instead of re-scraping
4. if missing, scrape the missing tutorial only — do not accidentally resume stale backlog queues
5. extract:
   - title
   - transcript or best available text
   - tools/platforms mentioned
   - workflows/settings/prompts
   - reusable resources/platforms
6. route durable lessons to:
   - Mark for website/build patterns
   - Elon for automation/infrastructure/tooling
   - Sun Tzu for orchestration/pipeline structure
   - Ernest for compressed SOPs
7. update PixC resource docs and research mapping

## Resource/platform auto-extraction
If a tutorial mentions platforms like Spline, Dribbble, Awwwards, Behance, Framer, Vercel, Firecrawl, WaveSpeed, Nano Banana, Kling, etc:
- capture them as default usable resources/platforms
- do not leave them buried in transcript text only
- fold them into default routing docs if they affect ongoing website work

## Failure handling
If transcript scraping fails:
- verify the endpoint/path before assuming the video is unavailable
- try direct metadata fetch / fallback extraction
- do not let one missing video block routing of the tutorials already covered
