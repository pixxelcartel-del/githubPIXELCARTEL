# Website Handoff Checklist

Date: 2026-04-02

## Required before handoff
- [ ] Live URL works
- [ ] Header branding/logo placement settled
- [ ] Founder section integrated or slot prepared cleanly
- [ ] Mobile nav/CTA visible
- [ ] Canonical/OG/schema point to live domain
- [ ] robots.txt correct
- [ ] sitemap.xml correct
- [ ] trust/proof density upgraded
- [ ] FAQ/objection layer present
- [ ] final CTA path clear
- [ ] remaining improvements listed separately, not mixed into done state
