# WaveSpeed / Kling / Vercel Implementation Checklist

Status date: 2026-04-02

## 1. Credentials
- [x] WaveSpeed token confirmed in runtime config via alias WAVESPEED_API_TOKEN
- [x] Vercel token confirmed in runtime config via alias VERCEL_API_TOKEN
- [x] Confirm PixC VERCEL_PROJECT_ID
- [~] Confirm PixC VERCEL_ORG_ID (not shown in UI; low-severity pending)
- [x] Generate PixC production Deploy Hook URL
- [x] Store non-secret project metadata in workspace registry

## 2. n8n workflows to build
- [x] wavespeed-image-generate spec written
- [x] wavespeed-video-generate spec written
- [x] vercel-deploy-trigger spec written
- [~] optional result logger / registry updater still not built

## 3. Workflow rules
- [ ] images before video
- [ ] default 2 images first
- [ ] default first video only after image review
- [ ] Nano Banana 2 for images
- [ ] Kling 3.0 Standard first, Pro only if justified
- [ ] Vercel Deploy Hook for routine redeploys

## 4. PixC execution order
- [ ] image 1 — hero website optics
- [ ] image 2 — systems service stack
- [ ] review winner direction
- [ ] short video — calm premium motion
- [ ] optional extra images if budget remains

## 5. Vercel hardening
- [ ] stop relying on interactive device login for routine deploys
- [ ] ensure .vercel project is linked only once
- [ ] create deploy hook immediately after bootstrap
- [ ] document branch/project/domain mapping

## 6. Logs and observability
- [ ] store requestId per generation run
- [ ] classify failures by stage
- [ ] append execution outcome to generation attempt log
- [ ] capture final asset URLs for reuse
