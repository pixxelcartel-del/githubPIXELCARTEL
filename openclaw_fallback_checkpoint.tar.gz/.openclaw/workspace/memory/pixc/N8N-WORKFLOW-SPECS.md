# n8n Workflow Specs — WaveSpeed + Vercel

Date: 2026-04-02
Status: implementation-ready specs

## 1. wavespeed-image-generate

Purpose:
Generate an image through WaveSpeed Nano Banana 2 and return/store the result.

Trigger options:
- manual webhook
- internal execute workflow
- future content-engine stage call

Suggested workflow name:
WAVESPEED — Image Generate

Nodes:
1. Trigger / Webhook
2. Normalize Input (Code)
3. Idempotency Check (optional Data Store / Supabase later)
4. HTTP Request — submit task
5. Wait / polling loop
6. HTTP Request — fetch result
7. If status completed
8. Success formatter
9. Failure formatter
10. Optional logger

Input JSON:
{
  "project": "pixc",
  "generation_id": "pixc-hero-001",
  "prompt": "...",
  "aspect_ratio": "16:9",
  "resolution": "1k",
  "output_format": "png",
  "filename": "pixc-promo-image-01-hero.png"
}

Submit request:
POST https://api.wavespeed.ai/api/v3/google/nano-banana-2/text-to-image
Headers:
- Authorization: Bearer {{$env.WAVESPEED_API_KEY}}
- Content-Type: application/json

Submit body:
{
  "prompt": "={{$json.prompt}}",
  "resolution": "={{$json.resolution || '1k'}}",
  "output_format": "={{$json.output_format || 'png'}}",
  "aspect_ratio": "={{$json.aspect_ratio || '16:9'}}",
  "enable_sync_mode": false,
  "enable_base64_output": false,
  "enable_web_search": false,
  "enable_image_search": false
}

Polling URL:
GET https://api.wavespeed.ai/api/v3/predictions/{{$json.requestId}}/result

Polling rule:
- 8s wait
- max 20 polls
- stop on completed / failed

Success output:
{
  "ok": true,
  "stage": "completed",
  "provider": "wavespeed",
  "model": "google/nano-banana-2/text-to-image",
  "project": "...",
  "generation_id": "...",
  "request_id": "...",
  "result_url": "...",
  "filename": "..."
}

Failure output:
{
  "ok": false,
  "stage": "submit_failed|poll_failed|generation_failed|result_missing",
  "project": "...",
  "generation_id": "...",
  "request_id": "...",
  "error": "..."
}

## 2. wavespeed-video-generate

Purpose:
Generate a short image-to-video clip through WaveSpeed Kling 3.0.

Suggested workflow name:
WAVESPEED — Video Generate

Input JSON:
{
  "project": "pixc",
  "generation_id": "pixc-video-001",
  "model_tier": "std",
  "image_url": "https://...",
  "prompt": "...",
  "negative_prompt": "...",
  "duration": 5,
  "sound": false,
  "cfg_scale": 0.5,
  "shot_type": "customize",
  "filename": "pixc-promo-video-01-calm-assembly.mp4"
}

Endpoint selection:
- std -> https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-std/image-to-video
- pro -> https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-pro/image-to-video

Submit body:
{
  "image": "={{$json.image_url}}",
  "prompt": "={{$json.prompt}}",
  "negative_prompt": "={{$json.negative_prompt || ''}}",
  "duration": "={{$json.duration || 5}}",
  "cfg_scale": "={{$json.cfg_scale || 0.5}}",
  "shot_type": "={{$json.shot_type || 'customize'}}",
  "enable_audio": "={{$json.sound || false}}"
}

Polling rule:
- 15s wait
- max 24 polls
- stop on completed / failed

Success output:
{
  "ok": true,
  "stage": "completed",
  "provider": "wavespeed",
  "model": "kwaivgi/kling-v3.0-std|pro/image-to-video",
  "project": "...",
  "generation_id": "...",
  "request_id": "...",
  "result_url": "...",
  "filename": "..."
}

## 3. vercel-deploy-trigger

Purpose:
Trigger a routine redeploy via Vercel Deploy Hook.

Suggested workflow name:
VERCEL — Deploy Trigger

Input JSON:
{
  "project_slug": "pixc-overnight",
  "reason": "post-polish deploy",
  "deploy_hook_url": "https://api.vercel.com/v1/integrations/deploy/..."
}

Behavior:
1. validate deploy_hook_url present
2. POST to deploy_hook_url
3. store trigger timestamp
4. optionally wait 20-30s
5. optional HTTP GET live production URL for sanity check

Success output:
{
  "ok": true,
  "project_slug": "pixc-overnight",
  "triggered": true,
  "reason": "...",
  "response": "..."
}

Failure output:
{
  "ok": false,
  "project_slug": "pixc-overnight",
  "stage": "hook_missing|trigger_failed|verify_failed",
  "error": "..."
}

## 4. Shared implementation rules
- credentials come from n8n env/credential store, not hardcoded in workflow JSON
- all workflows return structured ok/stage payloads
- all workflows accept generation_id or project_slug for traceability
- all media workflows should append results into the PixC generation log later
- Vercel deploy workflow should never depend on interactive CLI login
