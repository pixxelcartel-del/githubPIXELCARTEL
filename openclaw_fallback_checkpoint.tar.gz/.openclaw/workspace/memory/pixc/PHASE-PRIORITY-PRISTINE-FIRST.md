# Phase Priority — Pristine First

Date: 2026-04-02
Owner: Luna
Status: canonical phase gate

## Non-negotiable phase order
1. Restore system/runtime/delegation path to pristine working condition
2. Codify the website SOP from parsed tutorial corpus and internal best practices
3. Queue and execute website finishing work
4. Polish to handoff quality
5. Only then continue later phases

## Rule
If a hiccup appears during execution:
- fix the hiccup first
- re-validate the lane
- resume the current phase
Do not skip forward with a dirty control plane.

## What pristine means for this run
- live runtime agent roster matches workspace control docs
- subagent default model path is stable
- website deploy path is available
- tutorial-derived SOP is written, not just implied
- resource/platform defaults are documented and reusable
