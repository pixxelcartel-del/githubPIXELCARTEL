# Codex Code Review Preference

Date: 2026-04-02
Owner: Luna
Status: canonical preference

## Rule
For code debugging and code review work, prefer Codex code-review feature tokens first when the Codex lane is healthy.

## Surrounding doctrine
- Sonnet = planning, research, analysis, orchestration, decisions, critique
- Codex = coding, debugging, implementation, code review
- Haiku/Ollama = cheap background and heartbeat work

## Operational caveat
If Codex auth/runtime is unhealthy, Luna should repair it directly before surfacing it as a blocker whenever possible.
