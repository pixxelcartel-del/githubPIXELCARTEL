# PixC Resource System Spec

## Purpose

This document defines the canonical resource-system architecture for PixC Phase 1 knowledge capture, tutorial synthesis, free-resource tracking, and workflow adaptation.

It replaces ad hoc note-taking with a structured system that lets Luna:
- ingest tutorials and free resources without losing context
- merge overlapping material into one best-practice module per workflow area
- separate automated work from manual-download dependencies
- track screenshot-only extraction work
- convert findings into reusable PixC operating knowledge
- surface adjacent business and automation opportunities

This is a system spec only. It does not authorize build execution, external publishing, or asset generation outside the approved Phase 1 operating gates.

---

## 1. System Design Principles

1. **One canonical record per source item.** Every tutorial/resource gets one primary record, even if referenced elsewhere.
2. **Modules are the synthesis target.** Raw tutorials are inputs; reusable PixC modules are outputs.
3. **Duplicate knowledge must collapse.** Overlapping tutorials are not stored as competing truths. Luna must compare, score, and merge them into one chosen best-practice module.
4. **Manual dependencies must be explicit.** If Luna cannot legally or technically access/download something, it goes into a queue with clear next action.
5. **Visual-only knowledge must be queued.** If a workflow, prompt, setting, or asset is visible on screen but not machine-readable, it goes into screenshot extraction queue.
6. **Adoption requires traceability.** Any chosen workflow pattern must point back to the source tutorials/resources that informed it.
7. **Naming must stay stable.** IDs and slugs must be deterministic so later docs can reference them safely.
8. **Status values are controlled vocabulary.** No freeform statuses.

---

## 2. File Role and Authority

### 2.1 Canonical Files

- `memory/pixc/RESOURCES.md`
  - Human-readable operating ledger
  - May contain summaries, current queue snapshots, and high-level tracking
  - Not the authoritative schema definition

- `memory/pixc/RESOURCE-SYSTEM-SPEC.md`
  - **Authoritative architecture spec**
  - Defines sections/tables, schemas, statuses, naming rules, merge rules, and update policy

### 2.2 Authority Rule

If `RESOURCES.md` and this spec conflict:
- schema, naming, status values, and merge logic from `RESOURCE-SYSTEM-SPEC.md` win
- operating notes or current-state snapshots in `RESOURCES.md` may remain more current on day-to-day execution

---

## 3. Global Naming Conventions

Use lowercase kebab-case for all IDs that are human-entered or slug-derived.

### 3.1 ID Prefixes

| Record Type | Prefix | Example |
|---|---|---|
| Tutorial | `tut-` | `tut-jack-roberts-antigravity-basics` |
| Free resource | `res-` | `res-higgsfield-prompt-guide` |
| Manual download queue item | `mdq-` | `mdq-antigravity-private-template-pack` |
| Screenshot extraction queue item | `seq-` | `seq-jack-roberts-001` |
| Workflow adaptation log entry | `wal-` | `wal-scroll-pacing-defaults-v1` |
| Opportunity log entry | `opp-` | `opp-antigravity-site-productized-service` |
| Module | `mod-` | `mod-premium-scroll-hero-system` |
| Module mapping row | `map-` | `map-tut-jack-roberts-antigravity-basics-mod-premium-scroll-hero-system` |
| Tutorial cluster | `clu-` | `clu-scroll-hero-animation` |

### 3.2 Slug Rules

Slug components should be derived in this order:
1. creator or source domain
2. primary topic
3. distinguishing angle/version

Example:
- `tut-jack-roberts-antigravity-basics`
- `tut-youtube-kling-product-scroll-workflow`
- `res-github-frame-extractor-script`

### 3.3 URL and Video Identity Rules

- For YouTube tutorials, `source_key` must be the video ID.
- For websites/resources, `source_key` should be the normalized domain plus path slug when needed.
- If the same tutorial appears multiple times in raw intake, do not create duplicate tutorial records; update the canonical record and mark duplicate intake references in notes.

### 3.4 Module Naming Rules

Modules represent reusable PixC best-practice systems, not single-source summaries.

Module names must:
- describe capability, not author
- be implementation-oriented
- avoid tool-brand lock-in unless essential

Good:
- `mod-premium-scroll-hero-system`
- `mod-competitor-intelligence-reporting`
- `mod-client-portal-change-model`

Bad:
- `mod-jack-roberts-method`
- `mod-random-youtube-trick`

---

## 4. Controlled Vocabulary

### 4.1 Tutorial Status

Allowed values:
- `queued`
- `classified`
- `in-review`
- `synthesized`
- `superseded`
- `blocked`
- `archived`

### 4.2 Resource Status

Allowed values:
- `discovered`
- `validated`
- `adapted`
- `downloaded`
- `manual-action-needed`
- `blocked`
- `rejected`
- `archived`

### 4.3 Queue Status

For manual-download and screenshot queues:
- `queued`
- `ready`
- `waiting-on-himel`
- `in-progress`
- `completed`
- `blocked`
- `not-needed`

### 4.4 Adaptation Decision

Allowed values:
- `adopted`
- `adopted-with-modifications`
- `partial`
- `rejected`
- `deferred`
- `superseded`

### 4.5 Evidence Confidence

Allowed values:
- `high`
- `medium`
- `low`

### 4.6 Module Lifecycle

Allowed values:
- `candidate`
- `active`
- `needs-review`
- `superseded`
- `retired`

---

## 5. Required Sections in RESOURCES.md

`RESOURCES.md` should maintain these top-level sections in this order:

1. `## Tutorial Index`
2. `## Free Resource Index`
3. `## Manual-Download Queue`
4. `## Screenshot Extraction Queue`
5. `## Workflow Adaptation Log`
6. `## Opportunity Log`
7. `## Module Mapping`

Optional supporting sections allowed after those:
- current defaults
- cluster notes
- planned next actions
- summary dashboards

Do not remove any of the seven required sections.

---

## 6. Section Schemas

All fields below are required unless marked optional.

## 6.1 Tutorial Index

Purpose: canonical inventory of all tutorial/video/course inputs.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| tutorial_id | string | yes | Canonical tutorial ID with `tut-` prefix |
| source_key | string | yes | Stable source identifier, usually YouTube video ID |
| title | string | yes | Tutorial title |
| creator | string | yes | Channel, author, or source creator |
| url | string | yes | Direct source URL |
| cluster_id | string | yes | Topic cluster with `clu-` prefix |
| primary_module_candidates | string list | yes | One or more candidate module IDs |
| stage_focus | string list | yes | Relevant workflow stages/modules such as `M05`, `M06`, `M10`, `M11`, `M12` |
| format | enum | yes | `video`, `thread`, `article`, `repo`, `doc`, `course` |
| status | enum | yes | Tutorial status vocabulary |
| duplicate_of | string | no | If duplicate, reference canonical tutorial_id |
| synthesis_priority | integer | yes | 1-5, where 5 is highest |
| evidence_confidence | enum | yes | high/medium/low |
| key_claim | string | yes | Main promise or technique taught |
| extraction_state | string | yes | `none`, `transcript-only`, `metadata-only`, `full-notes`, `synthesized` |
| last_reviewed_utc | string | yes | ISO 8601 timestamp |
| notes | string | no | Short execution notes only |

### Update Rules

- Create one row as soon as a tutorial is discovered.
- `status=queued` until topic classification is completed.
- Set `cluster_id` before deep extraction.
- `duplicate_of` must be populated instead of creating a second canonical row.
- Once key lessons are merged into a module, set tutorial `status=synthesized` unless later superseded.
- If a tutorial becomes obsolete relative to a stronger synthesized module, set `status=superseded`, not deleted.

---

## 6.2 Free Resource Index

Purpose: canonical ledger of free templates, prompts, repos, docs, tools, asset packs, and guides discovered from tutorials or direct research.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| resource_id | string | yes | Canonical resource ID with `res-` prefix |
| name | string | yes | Resource name |
| resource_type | enum | yes | `template`, `prompt-pack`, `repo`, `script`, `tool`, `guide`, `asset-pack`, `doc`, `website`, `checklist`, `other` |
| is_free | boolean | yes | Whether access is free at point of discovery |
| source_origin | string | yes | Tutorial ID, domain, or direct source of discovery |
| direct_link | string | yes | Best direct link |
| related_tutorial_ids | string list | no | Tutorials that referenced it |
| module_ids | string list | yes | Modules this resource supports |
| intended_use | string | yes | How PixC would use it |
| adaptation_summary | string | no | What Luna changed or how it fits PixC |
| status | enum | yes | Resource status vocabulary |
| access_method | enum | yes | `direct-download`, `web-access`, `github-clone`, `manual-gated`, `signup-required`, `unknown` |
| license_or_usage_notes | string | no | Licensing or use constraints |
| manual_action_required | boolean | yes | Whether Himel must intervene |
| linked_manual_queue_id | string | no | Related `mdq-` item if manual action is required |
| last_validated_utc | string | yes | ISO 8601 timestamp |
| notes | string | no | Short factual notes |

### Update Rules

- Every discovered free resource gets a row, even if later rejected.
- If access requires a login, Discord, Gumroad checkout, or human download, set `manual_action_required=true` and create a linked manual queue item.
- If the resource is incorporated into a PixC workflow/module, status becomes `adapted`.
- If the link dies or the resource is no longer useful, set `blocked` or `archived`; do not delete history.

---

## 6.3 Manual-Download Queue

Purpose: explicit queue of items Luna identified but cannot fetch, unlock, or complete without Himel.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| queue_id | string | yes | Canonical queue ID with `mdq-` prefix |
| item_name | string | yes | Human-readable item name |
| linked_resource_id | string | no | Related `res-` item if applicable |
| linked_tutorial_id | string | no | Tutorial that referenced it |
| source_link | string | yes | URL where action must happen |
| blocker_type | enum | yes | `login-required`, `paywall-checkout`, `discord-gated`, `captcha`, `manual-click-path`, `broken-automation`, `legal-risk`, `unknown` |
| why_it_matters | string | yes | Why PixC may need it |
| luna_attempted | string | yes | What Luna already tried |
| required_himel_action | string | yes | Exact human step needed |
| priority | enum | yes | `high`, `medium`, `low` |
| downstream_module_ids | string list | yes | Which modules are blocked or improved by it |
| status | enum | yes | Queue status vocabulary |
| requested_utc | string | yes | ISO 8601 timestamp |
| resolved_utc | string | no | ISO 8601 timestamp when done |
| resolution_notes | string | no | Outcome or why closed |

### Update Rules

- Queue items must be actionable, specific, and minimal.
- `required_himel_action` must be written as a concrete task, not a vague request.
- If human action becomes unnecessary, set status `not-needed` with explanation.
- On completion, keep row and fill `resolved_utc` plus `resolution_notes`.

---

## 6.4 Screenshot Extraction Queue

Purpose: track visual-only tutorial moments where useful knowledge is shown on screen but not already captured in text.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| queue_id | string | yes | Canonical queue ID with `seq-` prefix |
| tutorial_id | string | yes | Source tutorial ID |
| timestamp_range | string | yes | Exact timestamp or range, e.g. `04:12-04:18` |
| visible_item_type | enum | yes | `prompt`, `settings`, `workflow-diagram`, `asset-name`, `folder-structure`, `ui-config`, `code-snippet`, `site-layout`, `other` |
| visible_content_summary | string | yes | What appears on screen |
| reason_capture_needed | string | yes | Why it matters to PixC |
| extraction_method | enum | yes | `manual-screenshot`, `frame-export`, `ocr`, `transcript-cross-check`, `multi-step` |
| target_module_ids | string list | yes | Modules likely impacted |
| priority | enum | yes | `high`, `medium`, `low` |
| status | enum | yes | Queue status vocabulary |
| extracted_result | string | no | Captured text or distilled finding |
| created_utc | string | yes | ISO 8601 timestamp |
| completed_utc | string | no | ISO 8601 timestamp |
| notes | string | no | Short notes |

### Update Rules

- Create queue items during tutorial review the moment a visual-only dependency is detected.
- Use one row per distinct extraction target, not per entire tutorial.
- Once extracted and incorporated into adaptation/module notes, set `status=completed` and store result summary.

---

## 6.5 Workflow Adaptation Log

Purpose: decision log for how raw tutorial/resource knowledge was translated into PixC workflow defaults, module rules, or operating changes.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| adaptation_id | string | yes | Canonical ID with `wal-` prefix |
| topic | string | yes | Decision topic |
| source_tutorial_ids | string list | no | Tutorials compared |
| source_resource_ids | string list | no | Resources compared |
| target_module_ids | string list | yes | Modules changed or informed |
| previous_default | string | no | Old PixC approach |
| evaluated_options | string | yes | Short summary of competing approaches |
| chosen_approach | string | yes | Selected PixC method |
| decision | enum | yes | Adaptation decision vocabulary |
| why_chosen | string | yes | Evidence-based rationale |
| tradeoffs | string | yes | What was sacrificed or constrained |
| implementation_rule | string | yes | Exact rule Luna should follow going forward |
| confidence | enum | yes | high/medium/low |
| supersedes_adaptation_id | string | no | Older adaptation being replaced |
| created_utc | string | yes | ISO 8601 timestamp |
| notes | string | no | Concise operational notes |

### Update Rules

- Every durable change to PixC workflow defaults must create an adaptation log entry.
- If the change affects approved defaults already listed elsewhere, update both places in the same pass.
- If a decision replaces an older one, use `supersedes_adaptation_id` instead of overwriting history.
- Adaptation log is the authoritative explanation layer for why PixC adopted a method.

---

## 6.6 Opportunity Log

Purpose: capture adjacent monetization, automation, tooling, service, or product opportunities discovered during resource analysis.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| opportunity_id | string | yes | Canonical ID with `opp-` prefix |
| title | string | yes | Short opportunity name |
| trigger_source | string | yes | Tutorial/resource/event that surfaced it |
| category | enum | yes | `service`, `product`, `automation`, `template`, `lead-gen`, `training`, `content`, `internal-tool`, `other` |
| description | string | yes | What the opportunity is |
| why_it_matters | string | yes | Strategic value to PixC |
| estimated_value | enum | yes | `high`, `medium`, `low`, `unknown` |
| setup_cost | enum | yes | `high`, `medium`, `low`, `unknown` |
| related_module_ids | string list | yes | Modules it touches |
| recommended_next_step | string | yes | Concrete next move |
| owner | string | yes | Usually `luna`, `atlas`, or `himel` |
| status | enum | yes | `open`, `validated`, `deferred`, `in-progress`, `closed`, `rejected` |
| created_utc | string | yes | ISO 8601 timestamp |
| notes | string | no | Optional notes |

### Update Rules

- Opportunities must be specific enough to act on later.
- If an opportunity becomes part of the core workflow, create or update module mapping and adaptation log entries.
- Reject low-quality ideas explicitly instead of leaving ambiguous notes.

---

## 6.7 Module Mapping

Purpose: tie source tutorials/resources to reusable best-practice PixC modules.

### Table Schema

| Field | Type | Required | Description |
|---|---|---:|---|
| mapping_id | string | yes | Canonical ID with `map-` prefix |
| module_id | string | yes | Module being informed |
| module_name | string | yes | Human-readable module name |
| module_lifecycle | enum | yes | candidate/active/needs-review/superseded/retired |
| source_type | enum | yes | `tutorial`, `resource`, `adaptation`, `opportunity` |
| source_id | string | yes | ID of source record |
| source_role | enum | yes | `primary`, `secondary`, `reference`, `rejected-alternative` |
| contribution_type | string | yes | What this source contributes, e.g. `scroll-pacing`, `prompt-structure`, `portal-model` |
| extracted_pattern | string | yes | Distilled lesson from source |
| adopted_for_pixc | boolean | yes | Whether it is actually used |
| adoption_notes | string | no | How it was adapted |
| superseded_by_module_id | string | no | If module was replaced |
| last_updated_utc | string | yes | ISO 8601 timestamp |

### Update Rules

- Every synthesized tutorial/resource that materially affects PixC should be mapped to at least one module.
- The same tutorial may map to multiple modules if it contributes to different systems.
- `source_role=primary` should be used sparingly; a module should ideally have one dominant primary source or one adaptation log as the primary authority.
- If a source is evaluated but intentionally not adopted, map it as `rejected-alternative` when that rejection is strategically useful to remember.

---

## 7. Module Definition Standard

Modules are the core output of this system. Each active module should be internally definable using this structure, whether stored in notes or implied in mapping:

| Field | Description |
|---|---|
| module_id | Canonical `mod-` ID |
| module_name | Reusable capability name |
| objective | What problem it solves in PixC |
| workflow_scope | Which PixC stages/modules it affects |
| inputs | Required inputs/assets/data |
| outputs | Deliverables produced |
| hard_rules | Non-negotiable rules |
| defaults | Preferred settings/default tools |
| anti_patterns | What not to do |
| source_authority | Primary mapping/adaptation records |
| review_trigger | What would cause module review |

A module is considered production-usable only when enough mapping/adaptation evidence exists to define these fields clearly.

---

## 8. Tutorial Clustering Rules

Before deep extraction, Luna must classify tutorials into clusters.

### Required Cluster Fields

For each cluster tracked in notes:
- `cluster_id`
- `cluster_name`
- `theme`
- `target_module_ids`
- `priority`
- `reason_this_cluster_matters`

### Example Clusters

- `clu-scroll-hero-animation`
- `clu-site-research-and-competitor-analysis`
- `clu-client-portal-and-change-ops`
- `clu-prompted-asset-generation`
- `clu-3d-video-frame-sequence`
- `clu-qa-and-audit-systems`

### Cluster Update Rule

No tutorial should proceed from `queued` to full synthesis without a `cluster_id`.

---

## 9. Duplicate and Overlap Merge Protocol

This is the critical synthesis rule.

Luna must not preserve multiple tutorials as parallel truths when they solve the same problem. Instead, Luna must merge them into one best-practice module.

### 9.1 When Tutorials Count as Overlapping

Treat tutorials as overlapping if they share most of the following:
- same workflow outcome
- same module target
- same core toolchain or technique
- same user intent
- same stage in PixC execution

Examples:
- multiple tutorials on cinematic scroll hero generation
- multiple tutorials on extracting frames from generated video
- multiple tutorials on client portal workflows

### 9.2 Merge Process

For each overlapping cluster, Luna must:

1. **Create/confirm cluster**
   - assign all related tutorials to the same `cluster_id`

2. **Normalize source notes**
   - capture each tutorial’s specific claims, strengths, constraints, and prerequisites

3. **Compare across seven dimensions**
   - outcome quality
   - repeatability
   - speed
   - complexity
   - tool dependence / fragility
   - fit with Luna-native automation
   - fit with PixC premium positioning

4. **Score candidate patterns**
   - mark each as `preferred`, `supporting`, `niche`, or `rejected`

5. **Extract the winning composite**
   - choose the best default method
   - pull only the strongest sub-techniques from alternates
   - reject redundant or fragile steps

6. **Create/update module mapping**
   - one active module should represent the merged pattern

7. **Create adaptation log entry**
   - document why this merged approach wins

8. **Update tutorial statuses**
   - dominant/useful tutorials: `synthesized`
   - obsolete or inferior ones: `superseded`
   - duplicates: `duplicate_of=<canonical>` and status `archived` or `superseded` as appropriate

### 9.3 Best-Practice Module Composition Rule

A best-practice module is allowed to be composite.
That means:
- Tutorial A may provide the strongest prompt structure
- Tutorial B may provide the best scroll pacing defaults
- Tutorial C may provide the cleanest asset organization

The final module should combine those into one PixC-standard workflow.

Do not force loyalty to one creator if a mixed approach is stronger.

### 9.4 Merge Output Template

When merging overlapping tutorials, Luna should produce a synthesis outcome with these fields in notes/adaptation:
- `merge_topic`
- `cluster_id`
- `tutorials_compared`
- `winner_for_default`
- `supporting_patterns_kept`
- `patterns_rejected`
- `final_pixc_rule`
- `module_id`
- `why_this_is_best`
- `review_trigger`

### 9.5 Tie-Break Rule

If two approaches are close, prefer the one that is:
1. easier to operationalize repeatedly
2. less dependent on brittle manual UI steps
3. more aligned with existing PixC defaults and approval gates
4. easier to explain and QA

---

## 10. Update Cadence and Operational Rules

### 10.1 On New Tutorial Discovery

Update in this order:
1. Tutorial Index row
2. Cluster assignment
3. Any immediate manual-download queue items
4. Any screenshot extraction queue items

### 10.2 On Full Review Completion

Update in this order:
1. tutorial extraction state/status
2. free resources discovered
3. screenshot queue completions
4. workflow adaptation log entries
5. module mapping rows
6. current defaults if changed

### 10.3 On Manual Human Intervention

When Himel downloads/unlocks something:
1. close or update the manual-download queue row
2. update linked free resource row
3. add adaptation or mapping only if the resource actually changes PixC workflow

### 10.4 No Deletion Rule

Do not delete rows for:
- duplicates
- blocked resources
- rejected workflows
- superseded tutorials

Historical traceability matters.
Use status changes and cross-references instead.

---

## 11. Data Quality Rules

1. No blank IDs.
2. No freeform statuses outside controlled vocabulary.
3. No module reference without a `mod-` ID.
4. No manual-action flag without either a queue item or explicit reason why queue item is not needed.
5. No `adapted` resource without at least one linked module.
6. No tutorial marked `synthesized` unless a module mapping or adaptation log exists.
7. No tutorial marked `duplicate` in notes alone; use `duplicate_of` field.
8. No “best practice” claim without comparison evidence in adaptation log or module mapping notes.

---

## 12. Recommended Initial Module Set for PixC

These modules should exist as the starting synthesis targets:

| Module ID | Module Name | Purpose |
|---|---|---|
| mod-client-intake-normalization | Client Intake Normalization | standardize project intake into build-ready inputs |
| mod-brand-and-site-extraction | Brand and Site Extraction | extract site structure, brand signals, and reusable content |
| mod-competitor-intelligence-reporting | Competitor Intelligence Reporting | analyze market patterns and build strategy inputs |
| mod-build-brief-locking | Build Brief Locking | convert research into approval-grade execution brief |
| mod-premium-scroll-hero-system | Premium Scroll Hero System | build premium animation/scroll hero methodology |
| mod-3d-video-frame-sequence | 3D Video Frame Sequence | convert video assets into scroll-sequence systems |
| mod-prompted-asset-generation | Prompted Asset Generation | manage image/video prompt architecture and generation defaults |
| mod-website-build-stack-selection | Website Build Stack Selection | choose correct implementation stack by project type |
| mod-uiux-pro-max-qa | UIUX Pro Max QA | enforce final quality gates |
| mod-client-portal-change-model | Client Portal Change Model | define post-launch change-request workflow |
| mod-resource-ingestion-and-synthesis | Resource Ingestion and Synthesis | turn tutorial/resource inputs into reusable PixC knowledge |
| mod-opportunity-capture | Opportunity Capture | record monetization/automation opportunities from research |

These are starting targets, not a ceiling.

---

## 13. Example Minimal Flow

For a newly discovered YouTube tutorial about AntiGravity-style scroll heroes:

1. Add row in Tutorial Index:
   - `tutorial_id=tut-jack-roberts-antigravity-basics`
   - `cluster_id=clu-scroll-hero-animation`
   - `status=queued`

2. On review, discover a free prompt guide and a gated template pack:
   - add free resource rows
   - create `mdq-...` row for gated pack

3. If prompt settings are shown visually only at `04:12-04:18`:
   - create `seq-...` row

4. Compare against other scroll-hero tutorials:
   - identify best prompt architecture from one
   - best pacing defaults from another
   - best file naming from a third

5. Create adaptation log entry:
   - chosen rule: Higgsfield 16:9 / 2K / 4 gens, Kling 3.0 1080p, 350vh default pacing

6. Update module mapping:
   - map all relevant sources into `mod-premium-scroll-hero-system`

7. Mark source tutorials:
   - strongest ones `synthesized`
   - weaker overlapping ones `superseded`

This is the expected operating behavior.

---

## 14. Enforcement Summary

Luna should use this resource system to enforce five outcomes:
- no raw tutorial hoarding
- no duplicate knowledge tracks
- no hidden manual blockers
- no visual-only knowledge loss
- no adoption without synthesis rationale

If a tutorial or resource cannot be mapped to a module, adaptation, queue, or opportunity, it is not fully processed.

That is the quality bar.
