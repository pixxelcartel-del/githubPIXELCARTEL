# Temporary Delegated Model Bypass

Date: 2026-04-02
Status: active workaround

## Why
Delegated subagent startup is currently blocked by stale/broken Codex OAuth state and dirty legacy fallback candidates.

## Temporary live routing
- sun-tzu -> Sonnet primary, Haiku fallback
- elon -> Sonnet primary, Haiku fallback
- mark -> Sonnet primary, Haiku fallback
- a -> Sonnet primary, Haiku fallback
- ernest -> Haiku primary

## Purpose
This is not the final doctrine. It is the live bypass that allows phase execution to resume while Codex auth is cleaned up separately.

## Steady-state target after Codex repair
- Sonnet for planning/orchestration/research/analysis/decision work
- Codex for implementation/debugging/build work
- Haiku for cheap background work
