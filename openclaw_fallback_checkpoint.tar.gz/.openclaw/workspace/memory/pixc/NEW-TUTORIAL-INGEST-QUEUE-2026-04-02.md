# New Tutorial Ingest Queue — 2026-04-02

Target links provided by Himel:
- https://youtu.be/TZUTe7s11-I
- https://youtu.be/nhibi9TRgNc
- https://youtu.be/csOEsfiBfvo
- https://youtu.be/ZfYvv-0l9NA

Rule:
1. dedupe by video id
2. check existing research/results first
3. scrape/save missing items properly into memory/research
4. extract taught workflow steps, tools, prompts, navigation paths, and implementation methods
5. only then create/update the necessary skill/SOP layers

Status update:
- TZUTe7s11-I already present in research and usable
- nhibi9TRgNc already present in research and usable
- csOEsfiBfvo already present in research and usable
- ZfYvv-0l9NA still missing; fetch currently blocked by TranscriptAPI DNS failure from this machine
- execution should continue from the 3 available tutorials instead of stalling the whole system
