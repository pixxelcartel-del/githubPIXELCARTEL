# PixC Deployment Registry

Status date: 2026-04-02
Owner: Luna

## Purpose
Canonical non-secret registry for deployable projects.
Use this to store project metadata after one-time bootstrap so routine redeploys can run through deploy hooks without interactive login.

## Required fields per project
- project_slug
- project_name
- local_path
- git_branch
- production_url
- vercel_project_id
- vercel_org_id
- deploy_hook_url
- deploy_mode (source|prebuilt)
- last_verified_utc
- notes

## Current entries

### pixc-overnight
- project_slug: pixc-overnight
- project_name: pixc-overnight
- local_path: /home/himel/.openclaw/workspace/memory/pixc/clients/pixc-overnight/site
- git_branch: unknown
- production_url: https://pixc-overnight.vercel.app
- vercel_project_id: prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH
- vercel_org_id: personal-account-not-yet-captured
- deploy_hook_url: https://api.vercel.com/v1/integrations/deploy/prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH/pEXl3TsBbk
- deploy_mode: source
- last_verified_utc: 2026-04-02T10:47:00Z
- notes: project id and deploy hook captured from Himel; org/team id not shown in UI and does not block deploy-hook-based routine redeploys.
