# PixC Website Factory SOP v1

Date: 2026-04-02
Derived from:
- parsed tutorial corpus in research/youtube_qde_pack_2026-04-01T22-15-41-142Z_distilled_qde_pack
- youtube backfill pack
- existing PixC overnight build findings

## Objective
Take PixC from context + assets + trust benchmarks to a fully polished handoff-ready premium website.

## Stage 0 — Preconditions
- runtime/delegation lane healthy
- Vercel deploy path available
- canonical assets known
- benchmark/tutorial routing available

## Stage 1 — Benchmark + trust blueprint
Inputs:
- Stripe / Vercel / Linear / Cloudflare-style trust patterns
- tutorial lessons from bUt1WpDlI6E, K0j_ADBkN9I, n3o8MgaNRE4, vXylQqxsGX0

Outputs:
- final section order
- proof stack
- CTA hierarchy
- founder presence slot
- motion restraint rules

Rules:
- trust before spectacle
- 1–2 cinematic moments max
- proof and clarity beat decorative complexity

## Stage 2 — Asset integration prep
Use:
- canonical PixC logo
- canonical Himel photo

Outputs:
- logo slot in header/footer/meta prep
- founder/founder-note section slot
- future OG/favicons queue

Rules:
- do not force assets into tacky hero treatment
- use founder image for trust, not vanity
- logo should read cleanly on dark background

## Stage 3 — Build and polish
Required sections:
- premium hero
- trust / proof strip
- services / offer framing
- process narrative
- founder/personal trust section
- FAQ / objection handling
- CTA footer

Required quality bars:
- mobile nav and CTA visible
- metadata consistent with live domain
- robots/sitemap correct
- restrained motion
- no placeholder-feel copy

## Stage 4 — Deploy and verify
Use:
- Vercel deploy hook for routine deploy
- linked project metadata already captured

Verify:
- live homepage loads
- robots.txt loads
- sitemap.xml loads
- canonical URL correct
- main mobile CTA visible

## Stage 5 — Handoff package
Deliver:
- live URL
- changed file list
- remaining trust-density punch list
- next content-factory hooks tied to live site

## Tutorial-derived operating principles
- Skills/SOPs are the productized interface, not giant prompts
- Modular pipelines beat one-shot generation
- Visual QA should inform frontend polish
- Iterative optimization loops belong after launch, not before shipping
- Reusable modules and trust patterns compound quality faster than starting blank each time
