# Default Resource & Platform Routing for PixC / Website Builds

Date: 2026-04-02
Owner: Luna
Status: canonical default

## Purpose
Himel should not need to explicitly restate which inspiration/resource platforms to use for website-building work.
This file makes the default stack explicit and reusable.

## Default platform sweep for website work
For any serious website build, redesign, premium landing page, cinematic build, or inspiration/research pass, Luna should automatically consider and use the relevant subset of:
- Awwwards
- Dribbble
- Behance
- Spline
- Framer showcases/examples
- Vercel / Linear / Stripe / Apple / Raycast quality references
- relevant YouTube tutorial corpus already scraped into the system

## Routing by purpose

### Visual benchmark / quality bar
Use first:
- Awwwards
- Stripe / Linear / Apple / Vercel references
- curated live competitors

### Component / layout / interaction inspiration
Use first:
- Dribbble
- Behance
- premium SaaS landing pages
- internal cinematic modules pack

### 3D / motion / scene direction
Use first:
- Spline
- relevant YouTube tutorials
- image/video generation references

### Build / deployment / productization
Use first:
- Vercel docs and existing PixC deployment registry
- internal workflow specs
- reusable modules and SOPs

## Default operating rule
When a website task starts, Luna should silently ask:
1. what is the benchmark layer?
2. what is the component/reference layer?
3. what is the motion/3D layer?
4. what is the deployment layer?
5. what existing tutorial knowledge already covers this?

Then gather what is needed without making Himel repeat platform names.

## Tech stack default
For generations and builds, default to our current approved stack unless Himel says otherwise:
- images: WaveSpeed → Nano Banana 2
- image-to-video: WaveSpeed → Kling 3.0
- deploy: Vercel deploy hook for routine redeploys
- orchestration: n8n
- site implementation: PixC website stack / premium dark SaaS baseline

## Resource ingestion rule
If a new tutorial, gallery, or platform becomes relevant:
- ingest it into research or memory/pixc resources
- deduplicate it
- route lessons to Mark / Elon / Sun Tzu / Ernest layers as appropriate
- extract durable tools/settings/workflows instead of leaving raw links unprocessed
