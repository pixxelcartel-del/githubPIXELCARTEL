# PixC Overnight Handoff

## What was built
A premium, Vercel-ready static landing page for PixC focused on trust, conversion, and restrained motion.

## File locations
- Site: `memory/pixc/clients/pixc-overnight/site/`
- Research: `memory/pixc/clients/pixc-overnight/research/`
- Intake: `memory/pixc/clients/pixc-overnight/intake/01-intake.md`

## Deployment
This is ready to deploy as a brand-new Vercel project using the `site/` folder as the project root.

## Recommended Vercel setup
- Framework preset: Other / Static
- Root directory: `memory/pixc/clients/pixc-overnight/site`
- Build command: none
- Output directory: .

## What to improve next
- Insert real PixC logo
- Insert real founder/team photography
- Connect CTA to booking form or contact workflow
- Add authentic case studies / logos / trust proof
- If desired, convert this into a Next.js project once approved assets exist for a stronger animated hero or richer content architecture

## Strategic note
The strongest decision was not over-animating. Under overnight constraints and with no real media assets, a premium restrained build converts better than a fake-cinematic one.