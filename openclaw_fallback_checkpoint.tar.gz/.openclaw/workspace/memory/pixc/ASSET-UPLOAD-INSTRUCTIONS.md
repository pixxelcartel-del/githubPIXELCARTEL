# PixC Asset Upload Instructions

Date: 2026-04-02

## Destination folder
Upload both files to:
/home/himel/.openclaw/workspace/assets/pixc/

## Expected filenames
- pixc-logo.jpg
- himel-photo.jpg

## SCP commands from Windows PowerShell

If using OpenSSH scp from Windows PowerShell:

scp "E:\Downloads\logo_pixelcartel (1).jpg" himel@72.62.69.94:/home/himel/.openclaw/workspace/assets/pixc/pixc-logo.jpg
scp "E:\Downloads\468359351_9207893749223517_2816012928349158009_n.jpg" himel@72.62.69.94:/home/himel/.openclaw/workspace/assets/pixc/himel-photo.jpg

## If using Tailscale instead of public IP

scp "E:\Downloads\logo_pixelcartel (1).jpg" himel@100.80.74.21:/home/himel/.openclaw/workspace/assets/pixc/pixc-logo.jpg
scp "E:\Downloads\468359351_9207893749223517_2816012928349158009_n.jpg" himel@100.80.74.21:/home/himel/.openclaw/workspace/assets/pixc/himel-photo.jpg

## After upload
Luna should treat these as the canonical PixC brand/logo and Himel photo assets unless newer approved replacements are provided.
