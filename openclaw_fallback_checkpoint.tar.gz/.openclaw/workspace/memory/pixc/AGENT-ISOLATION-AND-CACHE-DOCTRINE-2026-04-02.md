# Agent Isolation and Cache Doctrine

Date: 2026-04-02
Owner: Luna
Status: canonical

## Principle
Each Phase-1 agent should keep its own isolated operating lane as much as possible.
That means its own workspace, context history, tool surface, and cache locality.

## Why
- reduces context contamination
- preserves per-agent specialization
- improves cache reuse in repeated same-domain work
- makes failures easier to isolate
- keeps Luna main clean for coordination instead of workshop churn

## Operating rules
- Luna main = coordination, synthesis, memory, communication
- sun-tzu = orchestration hub and cross-agent sequencing lane
- elon = engineering implementation lane
- mark = website/frontend/product execution lane
- a = security/adversarial lane
- ernest = synthesis/compression lane

## Cache optimization rule
Keep repeated same-domain work in the same agent lane whenever possible.
Do not bounce an engineering task across multiple agents if one specialist can own it.
Do not stuff unrelated planning into implementation lanes if sun-tzu should hold that context.

## Cross-agent pipeline rule
When work spans multiple specialties:
1. sun-tzu scopes and sequences the pipeline
2. specialist executes in its own lane
3. result gets synthesized and, if needed, routed to the next specialist
4. Luna receives the final decision-grade synthesis

## Contamination avoidance
- no stale legacy agent ids
- no unnecessary tool sprawl in the wrong lane
- no carrying raw child context back into main
- only synthesized outputs and durable facts should move across lanes
