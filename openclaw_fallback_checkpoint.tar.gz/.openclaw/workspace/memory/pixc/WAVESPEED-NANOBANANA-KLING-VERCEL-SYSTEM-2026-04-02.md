# WaveSpeed + Nano Banana 2 + Kling 3.0 + Vercel System

Date: 2026-04-02
Owner: Luna
Status: planning locked, implementation-ready

## Objective
Build a reliable production workflow for:
- image generation via WaveSpeed using Google Nano Banana 2
- image-to-video generation via WaveSpeed using Kling 3.0
- automated website deployment via Vercel without interactive login friction
- clean handoff into PixC content and website operations

This doc is the canonical operating plan so we stop losing time to ad-hoc setup, half-working prompts, manual Vercel login loops, and scattered model notes.

## Official documentation references used

### WaveSpeed official docs
- Main docs: https://wavespeed.ai/docs
- Nano Banana 2 text-to-image: https://wavespeed.ai/docs/docs-api/google/google-nano-banana-2-text-to-image
- Kling 3.0 Standard image-to-video: https://wavespeed.ai/docs/docs-api/kwaivgi/kwaivgi-kling-v3.0-std-image-to-video
- Kling 3.0 Pro image-to-video: https://wavespeed.ai/docs/docs-api/kwaivgi/kwaivgi-kling-v3.0-pro-image-to-video

### Vercel official docs
- Deploy Hooks: https://vercel.com/docs/deploy-hooks
- Deploy from CLI: https://vercel.com/docs/projects/deploy-from-cli
- CLI token/global options: https://vercel.com/docs/cli/global-options

## What the official docs confirm

### WaveSpeed platform level
WaveSpeed officially supports:
- REST API
- JavaScript SDK
- Python SDK
- n8n integration
- browser/web UI

WaveSpeed positioning from docs:
- unified API across many models
- async task submit + result polling pattern
- Bearer token auth via WAVESPEED_API_KEY

### Nano Banana 2 on WaveSpeed
Official endpoint:
- POST https://api.wavespeed.ai/api/v3/google/nano-banana-2/text-to-image

Official result polling pattern:
- GET https://api.wavespeed.ai/api/v3/predictions/{requestId}/result

Documented capabilities:
- 1K / 2K / 4K output
- flexible aspect ratios including 16:9
- PNG or JPEG output
- prompt enhancer support
- optional web/image search flags
- async or sync mode flags exposed by API

### Kling 3.0 on WaveSpeed
Official endpoints:
- Standard: POST https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-std/image-to-video
- Pro: POST https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-pro/image-to-video

Official polling pattern:
- GET https://api.wavespeed.ai/api/v3/predictions/{requestId}/result

Documented capabilities:
- image + prompt required
- duration 3–15 seconds
- optional negative prompt
- optional end image for guided transitions
- optional sound generation
- optional cfg_scale and shot_type
- async workflow by default

### Vercel official deployment paths
Two official production-safe patterns matter for us:

1. CLI deploy with token
- use VERCEL_TOKEN
- use linked project metadata in .vercel/
- non-interactive linking/deploy supported

2. Deploy Hooks
- trigger by GET or POST to a generated hook URL
- no auth header required
- project/branch specific
- ideal for n8n/webhook-triggered redeploys

## Architecture decision

We should standardize on this split:

### A. Media generation = n8n + WaveSpeed API
Reason:
- external credentials belong in n8n, not random shell commands
- easy retries, logging, error notifications, and future chaining
- fits existing Luna system rule: external services through n8n

### B. Website deployment = Vercel Deploy Hook for routine redeploys
Reason:
- avoids interactive CLI device-login loops
- officially supported for external system triggers
- easiest reliable path for n8n or cron-based deployment triggers

### C. Initial project linking = one-time CLI setup with VERCEL_TOKEN
Reason:
- deploy hooks require an already connected Vercel project
- one-time bootstrap is acceptable, repeated interactive login is not

## Required secrets / config

### n8n credentials to add/store
1. WAVESPEED_API_KEY
2. VERCEL_TOKEN
3. VERCEL_PROJECT_ID
4. VERCEL_ORG_ID
5. Project-specific Vercel Deploy Hook URL(s)

### Workspace/runtime metadata to preserve
For each deployable site we should store:
- project name
- repo/path
- production domain
- vercel project id
- vercel org id
- deploy hook url
- branch used for production
- whether deploy is source-based or prebuilt

Recommended storage locations:
- n8n credentials store for secrets
- memory/infrastructure.md or dedicated deployment registry markdown for non-secret metadata
- optionally Supabase later for structured registry

## Standard workflow design

## Workflow 1 — WaveSpeed image generation
Purpose:
Generate 2 initial PixC images using Nano Banana 2 with exact defaults.

Input contract:
- prompt
- aspect_ratio default 16:9
- resolution default 1k
- output_format default png
- output filename hint
- project slug
- generation id / idempotency key

WaveSpeed submit:
POST /api/v3/google/nano-banana-2/text-to-image

Recommended defaults:
- resolution: 1k
- output_format: png
- enable_sync_mode: false
- enable_base64_output: false
- enable_web_search: false unless explicitly needed
- enable_image_search: false unless explicitly needed

n8n behavior:
1. receive request
2. submit WaveSpeed task
3. store requestId + prompt metadata
4. poll result endpoint with backoff
5. on success, store output URL + local bookkeeping
6. notify Luna / append execution log
7. on failure, capture full error payload

Failure handling:
- retry transient 429/5xx with backoff
- hard fail on auth/model/validation errors
- write clear stage failure: submit_failed vs poll_failed vs output_missing

## Workflow 2 — WaveSpeed image-to-video generation
Purpose:
Generate the first short PixC motion asset after image review.

Input contract:
- source image URL
- motion prompt
- model tier: kling-v3.0-std or kling-v3.0-pro
- duration default 5s
- resolution target 1080p as operating default
- aspect ratio 16:9
- optional negative prompt
- optional end image
- optional sound false by default

Recommended default for PixC:
- start with Kling 3.0 Standard for first budget-controlled run
- use Pro only when the shot is already validated and worth the extra cost

WaveSpeed submit:
- POST /api/v3/kwaivgi/kling-v3.0-std/image-to-video
or
- POST /api/v3/kwaivgi/kling-v3.0-pro/image-to-video

n8n behavior:
1. validate image review has passed
2. submit video generation
3. poll WaveSpeed result endpoint with slower cadence than images
4. store result URL and generation metadata
5. optionally extract best still frame later through local tooling

Failure handling:
- reject if source image URL is not publicly reachable
- reject if prompt missing
- capture submit payload fingerprint for reproducibility

## Workflow 3 — automated Vercel deploy trigger
Purpose:
Redeploy a site after edits without interactive auth.

Primary path:
- Vercel Deploy Hook URL per project

Official behavior from docs:
- GET or POST to hook URL triggers deployment
- no auth header required
- treat hook URL like a secret

Recommended n8n workflow:
1. receive site slug + optional reason
2. look up deploy hook URL
3. POST to deploy hook
4. store deployment trigger time
5. send success/failure notification
6. optionally ping live URL after short wait

Reason this should be primary:
- removes device-login friction
- ideal for routine redeploys from Luna/n8n
- branch/project stay locked in Vercel side

## Workflow 4 — one-time Vercel project bootstrap
Purpose:
Create/link new Vercel projects for fresh sites.

Officially supported path:
- use VERCEL_TOKEN
- use vercel link --yes in a prepared project directory
- use vercel deploy --prod non-interactively after linking

Required env:
- VERCEL_TOKEN
- ideally linked .vercel/project.json
- optionally VERCEL_ORG_ID and VERCEL_PROJECT_ID

After bootstrap, immediately create/store:
- deploy hook URL
- project metadata registry entry

Critical rule:
Routine deploys should not depend on repeating this step.
Bootstrap once. Then switch to deploy hooks.

## PixC operating defaults

### Image generation defaults
- model: Nano Banana 2 via WaveSpeed
- count: 2 images first
- aspect ratio: 16:9
- resolution: 1K for first pass
- output format: PNG
- no embedded text unless explicitly required
- no image search/web search unless a grounded factual visual is needed

### Video generation defaults
- model: Kling 3.0 Standard first
- aspect ratio: 16:9
- target use: 5–8 second promo asset
- sound: off by default
- duration: 5s default, only extend when prompt truly needs it
- resolution target: 1080p operating standard

### Deployment defaults
- every new website/app gets a brand-new Vercel project
- bootstrap once with token
- routine redeploys via deploy hook
- store deploy hook and project ids immediately after bootstrap

## Failure modes we must eliminate

### 1. Interactive Vercel device-login blocking deployments
Fix:
- move to token-based bootstrap + deploy hooks

### 2. Media generation spread across random providers with no state
Fix:
- standardize on WaveSpeed for this image/video path
- keep provider metadata in logs

### 3. Prompt drift across runs
Fix:
- prompts come from versioned prompt-pack files
- queue JSON references prompt source path

### 4. No idempotency / duplicate runs
Fix:
- every generation request carries generation id
- n8n checks if same id already completed before resubmitting

### 5. No clear failure stage
Fix:
- classify errors by stage: auth, submit, poll, asset_url, postprocess, deploy_trigger, live_verify

## Minimal implementation plan

### Phase A — credentials and registry
1. add WAVESPEED_API_KEY to n8n credentials
2. add VERCEL_TOKEN to n8n credentials
3. add/store VERCEL_PROJECT_ID + VERCEL_ORG_ID for PixC project
4. create Vercel Deploy Hook for PixC production branch
5. store hook URL in deployment registry

### Phase B — n8n workflows
1. wavespeed-image-generate
2. wavespeed-video-generate
3. vercel-deploy-trigger
4. deployment-registry-update or equivalent bookkeeping

### Phase C — prompt + queue integration
1. use existing PixC prompt pack
2. execute queue in order:
   - image 1
   - image 2
   - review
   - short video
3. append result log after each generation

### Phase D — website automation hardening
1. finish PixC local polish
2. bootstrap non-interactive Vercel deploy path properly
3. switch future redeploys to deploy hook only

## Immediate open blockers
1. WAVESPEED_API_KEY presence is not yet verified in the live system from this session
2. VERCEL_TOKEN presence is implied in notes but not yet verified in a live usable registry from this session
3. PixC project deploy hook does not appear documented yet
4. some prior notes reference Vercel MCP, but we should not rely on vague MCP assumptions for production deploy reliability

## Decision
From now on, official operating path is:
- WaveSpeed API for Nano Banana 2 + Kling 3.0 generation
- n8n for orchestration and secret handling
- Vercel Deploy Hook for routine redeploys
- one-time tokenized CLI bootstrap only when a new project is first created

## Exact endpoints to preserve

### WaveSpeed
- POST https://api.wavespeed.ai/api/v3/google/nano-banana-2/text-to-image
- POST https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-std/image-to-video
- POST https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-pro/image-to-video
- GET https://api.wavespeed.ai/api/v3/predictions/{requestId}/result

### Vercel
- Deploy Hook URL is generated per project in Vercel UI
- CLI docs confirm non-interactive token usage and linking/deploy workflows

## Next execution order
1. finish documenting implementation artifacts in workspace
2. verify available credentials/registry state
3. set up or document missing n8n workflow specs
4. set up Vercel deploy hook for PixC
5. wire first PixC image run through the standardized path
