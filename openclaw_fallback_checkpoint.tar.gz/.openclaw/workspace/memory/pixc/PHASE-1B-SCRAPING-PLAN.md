# Luna Phase 1B — Scraping System Complete Deployment & Execution

> **Date:** 2026-03-31 | **Status:** READY FOR REVIEW

---

## Current State Assessment

### What's DONE (Phase 1A — ✅ Complete)
- 5 agent SOULs + SKILLs deployed to VPS (`Ernest`, `Sun Tzu`, `Elon`, `Mark`, `A`)
- 4 agent workspaces created on VPS
- 9 Qdrant collections created (including `tutorials`, `code_snippets`, `market_intel`, `design_assets`, `agent_outputs`)
- 8 Supabase tables + 6 indexes deployed
- 3 Ollama models pulled
- Model routing configured in `openclaw.json`
- Memory system updated

### What's PREPARED But NOT Deployed (Phase 1B)
- QDE config files created locally: `qde-prompt.json`, `qde-red-flags.json`, `qde-gold-signals.json`
- Deploy script created: `deploy-phase1b.sh`
- Full implementation plan written
- Phase 1B Supabase tables SQL prepared (in the deploy script)

### What's NOT Done (Phase 1B — 0% execution)
- ❌ YouTube API OTP registration (never started)
- ❌ QDE configs NOT deployed to VPS
- ❌ Phase 1B Supabase tables NOT created (`scraping_runs`, `techniques`, `deprecation_alerts`)
- ❌ No YouTube links collected from Himel
- ❌ Zero scraping completed
- ❌ No n8n automation workflows created
- ❌ Asset directories NOT created on VPS

> [!CAUTION]
> **Supabase project `jjpqiskuksqdstopdgib` is currently INACTIVE/PAUSED.** It must be reactivated before any database operations can proceed. All Phase 1A tables may need to be re-verified after reactivation.

---

## Where Instructions & Links Are Saved in Luna's System

### Scraping Instructions Location Map

| Data | Location | Status |
|---|---|---|
| **Phase 1B Master Plan** | Local: `c:\Users\himel\.agent\.temp\phase1b-deploy\` | ✅ Created, NOT on VPS |
| | Target: `/home/himel/.openclaw/workspace/memory/pixc/PHASE-1B-SCRAPING-PLAN.md` | ❌ Not deployed |
| **QDE Scoring Prompt** | Local: `phase1b-deploy/qde-prompt.json` | ✅ Created |
| | Target: VPS `memory/pixc/qde-prompt.json` | ❌ Not deployed |
| **QDE Red Flags** | Local: `phase1b-deploy/qde-red-flags.json` | ✅ Created |
| | Target: VPS `memory/pixc/qde-red-flags.json` | ❌ Not deployed |
| **QDE Gold Signals** | Local: `phase1b-deploy/qde-gold-signals.json` | ✅ Created |
| | Target: VPS `memory/pixc/qde-gold-signals.json` | ❌ Not deployed |
| **Deploy Script** | Local: `phase1b-deploy/deploy-phase1b.sh` | ✅ Created |
| **YouTube Scraper Skill** | VPS: `/home/himel/.openclaw/workspace/skills/youtube-full/` | ✅ Exists (no API key) |
| **YouTube Links Queue** | Nowhere yet — **0 links provided by Himel** | ❌ Empty |
| **Scraping Results** | Qdrant `tutorials` collection | ❌ Empty (0 entries) |
| **Master Context** | Local: `LUNA-PIXC-MASTER-CONTEXT.md` | ✅ Full reference doc |
| **Agent Souls** | Local: `souls/` + VPS workspaces | ✅ Deployed |

### Scraping Completion Summary

| Component | Completion | Quality |
|---|---|---|
| QDE Config (scoring engine) | 100% designed, 0% deployed | ⭐⭐⭐⭐⭐ (Excellent design) |
| YouTube API Setup | 0% | N/A |
| YouTube Scraping | 0% | N/A |
| Spline Harvesting | 0% | N/A |
| Dribbble Intelligence | 0% | N/A |
| n8n Automation | 0% | N/A |
| Cross-Reference Engine | 0% (design only) | N/A |

**Bottom line: The QDE architecture is brilliantly designed. Zero execution has occurred.**

---

## User Review Required

> [!IMPORTANT]
> **Supabase Reactivation Required.** The project is paused. You'll need to reactivate it from the Supabase dashboard before I can proceed with database operations.

> [!IMPORTANT]
> **YouTube API Email.** I need the email address you want to use for the TranscriptAPI.com OTP registration.

> [!WARNING]
> **This is a Windows machine, not the VPS.** I can prepare and upload files, but VPS deployment commands (SSH, Docker, etc.) will require either: (a) SSH access from this machine, or (b) you running the deploy script on the VPS manually.

---

## Proposed Changes

### Phase 1: Infrastructure Fix (~5 min)

#### Supabase Reactivation
- [ ] **YOU (Himel):** Reactivate Supabase project from dashboard → [https://supabase.com/dashboard](https://supabase.com/dashboard)
- [ ] Verify tables exist after reactivation
- [ ] Create Phase 1B tables (`scraping_runs`, `techniques`, `deprecation_alerts`) if not present

---

### Phase 2: Data Upload to Luna's Memory (~10 min)

#### [MODIFY] Supabase — Phase 1B Tables
Run the SQL from `deploy-phase1b.sh` lines 142-206 to create:
- `scraping_runs` — logs every scrape session
- `techniques` — the technique registry with QDE scores
- `deprecation_alerts` — tracks outdated techniques

#### [NEW] Supabase — `scraping_queue` table
New table to store Himel's forwarded links:
```sql
CREATE TABLE scraping_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  url TEXT NOT NULL,
  source_type TEXT DEFAULT 'youtube',
  priority TEXT DEFAULT 'P1',
  status TEXT DEFAULT 'pending',
  notes TEXT,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  scraping_run_id UUID REFERENCES scraping_runs(id)
);
```

#### VPS File Deployment
Upload to VPS `/home/himel/.openclaw/workspace/memory/pixc/`:
- `qde-prompt.json`
- `qde-red-flags.json`
- `qde-gold-signals.json`
- `PHASE-1B-SCRAPING-PLAN.md` (the full implementation plan)

---

### Phase 3: YouTube API OTP Setup (~5 min)

1. **ASK HIMEL** → email address for TranscriptAPI registration
2. SSH into VPS → `cd ~/.openclaw/workspace/skills/youtube-full/`
3. Run: `node ./scripts/tapi-auth.js register --email [EMAIL]`
4. **ASK HIMEL** → OTP code from email
5. Run: `node ./scripts/tapi-auth.js verify --email [EMAIL] --password [PW] --otp [CODE]`
6. Verify: `echo $TAPI_KEY`
7. Test with sample video

---

### Phase 4: Collect & Queue Links from Himel

After OTP setup, **ASK HIMEL:**
> "Give me ALL the YouTube links, Dribbble shots, Spline assets, CodePen pens, Awwwards sites, and any other URLs you want scraped. I'll process every single one through the QDE and store the gold."

Store all links in `scraping_queue` table.

---

### Phase 5: Execute Full Scraping Phase

For each link in the queue:
1. **Extract** content (transcript for YouTube, source for web)
2. **Parse** into discrete techniques
3. **Score** each technique through QDE (7 dimensions)
4. **Route** based on verdict:
   - 🥇 GOLD → Qdrant `tutorials` + Supabase `techniques` + Neo4j node
   - 🥈 SILVER → Qdrant `tutorials` + Supabase `techniques`
   - 🥉 BRONZE → Qdrant `market_intel`
   - 🗑️ TRASH → Log to rejections, discard
5. **Report** summary to Himel with highlights

---

## Open Questions

> [!IMPORTANT]
> 1. **Can you reactivate the Supabase project now?** It's currently paused/inactive and I can't run any SQL.
> 2. **What email should I use for the YouTube API (TranscriptAPI) OTP registration?**
> 3. **Do you have SSH access from this Windows machine to the VPS?** (So I can deploy files directly, or do you prefer to run the deploy script yourself?)
> 4. **Give me ALL the links you want scraped** — YouTube, Dribbble, Spline, CodePen, Awwwards, anything.

---

## Verification Plan

### Automated Tests
- Query Supabase `scraping_runs` table for completed runs
- Query Supabase `techniques` table for GOLD/SILVER entries
- Test QDE with a known-good technique (GSAP ScrollTrigger) → expect GOLD
- Test QDE with a known-bad technique (jQuery slideToggle) → expect TRASH

### Manual Verification
- Himel reviews 20 random QDE verdicts for accuracy (target: ≥85% agreement)
- Check Qdrant collections have embeddings after scraping
- Verify cross-reference works: fake client brief → technique recommendations

---

## Token Budget Tracking

> [!NOTE]
> I will track token usage throughout this run to ensure I can complete all scraping within the session. The QDE scoring uses Groq Mixtral (free tier) so the main cost is my own context window and any Anthropic API calls.

| Phase | Estimated Token Usage | Status |
|---|---|---|
| Research & Planning | ~15K tokens | ✅ Complete |
| Supabase SQL Execution | ~2K tokens | Pending |
| YouTube API Setup | ~3K tokens | Pending |
| Link Collection | ~2K tokens | Pending |
| Per-Video Scraping (transcript + QDE) | ~5K tokens/video | Pending |
| Summary Report | ~3K tokens | Pending |
| **Total estimated for 20 videos** | ~125K tokens | Within budget |
