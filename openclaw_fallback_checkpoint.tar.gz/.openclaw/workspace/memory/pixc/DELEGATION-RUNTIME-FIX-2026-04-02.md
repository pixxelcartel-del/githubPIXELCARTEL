# Delegation Runtime Fix — 2026-04-02

## Root cause
The live OpenClaw control plane was invalid, not merely mis-routed.

Exact blocker:
- ~/.openclaw/openclaw.json contained an unsupported key under agents.defaults:
  - videoGenerationModel

Impact:
- OpenClaw CLI validation failed
- Gateway/CLI health commands were degraded
- delegated subagent startup behavior became unreliable and appeared to keep using stale gpt-5.4 session behavior even after per-agent model fixes

## Fix applied
- removed invalid agents.defaults.videoGenerationModel from ~/.openclaw/openclaw.json
- revalidated config with live commands:
  - openclaw status
  - openclaw gateway status

## Confirmed current intended runtime state
- subagent default model: anthropic/claude-haiku-4-5-20251001
- elon primary model: anthropic/claude-haiku-4-5-20251001
- mark primary model: anthropic/claude-haiku-4-5-20251001
- sun-tzu primary model: anthropic/claude-sonnet-4-6
- ernest primary model: anthropic/claude-haiku-4-5-20251001

## Remaining cleanup
- stale failed subagent sessions launched before the config repair may still show gpt-5.4 in status
- after repair, fresh delegated runs must be tested rather than trusting old failed session cards

## Next step
- inspect/clear stale failed child sessions if needed
- run a fresh minimal delegated smoke test
- if smoke test passes, reopen website-finisher delegation lane
