# Phase 1 — Blockers and Decision Gates

## Purpose

This document defines the minimum viable client journey for PixC Phase 1 website builds, the autonomy boundary for Luna, the true hard blockers, and the exact decision gates that prevent waste and rework.

The goal is simple: Luna should move a client from intake to research to build brief to approval to build with as little Himel involvement as possible, while still stopping at the points where human judgment or missing inputs would make autonomous execution unsafe or inefficient.

---

## 1) Minimum Viable Client Journey

### Stage 1 — Intake
Luna collects the core business inputs, brand assets, source content, goals, CTA, and style direction.

### Stage 2 — Discovery + Research
Luna runs the website-intelligence process:
- scrape current website or source materials
- extract brand snapshot
- analyze competitors
- identify patterns of the top 10%
- define positioning, page structure, and SEO direction

### Stage 3 — Build Brief
Luna creates the build brief with:
- design direction
- site architecture
- content framework
- CTA strategy
- asset plan
- animation recommendation

### Stage 4 — Approval Checkpoint
Luna stops. No final website build starts until the brief is approved.

### Stage 5 — Asset Production
If the site needs scroll-stop visuals, Luna prepares the prompt set and asset plan.
Defaults:
- Higgsfield image generation: 16:9, 2K, 4 generations
- Kling 3.0 video generation: 1080p
- scroll height baseline: 350vh
- slower / cinematic variant: 500vh
- faster / tighter variant: 250vh

### Stage 6 — Website Build
Luna or Atlas builds the site from the approved brief.

### Stage 7 — QA + Final Audit
Mandatory final pass:
- UIUX Pro Max audit
- SEO audit
- accessibility check
- performance check
- mobile review

### Stage 8 — Client Change System
Preferred model for PixC:
- client portal for changes
Not preferred as default:
- pure retainer-only dependency
- full CMS autonomy that can break the site

### Stage 9 — Handoff
Luna packages the preview, notes pending items, defines next steps, and routes change requests into the portal system.

---

## 2) What Luna Can Do Without Himel

Luna can autonomously do all of this:
- collect and structure intake
- scrape the client’s site or other source content
- extract logo, colors, fonts, tone, and messaging
- research competitors
- score competitors and identify winning patterns
- generate a competitive analysis report
- produce the build brief
- recommend site structure, design direction, copy direction, CTA strategy, and SEO priorities
- prepare the 3-asset generation plan for scroll-stop visuals
- recommend whether animation should be used at all
- build internal planning docs and execution checklists
- prepare the client portal model for change requests
- run audit logic and quality gates

Luna should do all of the above automatically once minimum intake exists.

---

## 3) What Still Requires Approval

These are real decision gates and should not be skipped.

### Mandatory Approval Gate 1 — Build Brief Approval
The build brief must be approved before implementation begins.
This is the core hard stop.

### Mandatory Approval Gate 2 — Major Direction Shift
If research shows the current brand direction is weak and Luna recommends a major repositioning, approval is required before moving forward with the new direction.

### Mandatory Approval Gate 3 — Final Publish / External Go-Live
Preview can be built autonomously, but public launch should still be treated as an approval moment unless explicitly pre-authorized.

### Optional Approval Gate — Premium Animation Scope
If animation meaningfully changes cost, complexity, or delivery time, Luna should confirm the direction before heavy asset work begins.

---

## 4) Hard Blockers

These are the exact blockers that justify stopping execution.

### Blocker A — No Source Material
If there is no website, no copy, no service details, and no usable source material, Luna cannot produce a strong brand extraction or accurate build brief.

### Blocker B — No Clear Offer
If the client cannot say what they sell, who they sell to, or what action they want visitors to take, the site strategy will be guesswork.

### Blocker C — No Approval on Build Brief
If the brief is not approved, the build does not start.

### Blocker D — 3D / Scroll Concept Is Underspecified
If a premium animated hero is requested but the object, before/after state, product internals, or visual direction are unclear, Luna should not force the 3D path.
A simpler premium hero is better than weak animation.

### Blocker E — Missing Essential Brand Assets for Claimed Brand Precision
If the client wants strict brand fidelity but does not provide logo, colors, typography references, or existing source material, Luna cannot guarantee precise execution.

### Blocker F — Unclear Change Authority
If Luna does not know who has authority to approve the brief or request changes, execution can stall and loop.

### Blocker G — Missing Technical Destination
If deployment, domain, forms, or contact routing are required for completion but no destination is defined, final handoff will be incomplete.

---

## 5) Mandatory Client Inputs Upfront

To avoid rework, Luna should collect these before starting Phase 1.

### Core Required
- business name
- website URL or alternate content source
- what the business sells
- who it sells to
- service area / location if relevant
- primary business goal
- primary CTA
- preferred vibe / style direction

### Strongly Recommended
- logo
- brand colors
- testimonials / proof
- competitor examples
- existing photos / videos
- required pages
- any hard no’s

### Required for Scroll / 3D Work
- whether animation is actually desired
- video file or asset generation direction
- object or transformation concept
- white-background first frame if using video
- preferred pacing: 350vh baseline, 500vh slower, or 250vh faster

---

## 6) What Can Be Templated

These components should become reusable PixC system assets.

- intake pack
- client-facing research request message
- competitor analysis report skeleton
- build brief structure
- homepage CTA frameworks
- asset generation prompt frameworks
- portal request page structure
- QA checklist
- audit checklist
- handoff checklist

The more these are standardized, the more Luna can operate autonomously.

---

## 7) Where Human Review Should Happen

Human review is most useful at these moments:

### Review Point 1 — After Build Brief
This is the highest-value checkpoint.
Review design direction, CTA logic, structure, and whether the proposed site matches the real offer.

### Review Point 2 — After First Working Build
Quick review for taste, quality ceiling, and whether the animation is worth keeping.

### Review Point 3 — Before Publish
Final business check: brand alignment, contact routing, deployment target, and public readiness.

Everything else should be handled by Luna and the system.

---

## 8) Decision Logic for Luna

Use this logic every time.

### If the client has a real site + clear offer + clear CTA
Proceed immediately into research and build brief.

### If the client has no site but does have copy / docs / offer clarity
Proceed, but build the brand extraction from alternate source material.

### If the client wants premium animation but the concept is weak
Recommend a non-3D premium hero first, or request tighter asset direction.

### If research contradicts the client’s current positioning
Surface the contradiction in the build brief and require explicit direction approval.

### If the client wants change autonomy after handoff
Default to portal model.
Do not default to a full editable CMS unless the use case truly demands it.

---

## 9) Upfront Questions That Prevent Rework

These questions are non-negotiable because they collapse future ambiguity.

- What exactly are we trying to make the visitor do?
- What is the single most important offer on this site?
- Who is the buyer?
- What proof do we have?
- What existing content is reliable enough to reuse?
- Is this a premium animation site, or just a premium site?
- Who approves the brief?
- Who approves launch?
- What happens after handoff when the client wants changes?

If Luna cannot answer those, the system is not ready to build.

---

## 10) PixC Phase 1 Default Operating Facts

Bake these into every website execution flow:
- Higgsfield image generation defaults: 16:9, 2K, 4 generations
- video generation default: Kling 3.0 at 1080p
- scroll pacing default: 350vh baseline
- slower cinematic variant: 500vh
- faster compact variant: 250vh
- preferred client change model: portal
- mandatory final pass: UIUX Pro Max audit

---

## 11) Bottom Line

Luna can autonomously run almost all of Phase 1.
The true stop points are not technical — they are strategic clarity, approvals, and missing source truth.

If intake is strong and the build brief gets approved, the rest of the system should move with very little human drag.
