# PixC Low-Budget Generation Plan

## Default rule
Follow Himel's standing rule exactly:
- generate 2 images first
- then 1 short video
- then buy more images only if budget remains

## Why this order is correct for PixC right now
- The overnight website direction is already visual enough to support still-image promo assets
- Two images are enough to test visual direction before spending on motion
- A short video becomes stronger when it inherits the visual language proven by the first two stills
- If the first image batch is weak, fix prompts before burning budget on more expensive motion

## Budget-conscious execution sequence

### Stage 1 — First two images
Use:
- Image Prompt 1 — hero / website optics
- Image Prompt 2 — systems / service stack

Goal:
- validate the PixC visual world
- get immediate promo assets for landing page support, social posts, and ad tests

Pass criteria:
- feels premium, not generic AI slop
- color world matches overnight site
- reads as digital agency / systems brand, not random SaaS app
- clean enough for caption overlay

If one image is clearly stronger:
- keep that direction
- slightly revise the weaker prompt before any more spend

### Stage 2 — First short video
Use:
- Short Video Prompt 1 — calm premium motion

Goal:
- create one 5-8s motion asset for reels, paid social, or website embed test

Pass criteria:
- motion feels controlled
- composition stays clean enough to end on a usable frame
- no weird distortions or overly literal fake text
- visually aligned with image winners from stage 1

### Stage 3 — Only if budget remains
Pick 1-3 extra images from:
- devices visual
- trust-section visual
- content-factory visual

Priority order:
1. devices visual
2. content-factory visual
3. trust-section visual

Reason:
The first two extend the paid-social and website-promo library fastest.

## Suggested tomorrow workflow
1. Generate image 1
2. Generate image 2
3. Review both side by side
4. Pick keeper direction
5. Slightly tune video prompt to match keeper direction
6. Generate 1 short video
7. Pull best frame from video for optional static reuse
8. If budget remains, generate image 3 and maybe image 5

## Editing / repurposing plan after generation
Each keeper asset should be repurposed into:
- website section support image
- Instagram post or carousel cover
- paid social creative base
- short reel with kinetic text overlay
- thumbnail frame for outreach / loom / proposal deck

## Hard guardrails
- no extra video before first two images are validated
- no more than one short video in the first spend block
- no prompt drift away from calm premium trust aesthetic
- no text embedded in generations unless explicitly needed later
