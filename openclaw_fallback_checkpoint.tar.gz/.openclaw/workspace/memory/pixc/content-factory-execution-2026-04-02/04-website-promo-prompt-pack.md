# PixC Website Promo Prompt Pack

Aligned to overnight website direction:
- premium dark SaaS / Linear-Vercel aesthetic
- restrained cyber-trust undertone
- colors: #050816, #0B1220, #54E3FF, #7C8CFF
- positioning: safe, smart, animated digital systems that launch fast

## Generation order rule
1. Image 1
2. Image 2
3. Short video 1
4. More images only if budget remains

## Image Prompt 1 — Hero / Website Optics
Prompt:
Create a premium website-promo hero visual for PixC, a digital agency. 16:9 composition. Dark background #050816 fading into #0B1220. Subtle technical grid, cyan and indigo glow accents (#54E3FF and #7C8CFF), floating glassmorphism interface panels, minimal futuristic UI fragments, high-end SaaS trust aesthetic, Apple-meets-Linear restraint, cinematic but calm, crisp edges, no people, no text, no logos, no watermark. The image should feel like a premium website studio still that could be used on a landing page hero or paid social ad.

Recommended settings:
- Aspect ratio: 16:9
- Resolution: 1K for first pass, 2K if keeper
- Model preference: Nano Banana 2 equivalent if available; otherwise best available image generator
- Output file target: `pixc-promo-image-01-hero.png`

## Image Prompt 2 — Systems / Service Stack
Prompt:
Create a coordinated premium promo visual for PixC showing the idea of websites, automation systems, and content engines in one scene. 16:9 composition. Dark void background #050816 with soft cyan and indigo ambient glow. Layered translucent cards, connected modules, subtle dashboard and landing-page motifs, premium UI architecture, minimal, polished, conversion-focused, no people, no text, no logos, no watermark. The image should feel like a smart, high-trust digital systems ad creative.

Recommended settings:
- Aspect ratio: 16:9
- Resolution: 1K for first pass, 2K if keeper
- Output file target: `pixc-promo-image-02-systems.png`

## Short Video Prompt 1 — Calm Premium Motion
Prompt:
Generate a short promo video for PixC, 5 to 8 seconds, 16:9, premium dark SaaS atmosphere. Start on a dark #050816 background with a faint grid and soft cyan-indigo glow. Floating translucent UI panels and interface fragments slowly assemble into a sharp premium website composition, while subtle connected system lines suggest automation and content flow. Motion should be restrained, elegant, and confident — no chaotic transitions, no flashy glitch effects, no text, no logos, no people, no watermark. End on a clean composed hero frame that feels trustworthy, modern, and expensive.

Recommended settings:
- Model: Kling 3.0 by default
- Duration: 5s or 8s max
- Output: 1080p
- Output file target: `pixc-promo-video-01-calm-assembly.mp4`

## Extra image prompts if budget remains

### Image Prompt 3 — Mobile + desktop duality
Create a premium promo image for PixC showing a refined desktop landing page and a coordinated mobile screen in one composition. Dark background, cyan-indigo glow, restrained depth, premium SaaS mood, no text, no logos, no people, no watermark.
Output target: `pixc-promo-image-03-devices.png`

### Image Prompt 4 — Trust-first homepage section
Create a premium dark homepage section concept for PixC focused on trust, clarity, and launch readiness. Minimal cards, premium borders, cyan accent light, no text, no logos, no people, no watermark.
Output target: `pixc-promo-image-04-trust-section.png`

### Image Prompt 5 — Content engine visual
Create a premium abstract visual for PixC representing a content factory turning one website direction into multiple content outputs. Dark backdrop, modular cards, elegant flow lines, cyan-indigo accents, no text, no logos, no people, no watermark.
Output target: `pixc-promo-image-05-content-factory.png`

## Adaption notes
- These prompts are intentionally text-free so captions can be added in editing without locking typography into the generation.
- Use the same color system across all generations to keep the brand world coherent.
- If one image comes out too "sci-fi" or too dashboard-heavy, push it back toward calm premium website mood, not software UI overload.
