# PixC UGC / Ad Angle Bank

## Angle 1 — Founder frustration
Core emotion: "we've outgrown this cheap-looking site"

UGC setup:
Founder on camera saying the business is real but the website makes it look smaller and less trustworthy than it is.

Best use:
- direct response ad
- founder-led short
- before/after promo

## Angle 2 — Premium without bloat
Core emotion: calm confidence

UGC setup:
Voiceover or on-camera line explaining that premium websites are usually cleaner, calmer, and more controlled than flashy overdesigned pages.

Best use:
- authority reel
- design opinion piece
- awareness ad

## Angle 3 — Small team unfair advantage
Core emotion: leverage

UGC setup:
Frame PixC as the way a lean team gets the optics and systems of a much larger company.

Best use:
- service explainer
- agency positioning ad
- landing page promo

## Angle 4 — Website + automation bundle
Core emotion: smart operator energy

UGC setup:
Show that the site is only one layer; the real win is a cleaner front-end plus cleaner internal workflow.

Best use:
- B2B outbound creative
- retargeting ad
- case-style explainer

## Angle 5 — One direction, many outputs
Core emotion: efficiency

UGC setup:
Explain how a single website direction can be turned into ads, promos, hooks, and a content pipeline.

Best use:
- content service cross-sell
- process showcase
- behind-the-scenes ad

## Angle 6 — Trust-first web design
Core emotion: safety

UGC setup:
Talk about what makes a homepage feel safe instantly: clarity, hierarchy, structure, proof, and no weird gimmicks.

Best use:
- website teardown clips
- educational ads
- founder thought-leadership

## Angle 7 — Bangladesh-to-global edge
Core emotion: underdog strength

UGC setup:
Position PixC as lean, fast, globally credible execution built outside the usual bloated-agency centers.

Best use:
- founder story
- brand video
- authority narrative

## 12 quick ad concepts
1. Talking-head: "your business is better than your website looks"
2. Screen-record teardown with voiceover
3. Carousel ad: cluttered homepage vs restrained premium homepage
4. Motion graphic: website, automation, content engine triangle
5. Founder POV: "over-animation kills trust"
6. Fake-not-fake style concept: calm premium UI with sharp copy overlays added later in edit
7. Before/after wireframe to polished section reveal
8. UGC line: "we didn't need more traffic, we needed a site people trusted"
9. Ops-focused ad: "one automation saved more time than another hire"
10. Promo reel from generated stills plus kinetic typography
11. Website hero zoom with VO about 'safe, smart, animated systems'
12. Retargeting clip: "still thinking about rebuilding your site?"

## First 5 angles to produce
- Founder frustration
- Premium without bloat
- Small team unfair advantage
- Trust-first web design
- One direction, many outputs
