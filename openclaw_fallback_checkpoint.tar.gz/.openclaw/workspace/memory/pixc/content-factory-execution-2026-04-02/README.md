# PixC Content Factory — Execution Layer v1

Created: 2026-04-02 UTC
Source direction: `memory/pixc/clients/pixc-overnight/`
Status: Ready for immediate use tomorrow

## Purpose
This folder is the first practical content-factory execution layer for PixC, built from the overnight website direction and aligned to Himel's default media generation rule:

1. generate 2 images first
2. then generate 1 short video
3. then spend remaining budget on more images

## What is inside
- `01-content-pillars.md` — content strategy pillars rooted in PixC's actual offer
- `02-hook-bank-v1.md` — first bank of short-form hooks
- `03-ugc-and-ad-angle-bank.md` — UGC / paid-ad / founder-led angle bank
- `04-website-promo-prompt-pack.md` — locked prompt pack for image + short-video generation
- `05-low-budget-generation-plan.md` — exact low-budget production sequence
- `06-generation-queue.json` — ready-to-run queue spec
- `07-captions-and-cta-bank.md` — website-promo captions and CTA lines
- `08-tomorrow-ops-checklist.md` — execution checklist for the next session
- `09-generation-attempt-log.md` — notes on real-generation attempt status tonight

## Real generation status tonight
Attempted real image generation through available OpenClaw image providers.

Result:
- Google image generation available but returned HTTP 429 quota exceeded
- OpenAI image generation path requires an API key for `openai/gpt-image-1` in this environment
- No successful real asset generation completed tonight from the configured stack

Because of that, this folder includes the exact ready-to-run prompt stack and queue so execution can resume immediately once quota or provider auth is restored.

## Recommended first action tomorrow
Run the 2-image block first using the prompts in `04-website-promo-prompt-pack.md`, then continue with the 1 short-video prompt, then branch into extra images if budget remains.
