# PixC Tomorrow Ops Checklist

## Immediate
- Open this folder first
- Run the 2-image block from the prompt pack
- Save outputs into a sibling `generated/` folder if generation succeeds
- Compare image 1 vs image 2 for keeper direction

## After first image review
- Choose the stronger visual language
- Tune the short-video prompt to lean toward that winner
- Generate exactly 1 short video

## If budget remains
- Generate the devices visual
- Generate the content-factory visual
- Skip extra motion unless there is a clear reason

## Fast repurposing tasks
- Put the best still behind a website section or case-study placeholder
- Turn best still into one Instagram post / cover
- Make one short reel by combining still(s) + kinetic text + CTA
- Use one asset in proposal or outreach deck

## Copy tasks
- Pull 3 hooks from `02-hook-bank-v1.md`
- Pair them with 3 captions from `07-captions-and-cta-bank.md`
- Turn one asset into an ad test and one into an organic post

## If generation still fails tomorrow
- Verify provider quota / auth first
- Retry the queue in same order
- Do not redesign the prompt stack before one clean run
