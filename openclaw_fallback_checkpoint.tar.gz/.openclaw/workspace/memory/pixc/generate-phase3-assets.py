#!/usr/bin/env python3
"""
PixC Phase 3 Asset Generation
Minimal WaveSpeed API client for Nano Banana 2 images and Kling 3.0 video
"""

import os
import json
import time
import requests
from datetime import datetime
from pathlib import Path

# Config
API_TOKEN = os.environ.get("WAVESPEED_API_TOKEN")
API_BASE = "https://api.wavespeed.ai/api/v3"
WORKSPACE = Path("/home/himel/.openclaw/workspace/memory/pixc")
OUTPUT_DIR = WORKSPACE / "phase3-outputs"
LOG_FILE = WORKSPACE / "phase3-execution.log"

# Ensure output directory
OUTPUT_DIR.mkdir(exist_ok=True, parents=True)

def log(msg):
    """Log to both console and file"""
    timestamp = datetime.utcnow().isoformat()
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def call_wavespeed(endpoint, payload, asset_name):
    """Call WaveSpeed API and poll for result"""
    log(f"Generating {asset_name}...")
    
    headers = {
        "Authorization": f"Bearer {API_TOKEN}",
        "Content-Type": "application/json"
    }
    
    try:
        # Submit job
        resp = requests.post(
            f"{API_BASE}{endpoint}",
            json=payload,
            headers=headers,
            timeout=30
        )
        
        if resp.status_code not in [200, 201, 202]:
            log(f"ERROR: {asset_name} submit failed with status {resp.status_code}: {resp.text}")
            return None
        
        resp_data = resp.json()
        data = resp_data.get("data", resp_data)
        request_id = data.get("id") or data.get("request_id")
        
        if not request_id:
            log(f"ERROR: No request_id in response for {asset_name}: {resp_data}")
            return None
        
        log(f"✓ Submitted {asset_name}, request_id={request_id}")
        log(f"  Polling for result...")
        
        # Poll for completion
        for attempt in range(120):  # 10 minute timeout (5s * 120)
            time.sleep(5)
            poll_resp = requests.get(
                f"{API_BASE}/predictions/{request_id}/result",
                headers=headers,
                timeout=30
            )
            
            if poll_resp.status_code == 200:
                poll_resp_data = poll_resp.json()
                poll_data = poll_resp_data.get("data", poll_resp_data)
                status = poll_data.get("status") or poll_data.get("state")
                
                if status in ["completed", "success"]:
                    log(f"✓ {asset_name} completed in {(attempt+1)*5}s")
                    return poll_data
                elif status == "failed":
                    log(f"ERROR: {asset_name} generation failed: {poll_data.get('error', 'unknown')}")
                    return None
                else:
                    # Still processing
                    if attempt % 6 == 0:  # Log every 30s
                        log(f"  ... still processing ({(attempt+1)*5}s elapsed, status={status})")
        
        log(f"ERROR: {asset_name} timed out after 10 minutes")
        return None
        
    except Exception as e:
        log(f"ERROR: Exception generating {asset_name}: {str(e)}")
        return None

def download_file(url, filename):
    """Download URL to file"""
    try:
        resp = requests.get(url, timeout=60)
        if resp.status_code == 200:
            output_file = OUTPUT_DIR / filename
            with open(output_file, "wb") as f:
                f.write(resp.content)
            log(f"✓ Downloaded {filename} ({len(resp.content)} bytes)")
            return str(output_file)
        else:
            log(f"ERROR: Download failed for {filename}: status {resp.status_code}")
            return None
    except Exception as e:
        log(f"ERROR: Exception downloading {filename}: {str(e)}")
        return None

def main():
    log("="*60)
    log("PixC Phase 3 Asset Generation START")
    log(f"Workspace: {WORKSPACE}")
    log(f"Output dir: {OUTPUT_DIR}")
    
    if not API_TOKEN:
        log("ERROR: WAVESPEED_API_TOKEN not set")
        return False
    
    log(f"API Token (first 16 chars): {API_TOKEN[:16]}...")
    
    results = {}
    
    # Asset 1: Nano Banana 2 - Hero grid
    asset1_payload = {
        "prompt": "A dark, sophisticated abstract visualization of interconnected data flows and secure digital architecture. Dominant colors: deep navy (#0B1220) background with accents of cyan (#54E3FF) and soft blue (#7C8CFF) geometric nodes and connecting lines. Style: clean, minimal grid-based design with subtle glow effects on connection points. The composition suggests a secure network or encrypted communication system with premium, trustworthy aesthetics. Motion implied through directional flow lines but static image. No text, no people, no branding. Professional, calming, technical. Premium SaaS aesthetic.",
        "resolution": "1k",
        "aspect_ratio": "16:9",
        "output_format": "png",
        "enable_sync_mode": False,
        "enable_base64_output": False
    }
    
    log("\n[ASSET 1] Nano Banana 2 - Hero Grid")
    result1 = call_wavespeed("/google/nano-banana-2/text-to-image", asset1_payload, "Asset 1 (Nano Banana 2 hero grid)")
    if result1:
        # WaveSpeed response has outputs array or direct image_url
        url1 = None
        if "outputs" in result1 and result1["outputs"]:
            url1 = result1["outputs"][0] if isinstance(result1["outputs"][0], str) else result1["outputs"][0].get("url")
        if not url1:
            url1 = result1.get("image_url") or result1.get("output", {}).get("image_url")
        
        if url1:
            path1 = download_file(url1, "hero-grid-bg.png")
            results["image_1"] = {
                "name": "Hero Grid Background",
                "url": url1,
                "path": path1,
                "status": "success"
            }
        else:
            log(f"ERROR: No image_url in result for Asset 1: {result1}")
            results["image_1"] = {"status": "failed", "error": "No URL in response"}
    else:
        results["image_1"] = {"status": "failed", "error": "Generation failed"}
    
    # Asset 2: Nano Banana 2 - Process layers
    asset2_payload = {
        "prompt": "Abstract illustration of layered, stacked geometric shapes in a modern, minimalist style. Dominant colors: #0B1220 background with #54E3FF cyan, #7C8CFF blue, and touches of white geometric elements. The shapes suggest progression and iteration—like stages of a process or layers of a system. Style: clean, sharp lines, subtle shadows for depth, no gradients that distract. The overall feeling is methodical, trustworthy, and premium. Each layer slightly offset to imply movement and stages. Professional tech aesthetic. No people, no text, no branding. Suitable for use as a section accent or decorative visual element in a B2B SaaS layout.",
        "resolution": "1k",
        "aspect_ratio": "16:9",
        "output_format": "png",
        "enable_sync_mode": False,
        "enable_base64_output": False
    }
    
    log("\n[ASSET 2] Nano Banana 2 - Process Layers")
    result2 = call_wavespeed("/google/nano-banana-2/text-to-image", asset2_payload, "Asset 2 (Nano Banana 2 process layers)")
    if result2:
        # WaveSpeed response has outputs array or direct image_url
        url2 = None
        if "outputs" in result2 and result2["outputs"]:
            url2 = result2["outputs"][0] if isinstance(result2["outputs"][0], str) else result2["outputs"][0].get("url")
        if not url2:
            url2 = result2.get("image_url") or result2.get("output", {}).get("image_url")
        
        if url2:
            path2 = download_file(url2, "process-layers-accent.png")
            results["image_2"] = {
                "name": "Process Layers Accent",
                "url": url2,
                "path": path2,
                "status": "success"
            }
        else:
            log(f"ERROR: No image_url in result for Asset 2: {result2}")
            results["image_2"] = {"status": "failed", "error": "No URL in response"}
    else:
        results["image_2"] = {"status": "failed", "error": "Generation failed"}
    
    # Asset 3: Kling 3.0 - Hero motion (requires Asset 1)
    # Only proceed if Asset 1 succeeded
    if results.get("image_1", {}).get("status") == "success" and results["image_1"].get("url"):
        image_url = results["image_1"]["url"]
        asset3_payload = {
            "image": image_url,
            "prompt": "Starting from a dark navy digital grid background (#0B1220) with cyan and blue geometric nodes and connecting lines, animate the following sequence over 6 seconds: (1) Subtle pulsing glow on the connection points, cycling through cyan then blue then white, slow rhythm (2-3 second waves). (2) Very subtle horizontal data flow lines moving left-to-right across the grid, suggesting secure information transmission. (3) Occasional nodes lighting up in sequence, as if verifying a secure connection. (4) The entire composition maintains a calm, premium, trustworthy aesthetic—never chaotic or jarring. (5) Smooth, hardware-accelerated motion. Professional SaaS premium feel. Camera static, wide view. Loopable seamlessly.",
            "duration": 6,
            "cfg_scale": 0.5,
            "shot_type": "customize",
            "enable_audio": False
        }
        
        log("\n[ASSET 3] Kling 3.0 - Hero Motion (6s video)")
        log(f"  Using image URL: {image_url}")
        result3 = call_wavespeed("/kwaivgi/kling-v3.0-std/image-to-video", asset3_payload, "Asset 3 (Kling 3.0 hero motion)")
        if result3:
            # WaveSpeed response has outputs array or direct video_url
            url3 = None
            if "outputs" in result3 and result3["outputs"]:
                url3 = result3["outputs"][0] if isinstance(result3["outputs"][0], str) else result3["outputs"][0].get("url")
            if not url3:
                url3 = result3.get("video_url") or result3.get("output", {}).get("video_url")
            
            if url3:
                path3 = download_file(url3, "hero-motion.mp4")
                results["video_1"] = {
                    "name": "Hero Motion Sequence",
                    "url": url3,
                    "path": path3,
                    "duration": 6,
                    "status": "success"
                }
            else:
                log(f"ERROR: No video_url in result for Asset 3: {result3}")
                results["video_1"] = {"status": "failed", "error": "No URL in response"}
        else:
            results["video_1"] = {"status": "failed", "error": "Generation failed"}
    else:
        log("SKIPPING Asset 3 (Kling video) - Asset 1 (hero grid) not ready")
        results["video_1"] = {"status": "skipped", "reason": "Asset 1 prerequisite failed"}
    
    # Write results summary
    summary_file = WORKSPACE / "phase3-results.json"
    with open(summary_file, "w") as f:
        json.dump(results, f, indent=2)
    
    log(f"\n✓ Results saved to {summary_file}")
    log("\n" + "="*60)
    log("PHASE 3 EXECUTION SUMMARY")
    log("="*60)
    
    for key, val in results.items():
        status = val.get("status", "unknown")
        name = val.get("name", key)
        log(f"{name}: {status}")
        if status == "success":
            log(f"  URL: {val.get('url', 'N/A')}")
            log(f"  Path: {val.get('path', 'N/A')}")
    
    complete = all(
        v.get("status") == "success" 
        for v in results.values()
    )
    
    log(f"\nGeneration Complete: {complete}")
    log("="*60)
    
    return complete

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
