# Luna Token & Context Optimization Doctrine
Date: 2026-04-05 | Source: Anthropic docs + production research
Status: CANONICAL — enforced at all times across all agents and sessions

## 1. Model Routing (Hard Rules)
- luna/main/elon/mark → openai-codex/gpt-5.4 (free via OpenAI Plus)
- ernest → anthropic/claude-haiku-4-5-20251001 (triage + APG compression)
- sun-tzu → anthropic/claude-sonnet-4-6 (strategy only, used sparingly)
- a → anthropic/claude-haiku-4-5-20251001 (security, not sonnet)
- heartbeat/cron → ollama/llama3.2:3b (free local)
- agents.defaults.primary = haiku (fallback for anything not explicitly set)
- NEVER use Sonnet for anything that haiku or codex can handle

## 2. Prompt Caching (Anthropic API) — 90% cost reduction on repeated context
Cache hierarchy: tools → system → messages (prefix-match, must be identical)
Rules:
- Always place SOUL.md + AGENTS.md + static context at TOP of system prompt
- Mark end of static content with cache_control: {"type":"ephemeral","ttl":"1h"}
- Minimum 1024 tokens to cache (haiku needs 2048)
- Cache breakpoints are FREE — only pay for writes (1.25x) and reads (0.1x)
- 1-hour TTL for sessions > 30 min (2x write, but saves repeated writes)
- 5-min TTL for short tasks (1.25x write, reads at 0.1x)
- Never put timestamps in system prompts (breaks cache every session)
- Never put dynamic content before static content (invalidates whole cache)
- Put tool definitions first — they never change
- Put SOUL.md + memory context second
- Put conversation history last (dynamic)

## 3. Context Window Management
- Ernest (APG compressor) MUST run before any Sonnet/sub-agent spawn
- Ernest summarizes conversation to <500 tokens before passing to sun-tzu
- Sub-agents receive compressed context only — never raw conversation
- Max context per sub-agent call: 8000 tokens input
- If context > 80%: Ernest triggers compression pass automatically
- Session state written to Supabase + Qdrant before context approaches limit

## 4. Memory Architecture (Unified Cross-Platform)
Luna's memory is the same whether she's on Telegram or UI. Rules:
- Every session: write summary to Supabase luna_memory_vault table
- Every new session: read last 5 entries from luna_memory_vault on startup
- Qdrant: embed key decisions, techniques, client context for semantic recall
- Neo4j: relationship graph — entities, decisions, dependencies
- mem0: session-level recall, feeds from Supabase cold storage
- The system prompt for EVERY agent must load: SOUL.md + AGENTS.md + last memory

## 5. Cross-Platform Memory Sync (Telegram ↔ UI)
Problem fixed: Telegram and UI were running separate brain.
Solution: Both read/write from the SAME Supabase luna_memory_vault.
- On startup (any platform): SELECT * FROM luna_memory_vault ORDER BY created_at DESC LIMIT 5
- On session end (any platform): INSERT into luna_memory_vault (summary, platform, context_tags)
- On task completion: write to tasks table with status + summary
- n8n webhook triggers memory write after every Telegram message processed

## 6. Batch API (50% discount for non-urgent work)
- Research tasks, QDE scoring, content generation → use Anthropic Batch API
- Not for real-time Telegram responses
- Batch endpoint: /v1/messages/batches
- Use for: scraping analysis, overnight research, content pipeline

## 7. Cost Guard Rails
- Daily cost alert: if Anthropic spend > $3/day → Telegram alert to Himel
- Weekly cap: $15/week hard limit (n8n workflow monitors via usage API)
- On cap hit: routes to ollama/codex only until reset
- Cost ledger: every API call logs to Supabase cost_ledger table
