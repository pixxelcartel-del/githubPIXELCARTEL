# PixC Website Build — Autonomous Agent SOP
Date: 2026-04-05 | Status: ACTIVE
Trigger: Luna initiates this SOP on receiving "build pixc site" instruction
Execution: Fully autonomous. No human input required until Telegram approval gate.

---

## AGENT ASSIGNMENTS
- **Luna** — Orchestrator. Delegates, monitors, reports to Himel
- **Sun Tzu** (Sonnet) — Strategy: competitor research, brief, final approval
- **Mark** (Codex) — Website builder: HTML/CSS/JS, all 7 sections
- **Elon** (Codex) — Tech: GitHub repo, Lighthouse audit, Vercel CLI deploy
- **Ernest** (Haiku) — Compression: context cleanup between steps

## PHASE 1 — Competitor Research (Sun Tzu leads)
Sun Tzu uses Exa MCP to scrape 5 top digital agency sites:
Targets: webflow.com, superside.com, ueno.co, instrument.com, halo.studio
Extract per site:
- Hero copy pattern (headline formula)
- Trust signals used (numbers, logos, case studies)
- Services framing (how they describe offerings)
- CTA mechanism (email, form, calendly)
- Visual style (dark/light, colors, fonts observed)

Output: Write `memory/pixc/COMPETITOR-INTEL-{date}.md`
Pass to Mark as brief context.

## PHASE 2 — Site Brief (Sun Tzu)
Produce a tight build brief for Mark:
- Final section order (based on competitor research + AntiGravity SOP)
- Headline direction (unique angle vs competitors)
- Trust proof approach (what PixC can credibly claim)
- CTA mechanism decision
- Motion restraint rules (cinematic, not decorative)
- Asset slots: logo → /assets/pixc-logo.jpg | portrait → /assets/himel-portrait.jpg

Output: Write `memory/pixc/PIXC-SITE-BRIEF-{date}.md`

## PHASE 3 — Build (Mark leads, Elon assists)
Mark builds the full site:
Stack: Pure HTML + CSS + vanilla JS (no build tools — Vercel handles static)
Required files:
  - index.html (all sections, single page)
  - styles.css (external, clean separation)
  - assets/ (logo + portrait already present)
  - robots.txt
  - sitemap.xml

Required sections (in order):
  1. Nav (fixed, logo + links + CTA button)
  2. Hero (headline, subheadline, dual CTA, 4 proof stats)
  3. Trust Strip (4 trust signals, horizontal)
  4. Services (3 cards: Websites, Automations, Content)
  5. Process (4-step narrative)
  6. Founder (portrait + copy + founder quote)
  7. FAQ (5+ items, accordion)
  8. CTA Footer (email input + submit)
  9. Footer (logo, copyright, links)

Design rules (non-negotiable):
  - Dark: bg #050816, surface #0a0e27
  - Accent: #6c63ff (purple), #4ade80 (green for live dot)
  - Fonts: Inter (body) + Space Grotesk (headings)
  - All animations: transform + opacity only
  - prefers-reduced-motion implemented
  - Mobile first, min-width 320px

Output: Write files to `memory/pixc/clients/pixc-overnight/site/`

Ernest compresses Mark's output report before passing to Elon.

## PHASE 4 — Technical Audit (Elon)
Elon runs Lighthouse against preview:
  cd /tmp/pixc-site && npx serve . -p 4321 &
  npx lighthouse http://localhost:4321 --output json --output-path /tmp/lh-report.json
  cat /tmp/lh-report.json | python3 -c "import json,sys; r=json.load(sys.stdin); cats=r['categories']; [print(k,v['score']*100) for k,v in cats.items()]"

Required scores: performance≥90, accessibility≥95, best-practices≥95, seo≥95

Manual checklist review: Elon scores Sections A+B, Mark scores C+D+E
Total score written to: `memory/pixc/BENCHMARK-SCORE-{date}.md`

If score <49/50: identify failing checks, route back to Mark for fix, re-run.
If score ≥49/50: proceed to deploy.

## PHASE 5 — GitHub + Vercel Deploy (Elon)
EXACT deployment sequence:

```bash
# 1. Init git repo
cd /home/himel/.openclaw/workspace/memory/pixc/clients/pixc-overnight/site
git init
git add .
git commit -m "feat: PixC agency site v1 — {date}"

# 2. Create GitHub repo via CLI
gh repo create pixelcartel/pixc-site --public --source=. --remote=origin --push

# 3. Deploy to Vercel as NEW project via CLI
cd /home/himel/.openclaw/workspace/memory/pixc/clients/pixc-overnight/site
npx vercel --yes --prod --token=$VERCEL_TOKEN

# 4. Capture live URL from vercel output
# Format: https://pixc-site-{hash}.vercel.app or custom if configured
```

Note: This creates a NEW Vercel project (not the old pixc-overnight hook).
Vercel CLI method is the canonical deploy path.

Output: Write live URL to `memory/pixc/DEPLOYMENT-REGISTRY.md`

## PHASE 6 — Final Report to Himel (Luna)
Luna sends Telegram message:
```
✅ PixC site deployed

Score: {X}/50 ({pct}%)
Live URL: {vercel_url}

Benchmark breakdown:
• Performance: {score}/10
• SEO: {score}/10
• Design: {score}/10
• Mobile/A11y: {score}/10
• Content/Trust: {score}/10

Competitor intel: {n} sites analyzed
Build time: {duration}

Ready for review. Awaiting your approval to lock domain.
```

---

## ERROR HANDLING
- Any phase fails → Ernest summarizes, Luna routes fix to correct agent
- Score <49 → Mark re-runs specific failing sections only (not full rebuild)
- Vercel CLI fails → fallback to deploy hook (document reason)
- GitHub CLI fails → create manually, document, continue with Vercel deploy

## NEVER DO
- Never deploy before benchmark score ≥49/50
- Never use placeholder content or lorem ipsum
- Never use the old pixc-overnight deploy hook as primary method
- Never skip competitor research phase
- Never show raw sub-agent output to Himel — Luna rewrites in her voice
