# Secrets To Set For PixC Automation

Date: 2026-04-02
Status: active

## WaveSpeed
Configured key:

WAVESPEED_API_KEY=549f6f9b3bbe61bd15d29c544169a835c6529d3ce56ba90d7e040a20190fbe15

Runtime alias already present:
- WAVESPEED_API_TOKEN=<configured in openclaw.json>

## Vercel
Known values:
- VERCEL_PROJECT_ID=prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH
- DEPLOY_HOOK_URL=https://api.vercel.com/v1/integrations/deploy/prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH/pEXl3TsBbk
- runtime alias already present: VERCEL_API_TOKEN=<configured in openclaw.json>

Optional for cleaner full metadata later:
- VERCEL_ORG_ID=<optional for now if personal account deploy-hook flow is enough>

## Recommended placement
- n8n credential/env store for execution
- optional shell env for local helper scripts

## Important note
For routine redeploys, the Deploy Hook URL is enough.
VERCEL_ORG_ID is not a blocker for deploy-hook-based automation.
