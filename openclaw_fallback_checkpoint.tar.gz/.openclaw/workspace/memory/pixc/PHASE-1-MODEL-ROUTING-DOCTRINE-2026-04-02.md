# Phase-1 Model Routing Doctrine

Date: 2026-04-02
Owner: Luna
Status: canonical

## Direct chat
- Luna main/direct chat -> GPT-5.4

## Heartbeats and cheap background work
- Heartbeats -> Ollama llama3.2:3b
- Cheap/routine background subagent work -> Haiku baseline

## Sonnet role
Use Sonnet generally for:
- planning
- research
- analysis
- orchestration
- decision making
- critique
- decomposition
- high-judgment review

Primary owners:
- sun-tzu -> Sonnet primary
- a -> Sonnet primary
- elon/mark when the task is planning, critique, architecture, or judgment-heavy rather than direct implementation

## Codex role
Use Codex generally for:
- coding
- debugging
- direct implementation
- execution-heavy engineering
- execution-heavy frontend/product build work

Primary owners:
- elon -> Codex primary for implementation/debugging
- mark -> Codex primary for website/frontend implementation

## Workflow doctrine
- Sonnet thinks, scopes, critiques, and guides
- Codex builds, debugs, executes, and patches
- Haiku handles cheap background work when the task does not justify a stronger model

## Graceful fallbacks
- Sonnet lane fallback: Codex -> Haiku
- Codex lane fallback: Sonnet -> Haiku
- Haiku lane escalation: Sonnet or Codex depending on specialty

## Troubleshooting loop
If delegated work fails before task execution:
1. treat it as routing/control-plane issue first
2. validate openclaw.json and gateway health
3. verify intended agent model/fallback chain
4. retry with the same agent only after control-plane validation
5. if still failing, dispatch diagnosis to sun-tzu on Sonnet once the lane is healthy
6. then let elon/mark execute on Codex or Sonnet according to task type
