# Tutorial Triage — Batch 01

## Status
This is a metadata-blind first-pass triage built from the raw queued YouTube links currently recorded in `memory/pixc/RESOURCES.md`.

Important: this is a provisional routing document, not a final topical truth map. Until title/description/metadata/transcript scraping is completed, the priority and clustering below should be treated as an optimization hypothesis for efficient scraping order.

## Queue Summary
- Total unique queued YouTube links: 27
- One raw duplicate was already collapsed at intake level: `eH8JdttKIdA`
- Current queue source: `memory/pixc/RESOURCES.md`

## Raw Deduplicated Queue
| # | Video ID | URL |
|---|---|---|
| 1 | QiHXlY1EaB4 | https://youtu.be/QiHXlY1EaB4 |
| 2 | K0j_ADBkN9I | https://youtu.be/K0j_ADBkN9I |
| 3 | C3-4llQYT8o | https://youtu.be/C3-4llQYT8o |
| 4 | HJ-dwefABss | https://youtu.be/HJ-dwefABss |
| 5 | eH8JdttKIdA | https://youtu.be/eH8JdttKIdA |
| 6 | ZeJXI2MAhj0 | https://youtu.be/ZeJXI2MAhj0 |
| 7 | n3o8MgaNRE4 | https://youtu.be/n3o8MgaNRE4 |
| 8 | vXylQqxsGX0 | https://youtu.be/vXylQqxsGX0 |
| 9 | uD7prXJCRY0 | https://youtu.be/uD7prXJCRY0 |
| 10 | 1aI7pAlkz4w | https://youtu.be/1aI7pAlkz4w |
| 11 | wQ0duoTeAAU | https://youtu.be/wQ0duoTeAAU |
| 12 | wqH1hTkA6qg | https://youtu.be/wqH1hTkA6qg |
| 13 | tDGiWn0flK8 | https://youtu.be/tDGiWn0flK8 |
| 14 | TZUTe7s11-I | https://youtu.be/TZUTe7s11-I |
| 15 | cNf7uVff11Y | https://youtu.be/cNf7uVff11Y |
| 16 | rp6_d6sNYXY | https://youtu.be/rp6_d6sNYXY |
| 17 | SK_sSNyJ758 | https://youtu.be/SK_sSNyJ758 |
| 18 | _rZAR-s4KIo | https://youtu.be/_rZAR-s4KIo |
| 19 | g_zZj8WGncA | https://youtu.be/g_zZj8WGncA |
| 20 | q0TgUtj6vIs | https://youtu.be/q0TgUtj6vIs |
| 21 | r2-1c_T6F34 | https://youtu.be/r2-1c_T6F34 |
| 22 | iTKkoGd3YcM | https://youtu.be/iTKkoGd3YcM |
| 23 | csOEsfiBfvo | https://youtu.be/csOEsfiBfvo |
| 24 | nhibi9TRgNc | https://youtu.be/nhibi9TRgNc |
| 25 | _vPzDfA0t7w | https://youtu.be/_vPzDfA0t7w |
| 26 | bhPHwVsrTo0 | https://youtu.be/bhPHwVsrTo0 |
| 27 | KtAGjnWViMQ | https://youtu.be/KtAGjnWViMQ |

## Provisional Topic Clusters
Until metadata is fetched, the queue should be routed through these topic buckets during the first real scraping pass.

| Cluster ID | Topic Cluster | Why It Exists |
|---|---|---|
| C01 | Website Build / Design Systems | likely high-value for PixC build quality and implementation |
| C02 | Asset Generation / 3D / Visual Prompting | directly affects hero assets, AntiGravity outputs, image/video generation |
| C03 | Scraping / Research / Competitive Intel | strengthens discovery, benchmarking, and automation |
| C04 | QA / SEO / Audit | directly improves deliverable quality and conversion readiness |
| C05 | Automation / Tooling / Agent Workflows | improves throughput and reusable system leverage |
| C06 | Client Ops / Portal / CMS / Change Requests | supports client management model and post-build workflow |
| C07 | Outreach / Lead Gen / Bad Site Detection | useful for demand generation after PixC core system is stable |
| C08 | Socials / Content Systems | second-priority lane per Himel instruction |
| C09 | Business Models / Monetization / Opportunity | capture adjacent scalable income or productized service ideas |
| C10 | Misc / Needs Metadata | temporary holding bucket when topic cannot be safely inferred |

## Priority Framework
Priority must reflect Himel’s explicit routing rule:
1. PixC build value first
2. content/socials second
3. maximize full-system leverage where it is strong enough

### Priority Weights
| Tier | What Gets Pulled Up |
|---|---|
| P1 | Anything likely to improve M05-M07 and Phase 0B/1 immediately |
| P2 | Anything strengthening M02/M03/M11 (scraping, intelligence, automation) |
| P3 | Anything strengthening M08/M09/M12 (client ops, lead gen, opportunity capture) |
| P4 | Social/content items unless they reveal major cross-system leverage |

### Current Routing Assumption
Without metadata, assume the first likely winners will come from:
- website build / design systems
- asset generation / AntiGravity / 3D
- scraping / research / automation
- QA / SEO / audit

## Phased Scrape Order
This is the actual efficient batch strategy.

### Phase A — Metadata Pass (all 27)
Goal:
- fetch title
- fetch channel
- fetch description if available
- detect obvious resource links in descriptions
- detect duplicates or near-duplicates by topic
- assign each video to a real cluster

Output:
- topic-labeled queue
- first free-resource index entries
- candidate shortlist for transcript pass

### Phase B — Top Cluster Transcript Pass
Goal:
- scrape full transcripts only for the highest-value tutorials after Phase A
- extract durable lessons, settings, prompts, workflows, tools, and resource mentions
- log any visible-but-not-spoken likely assets for screenshot review

Output:
- topic synthesis docs
- best-practice extraction notes
- updates to `RESOURCES.md`

### Phase C — Screenshot / Visual Extraction Pass
Goal:
- only run on videos that appear to contain visible prompts/configs not fully spoken aloud
- capture timestamps and what needs image/screenshot extraction

Output:
- screenshot extraction queue
- manual asset requests if Luna cannot extract directly

### Phase D — Cross-Tutorial Synthesis
Goal:
- merge tutorials on the same task into one chosen PixC/Luna best-practice
- reject weaker or redundant patterns
- map adopted methods to workflow modules

Output:
- best-practice module updates
- adaptation log entries
- opportunity log entries

## Recommended Parallelization Plan
Use parallel subagents only where the work naturally splits.

### Lane 1 — Metadata & Resource Harvest
Best for fast first pass across all links.

### Lane 2 — High-Priority Transcript Extraction
Run only on shortlisted videos from the top-ranked clusters.

### Lane 3 — Resource System Maintenance
Update `RESOURCES.md`, manual-download queue, screenshot queue, and module mapping as structured outputs come in.

### Lane 4 — Synthesis / Governance
Merge duplicate lessons into one adopted pattern and ensure memory durability.

## Batch-01 Execution Rules
- Do not transcript-scrape all 27 immediately.
- Do not let overlapping tutorials create duplicate guidance.
- Do not bury free resources inside transcript notes.
- Every resource must be indexed with source link, intended module use, and status.
- Every good lesson must either be adopted, parked, or rejected explicitly.

## Immediate Next Action
Run a metadata/title/description/resource-link pass across all 27 queued videos, then sort them into the real topic clusters before spending more tokens on transcript extraction.
