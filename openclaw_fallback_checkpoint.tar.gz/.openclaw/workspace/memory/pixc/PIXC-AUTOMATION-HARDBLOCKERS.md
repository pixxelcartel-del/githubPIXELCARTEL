# PixC Automation Hardblockers

Date: 2026-04-02
Status: concrete blockers only

## Cleared
- canonical system plan written
- implementation checklist written
- dispatch layer repaired to live Phase-1 roster
- helper scripts created for non-interactive Vercel bootstrap / deploy-hook trigger / WaveSpeed submit
- n8n workflow specs written for image, video, and deploy automation
- deployment registry file created

## Current hard blockers

### 1. Personal-account org/team id not yet captured
Impact:
- low severity; does not block deploy-hook-based routine redeploys
- only matters for cleaner full Vercel metadata and some CLI/API flows

What resolves it:
- capture personal account/team id later from Vercel settings/API if needed

## Cleared during implementation
- PixC Vercel project id captured: prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH
- PixC Deploy Hook URL captured and stored
- runtime config already contains Vercel token under alias VERCEL_API_TOKEN
- runtime config already contains WaveSpeed token under alias WAVESPEED_API_TOKEN
- helper scripts updated to accept both canonical and aliased env names

## Cleared during implementation
- PixC Vercel project id captured: prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH
- PixC Deploy Hook URL captured and stored

## Exact next action once creds are available
1. store WAVESPEED_API_KEY and VERCEL_TOKEN in the actual execution environment
2. run scripts/vercel-bootstrap-noninteractive.sh against /home/himel/.openclaw/workspace/memory/pixc/clients/pixc-overnight/site only if CLI bootstrap still needs verification
3. wire n8n workflows from memory/pixc/N8N-WORKFLOW-SPECS.md
4. execute first two PixC Nano Banana 2 image jobs
5. execute first Kling 3.0 short video after image review
