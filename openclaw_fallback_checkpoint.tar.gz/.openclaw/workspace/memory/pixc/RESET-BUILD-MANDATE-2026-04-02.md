# Reset Build Mandate — 2026-04-02

Himel rejected the earlier PixC output as not meeting the actual requested standard.

## New objective
Do not treat the prior overnight site as the finished product.
Treat it as a failed/partial attempt.

## Required sequence now
1. Fix Vercel deployment path so launches are clean and functional
2. Run the real website-builder workflow SOP end-to-end
3. Generate / document the correct asset prompts and supporting sheet
4. Build the actual site
5. Polish and debug it
6. Run security audit and benchmark validation
7. Validate final output against checks
8. Only then present the hosted Vercel link

## Rule
No more pretending a structurally okay placeholder is a true handoff.
The new bar is full pipeline completion.
