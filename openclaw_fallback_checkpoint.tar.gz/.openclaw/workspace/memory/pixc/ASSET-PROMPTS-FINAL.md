# PixC Asset Prompts — Final Generation Sheet

**Date:** 2026-04-02  
**Phase:** Phase 2 — Final PixC Asset Prompt Sheet  
**Status:** Ready for immediate generation via WaveSpeed API  
**Client:** PixC (Internal Build)

---

## Brand & Tone Foundation

### Brand Context
PixC positions as a premium digital pioneering agency: fast-moving, agentic, technically sharp, visually elevated. Dark premium SaaS aesthetic with restrained motion, cybersecurity-grade trust cues, and clean execution discipline.

### Design System (AntiGravity 5D)
- **Pattern:** Agency / premium SaaS hybrid
- **Style:** Linear / Vercel-inspired dark premium SaaS + mild cyber-defense undertones
- **Colors:** Dark backgrounds (#050816, #0B1220), accent cyan (#54E3FF), accent blue (#7C8CFF)
- **Typography:** Space Grotesk (headings), Inter (body)
- **Motion:** Restrained, selective, purposeful (never decorative)

### Copy Tone Rules
- **Assertive, concise, no fluff**
- Premium agency polish + operational intelligence
- Competence first, spectacle second
- Systems-thinking language, not hype
- Trust through clarity, not decoration

### Quality Bar
- Minimum: Awwwards-grade execution
- Lighthouse 90+ or don't deploy
- Mobile-first, WCAG AA contrast (4.5:1)
- Transform + opacity animations only (GPU)
- prefers-reduced-motion always respected

---

## ASSET 1: Nano Banana 2 Image Prompt #1

### Purpose
Hero section background visualization: abstract grid/data flow aesthetic suggesting secure, connected systems. Will be deployed as a dark hero background layer or accent element.

### Technical Specs
- **Model:** Google Nano Banana 2 (via WaveSpeed)
- **Dimensions:** 1920 × 1080px (16:9 landscape)
- **Output Format:** PNG
- **Quality Target:** 1K quality, vibrant-but-restrained color

### Prompt Text

```
A dark, sophisticated abstract visualization of interconnected data flows and 
secure digital architecture. Dominant colors: deep navy (#0B1220) background with 
accents of cyan (#54E3FF) and soft blue (#7C8CFF) geometric nodes and connecting 
lines. Style: clean, minimal grid-based design with subtle glow effects on 
connection points. The composition suggests a secure network or encrypted 
communication system with premium, trustworthy aesthetics. Motion implied through 
directional flow lines but static image. No text, no people, no branding. 
Professional, calming, technical. Premium SaaS aesthetic.
```

### Idempotency Key
```
pixc-hero-grid-secure-v1-1080p-cyan-blue
```

### WaveSpeed API Snippet (Queue-Ready JSON)

```json
{
  "model": "google/nano-banana-2",
  "prompt": "A dark, sophisticated abstract visualization of interconnected data flows and secure digital architecture. Dominant colors: deep navy (#0B1220) background with accents of cyan (#54E3FF) and soft blue (#7C8CFF) geometric nodes and connecting lines. Style: clean, minimal grid-based design with subtle glow effects on connection points. The composition suggests a secure network or encrypted communication system with premium, trustworthy aesthetics. Motion implied through directional flow lines but static image. No text, no people, no branding. Professional, calming, technical. Premium SaaS aesthetic.",
  "width": 1920,
  "height": 1080,
  "num_inference_steps": 30,
  "guidance_scale": 7.5,
  "seed": 42,
  "idempotency_key": "pixc-hero-grid-secure-v1-1080p-cyan-blue"
}
```

### Deployment Target
- **File path:** `/assets/hero-grid-bg.png`
- **HTML integration:** Hero section background-image or canvas overlay layer
- **CSS consideration:** May pair with `backdrop-filter: blur()` for depth or `mix-blend-mode: screen/overlay` for glow reinforcement

---

## ASSET 2: Nano Banana 2 Image Prompt #2

### Purpose
Process/capabilities section accent visual: abstract layered shape composition suggesting workflow stages, iteration, and systematic improvement. Complements the "Why PixC Wins" messaging around clean build process and systems thinking.

### Technical Specs
- **Model:** Google Nano Banana 2 (via WaveSpeed)
- **Dimensions:** 1920 × 1080px (16:9 landscape)
- **Output Format:** PNG
- **Quality Target:** 1K quality, balanced color intensity

### Prompt Text

```
Abstract illustration of layered, stacked geometric shapes in a modern, 
minimalist style. Dominant colors: #0B1220 background with #54E3FF cyan, 
#7C8CFF blue, and touches of white geometric elements. The shapes suggest 
progression and iteration—like stages of a process or layers of a system. 
Style: clean, sharp lines, subtle shadows for depth, no gradients that 
distract. The overall feeling is methodical, trustworthy, and premium. 
Each layer slightly offset to imply movement and stages. Professional tech 
aesthetic. No people, no text, no branding. Suitable for use as a section 
accent or decorative visual element in a B2B SaaS layout.
```

### Idempotency Key
```
pixc-process-layers-v1-1080p-blue-cyan
```

### WaveSpeed API Snippet (Queue-Ready JSON)

```json
{
  "model": "google/nano-banana-2",
  "prompt": "Abstract illustration of layered, stacked geometric shapes in a modern, minimalist style. Dominant colors: #0B1220 background with #54E3FF cyan, #7C8CFF blue, and touches of white geometric elements. The shapes suggest progression and iteration—like stages of a process or layers of a system. Style: clean, sharp lines, subtle shadows for depth, no gradients that distract. The overall feeling is methodical, trustworthy, and premium. Each layer slightly offset to imply movement and stages. Professional tech aesthetic. No people, no text, no branding. Suitable for use as a section accent or decorative visual element in a B2B SaaS layout.",
  "width": 1920,
  "height": 1080,
  "num_inference_steps": 30,
  "guidance_scale": 7.5,
  "seed": 43,
  "idempotency_key": "pixc-process-layers-v1-1080p-blue-cyan"
}
```

### Deployment Target
- **File path:** `/assets/process-layers-accent.png`
- **HTML integration:** Process section hero image or split-screen visual companion
- **CSS consideration:** May use `object-fit: cover` or as a static accent card element

---

## ASSET 3: Kling 3.0 Motion Prompt

### Purpose
Premium hero motion sequence: elegant, subtle animation suggesting secure connection establishment, data flow, or system initialization. Plays as a looped background animation or short intro reveal. Will enhance trust and visual polish without overwhelming the page or slowing performance.

### Technical Specs
- **Model:** Kling 3.0 Standard (via WaveSpeed)
- **Duration:** 6 seconds (5–8s window, target middle for smooth loop)
- **Resolution:** 1080p (1920×1080)
- **Frame Rate:** 24fps (Kling default)
- **Shot Type:** Wide, static camera (no camera pan/zoom unless essential)
- **Audio:** Optional; if included, ambient tech/digital tone recommended
- **Loop Quality:** Must be seamless/loopable for repeated playback

### Base Image Source
Use ASSET 1 (hero-grid-secure) as the starting frame for Kling generation.

### Prompt Text

```
Starting from a dark navy digital grid background (#0B1220) with cyan and 
blue geometric nodes and connecting lines, animate the following sequence over 
6 seconds: (1) Subtle pulsing glow on the connection points, cycling through 
cyan then blue then white, slow rhythm (2-3 second waves). (2) Very subtle 
horizontal data flow lines moving left-to-right across the grid, suggesting 
secure information transmission. (3) Occasional nodes lighting up in sequence, 
as if verifying a secure connection. (4) The entire composition maintains a 
calm, premium, trustworthy aesthetic—never chaotic or jarring. (5) Smooth, 
hardware-accelerated motion. Professional SaaS premium feel. Camera static, 
wide view. Loopable seamlessly.
```

### Optional End Image
If Kling allows: same as base image (ensures seamless loop without jarring cut).

### Idempotency Key
```
pixc-hero-motion-secure-grid-6s-1080p
```

### WaveSpeed API Snippet (Queue-Ready JSON)

```json
{
  "model": "kwaivgi/kling-v3.0-std",
  "image": "/assets/hero-grid-bg.png",
  "prompt": "Starting from a dark navy digital grid background (#0B1220) with cyan and blue geometric nodes and connecting lines, animate the following sequence over 6 seconds: (1) Subtle pulsing glow on the connection points, cycling through cyan then blue then white, slow rhythm (2-3 second waves). (2) Very subtle horizontal data flow lines moving left-to-right across the grid, suggesting secure information transmission. (3) Occasional nodes lighting up in sequence, as if verifying a secure connection. (4) The entire composition maintains a calm, premium, trustworthy aesthetic—never chaotic or jarring. (5) Smooth, hardware-accelerated motion. Professional SaaS premium feel. Camera static, wide view. Loopable seamlessly.",
  "duration": 6,
  "cfg_scale": 7.0,
  "shot_type": "wide",
  "idempotency_key": "pixc-hero-motion-secure-grid-6s-1080p"
}
```

### Deployment Target
- **File path:** `/assets/hero-motion.mp4`
- **HTML integration:** Hero section `<video>` background or fullscreen overlay with muted autoplay
- **CSS/JS considerations:**
  - `<video muted autoplay loop playsinline>` for seamless looping
  - `will-change: transform` on parent container to ensure smooth playback
  - Optional: `loading="lazy"` if below fold
  - Fallback to ASSET 1 static image if video fails to load

---

## Generation Queue & Execution Plan

### Order of Operations
1. **Nano Banana 2 (Image 1)** – Hero grid background
2. **Nano Banana 2 (Image 2)** – Process layers accent
3. **Kling 3.0 (Video)** – Hero motion sequence (depends on Image 1 being ready)

### Quality Benchmarks

#### Nano Banana 2 Checks
- [ ] No watermarks or logos
- [ ] Correct aspect ratio (1920×1080, 16:9)
- [ ] Colors match spec: navy, cyan, blue dominant
- [ ] Professional, minimal, no fluff or realistic skies/environments
- [ ] 1K quality visible without pixelation
- [ ] Suitable for web (PNG, RGB, no embedded color profile bloat)

#### Kling 3.0 Checks
- [ ] 6-second duration ±0.5s
- [ ] 1080p resolution confirmed
- [ ] Motion is smooth, loopable, no jarring cuts
- [ ] Glow/flow effects visible but not overwhelming
- [ ] No audio artifacts (if audio included)
- [ ] MP4 codec, H.264 or better, <20MB for 6s optimal
- [ ] Plays seamlessly in browser `<video>` tag

### Failure Handling
- If image generation exceeds token/time budget, reduce `num_inference_steps` to 20
- If Kling video generation times out, retry with shorter duration (5s) or simpler prompt
- If colors are off, use `prompt_enhancer: true` in WaveSpeed API call to recalibrate color language

---

## Integration Checkpoints

### Phase 2 → Phase 3 Handoff Criteria
Before marking assets as "ready for site deployment":
1. All 3 assets generated and downloaded
2. Visual QA passed (benchmarks above)
3. File sizes and formats validated
4. Idempotency keys logged in DEPLOYMENT-REGISTRY.md
5. HTML/CSS integration points identified and tested
6. Vercel deploy hook re-triggered to push updated assets live

### Monitoring & Iteration
- Monitor Core Web Vitals after deployment (LCP, FID, CLS)
- If video impacts mobile performance, consider lazy-load or fallback strategy
- Log generation timestamps and model versions for reproducibility

---

## Summary for Immediate Generation

### Ready-to-Fire Assets
✅ **ASSET 1:** Nano Banana 2 hero grid background (16:9, 1K, cyan+blue+navy)  
✅ **ASSET 2:** Nano Banana 2 process layers accent (16:9, 1K, geometric, blue+cyan)  
✅ **ASSET 3:** Kling 3.0 hero motion (6s, 1080p, loopable, secure grid glow+flow)

### Status
**READY FOR IMMEDIATE GENERATION** — All prompts finalized, idempotency keys assigned, WaveSpeed JSON payloads queue-ready, deployment targets mapped.

### Next Step
Execute WaveSpeed API calls (via n8n workflow or direct API) in order: Image 1 → Image 2 → Video (with Image 1 dependency). Expected total time: 2–4 minutes depending on WaveSpeed queue depth.

---

## Appendix: Brand/Tone Quick Reference

**PixC Brand DNA:**
- Premium, assertive, systems-thinking
- Dark mode SaaS + subtle cyber undertones
- Competence first, spectacle second
- Restrained motion, high contrast, clean type
- Trust through clarity, not decoration

**Accent Colors:** Cyan #54E3FF, Blue #7C8CFF  
**Background:** Navy #050816, #0B1220  
**Type:** Space Grotesk (bold), Inter (body)  
**Motion Rule:** Transform + opacity only, GPU-accelerated, prefers-reduced-motion always respected

