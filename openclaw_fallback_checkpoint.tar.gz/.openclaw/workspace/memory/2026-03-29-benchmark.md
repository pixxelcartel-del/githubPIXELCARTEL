# Luna Benchmark Report
Generated: 2026-03-29 18:00 UTC
Sessions analyzed: 5

## Session: 3956b284...
Messages scored: 62 | Avg score: 95%

## Session: a4de3449...
Messages scored: 1 | Avg score: 69%

## Session: a60fa4f1...
Messages scored: 1 | Avg score: 69%

## Session: 6a62a189...
Messages scored: 5 | Avg score: 94%

## Session: 9e317e66...
Messages scored: 1 | Avg score: 69%

## OVERALL SCORE: 94% (70 messages)

## Top Violations (most frequent first)
  - short_response (28x): Max 8 lines for complex, 4 for casual
  - no_markdown (5x): No bullet points / bold / backticks in chat

## Suggested SOUL.md Patches
  Priority fix: [short_response] — Max 8 lines for complex, 4 for casual
  Suggested addition to SOUL.md enforcement section:
  > HARD RULE: Max 8 lines for complex, 4 for casual — violated 28x in last benchmark

---