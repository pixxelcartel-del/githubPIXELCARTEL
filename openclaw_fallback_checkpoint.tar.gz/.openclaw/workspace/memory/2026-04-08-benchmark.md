# Luna Benchmark Report
Generated: 2026-04-08 00:00 UTC
Sessions analyzed: 5

## Session: e9a1c099...
Messages scored: 6 | Avg score: 98%

## Session: a4de3449...
Messages scored: 1 | Avg score: 69%

## Session: a60fa4f1...
Messages scored: 1 | Avg score: 69%

## Session: 6a62a189...
Messages scored: 5 | Avg score: 94%

## OVERALL SCORE: 92% (13 messages)

## Top Violations (most frequent first)
  - short_response (4x): Max 8 lines for complex, 4 for casual
  - no_markdown (3x): No bullet points / bold / backticks in chat

## Suggested SOUL.md Patches
  Priority fix: [short_response] — Max 8 lines for complex, 4 for casual
  Suggested addition to SOUL.md enforcement section:
  > HARD RULE: Max 8 lines for complex, 4 for casual — violated 4x in last benchmark

---