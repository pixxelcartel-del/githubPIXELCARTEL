# Pixel Cartel — Competitor Analysis
**Market:** Web Design Agency, Bangladesh / Remote
**Date:** 2026-04-04

## Top 5 Competitors (Clutch BD Rankings)

| Agency | Rating | Clutch Score | Rate | Differentiator | Weakness |
|--------|--------|-------------|------|----------------|----------|
| Wavespace Digital | 4.9★ | 33.4/40 | $25-49/hr | UX/UI focus, DTC brands | Generic site, no scroll FX |
| Beyond Bracket | 5.0★ | 32.8/40 | $50-99/hr | Timely delivery | No visual brand identity |
| Seative Digital | 5.0★ | 27.3/40 | $25-49/hr | Responsive + UI/UX | Small portfolio, plain site |
| Dcastalia Limited | 4.9★ | 30.9/40 | $25-49/hr | 69 reviews, mobile apps | Outdated web presence |
| Karukaj DIGITAL | 4.9★ | 25.2/40 | <$25/hr | SEO + social media | Budget positioning |

## Patterns of the Top 10%

1. **Clutch presence is mandatory** — every credible BD agency has a Clutch profile with verified reviews
2. **Communication > design** — clients praise responsiveness/timely delivery more than aesthetics
3. **International clients = credibility** — US/UK/AU projects signal remote readiness
4. **Price anchoring** — all cluster $25-99/hr; no one is positioning as premium $100+
5. **Service breadth** — all offer web design + dev + SEO; no specialists

## What NONE of them do
- Scroll-driven / cinematic websites
- Video integration on hero sections
- Premium dark aesthetic (all use light corporate templates)
- Clear pricing tiers on website
- Case study storytelling (just project lists)
- Awwwards-quality design

## Pixel Cartel Differentiation
- **Only BD agency with Awwwards-caliber scroll design**
- **Transparent pricing** (package tiers visible on site)
- **Creative niche**: Startups, SaaS, DTC brands who want premium
- **Remote-first**: Global clients, async-friendly team
- **Story-led case studies** vs boring project lists

## Recommended Design Direction
- **Color:** Electric blue (#3B82F6) + Deep black (#0A0A0A) + White (#FAFAFA)
- **Typography:** Space Grotesk (headlines) + Inter (body)
- **Aesthetic:** Dark luxury tech — Apple meets Stripe meets Awwwards
- **Animation:** Scroll-triggered reveals, magnetic cursors, parallax hero text
- **CTA:** "Start a project" primary, "See our work" secondary
