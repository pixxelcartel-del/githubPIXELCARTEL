# PixC Motion Prototype Notes

## 2026-04-16
- Added `gsap-lenis-container-prototype.html` as the first concrete follow-up to the QDE scoring pass.
- Purpose: validate the preferred premium motion stack before calling it integrated.
- Stack choice from QDE pass:
  - GSAP + ScrollTrigger = strongest production motion bridge
  - Lenis = promoted to GOLD for cinematic scroll feel
  - Container queries = promoted to GOLD as the native responsive primitive

## Integration rule
Do not mark these techniques as `integrated=yes` in `QDE-TRACKER.md` until one of the following is true:
- the pattern ships inside a real PixC build, or
- it becomes a reusable section/component committed to the website builder system.

## Next build pass
1. Port this into the active PixC website builder or a reusable section library.
2. Replace CDN scripts with package-based imports.
3. Add Lighthouse and reduced-motion verification.
