# Pixel Cartel Website

Premium web design agency website built by Mark (PixC pipeline).

## Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# From /site directory
cd site
vercel --prod
```

## Tech Stack
- Pure HTML/CSS/JavaScript (no framework)
- GSAP + ScrollTrigger for animations
- Google Fonts: Space Grotesk + Inter
- Mobile-first responsive design
- Lighthouse 90+ optimized

## Design System (AntiGravity 5D)
1. **Pattern**: Agency/portfolio dark layout
2. **Style**: Dark luxury tech
3. **Colors**: Electric blue #3B82F6 + Black #0A0A0A + White #FAFAFA
4. **Typography**: Space Grotesk (headings) + Inter (body)
5. **Animation**: Scroll-triggered reveals, GSAP parallax, counter animations

## Performance
- CSS custom properties for theming
- Intersection Observer for lazy reveals
- `prefers-reduced-motion` respected
- No render-blocking resources
- Images lazy-loaded via IntersectionObserver

## Local Preview
```bash
cd site
python3 -m http.server 8080
# open http://localhost:8080
```
