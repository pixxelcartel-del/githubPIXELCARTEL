# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

This is Himel's home directory on Windows, which serves as the local control plane for **PixC (PixelCartel)** — an automated AI website factory system. The production system runs on a VPS, but blueprints, agent configs, and project files live here.

## Key Projects

- **LUNA system** — the multi-agent orchestration system at `LUNA/luna-system-v1/`
- **PixC website factory** — 14-module automated website production pipeline (Mark + A agents)
- **CosyPOS** — gas station POS app at `github/POS_SF/` (React 19 + TypeScript + Vite + Supabase)

---

## CosyPOS Development Commands

```bash
cd C:/Users/himel/github/POS_SF
npm install
npm run dev        # Dev server
npm run build      # Production build
npm run preview    # Preview production build
```

Deployed to Vercel automatically on push to `main`. Env vars (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) set in Vercel dashboard.

---

## LUNA System Architecture

Located at `LUNA/luna-system-v1/`. On the VPS this lives at `/home/himel/.openclaw/`.

### Agent Roster

| Agent | Role | Workspace |
|-------|------|-----------|
| Luna | Orchestrator, Telegram interface, heartbeat | `workspace/` (workspace-main) |
| Mark | Website factory (14-module pipeline) | `workspace-mark/` |
| A | Security & reliability, runs M11 in parallel | `workspace-a/` |
| Elon | n8n workflows, API integrations | `workspace-elon/` |
| Ernest | Copy compression (removes AI slop) | sub-agent of Mark |
| Dieter Rams | UX/design quality | sub-agent of Mark (M04, M12) |
| John Lasseter | Animation/motion spec | sub-agent of Mark (M04-D5, M08) |
| Larry Page | SEO/performance | sub-agent of Mark (M09, M10) |
| Sun Tzu | Strategic decomposition | sub-agent of Mark (M02) |
| Nova, Atlas, Oracle, Cipher | Additional agents | various workspaces |

### Mark's 14-Module Pipeline

```
M01:Research → M02:Strategy → M03:Copy → M04:Design → M05:Assets
→ M06:Prompts → M07:Components → M08:Build → M09:SEO → M10:Perf
→ M11:Security(A, parallel) → M12:QualityGate → M13:Deploy → M14:Monitor
```

A runs M11 **in parallel** with Mark's M08–M10, writing blockers to `security/[client]/BLOCKERS.md`. Mark checks this file before M12.

### Quality Gates (Hard Limits)

- Lighthouse Performance: 95+ (or no deploy)
- Lighthouse SEO: 95+ (or no deploy)
- LCP < 1.5s, CLS < 0.05, INP < 150ms
- Zero critical/high npm audit vulnerabilities
- Zero anti-slop words in copy (no "revolutionize", "leverage", "cutting-edge", "seamless", "unlock")

### Tech Stack for Built Sites

- **Next.js 14** (App Router, SSG by default)
- **Tailwind CSS v4**
- **GSAP + ScrollTrigger** (animations)
- **Lenis** (smooth scroll)
- **Sharp** (image optimization)
- **next-sitemap** (sitemap/robots.txt)

### Design Rules (AntiGravity 5D)

- No Inter, Roboto, Arial, or system fonts
- 60-30-10 color rule, max 3 primaries, WCAG AA contrast (4.5:1)
- Max 2 font families
- GPU-only animations: `transform` + `opacity` only
- Max transition: 300ms
- `prefers-reduced-motion` always respected
- No inline styles, no div soup — semantic HTML required

---

## Infrastructure (VPS)

| Service | Access | Status |
|---------|--------|--------|
| n8n | Docker `n8n-n8n-1` | 28 workflows, 22 webhooks |
| Qdrant | Docker, `localhost:6333` | 10 collections |
| Ollama | Docker | 3 models (incl. nomic-embed-text, llama3.2:3b) |
| Neo4j | Docker | `luna-graph-2026`, 19 nodes |

### Key Qdrant Collections

`memories`, `market_intel`, `luna_memory`, `code_snippets`, `pixc_builds`, `tutorials`, `design_assets`, `agent_outputs`, `luna_learnings`

### MCP Servers (configured on VPS)

`luna-n8n-gateway`, `firecrawl`, `playwright`, `github`, `context7`, `exa`, `transcriptapi`, `supabase`

---

## Model Routing Rules

- **Primary**: `openai-codex/gpt-5.4` (for builds, research, security)
- **Monitoring/background**: `ollama/llama3.2:3b` (M14, zero cost)
- **BANNED**: `anthropic/*`, `gemini/*` — hard rule, no exceptions

---

## GitHub

- Org: `luxurioupotato`
- All repos: **always private** — `--private` flag mandatory on `gh repo create`
- Vercel account: `pixxelcartel-2730`
- CI/CD: GitHub Actions → lint + build + Lighthouse CI + `npm audit` → auto-merge → Vercel deploy

---

## Credential Reference

All credentials stored in `LUNA/luna-system-v1/openclaw.json` env section. Key services: OpenClaw Gateway, Firecrawl, Exa, Supabase, GitHub (`luxurioupotato`), Telegram bot, Vercel, WaveSpeed, Neo4j, Ollama, n8n, ElevenLabs, Groq, OpenRouter.

Anthropic has $0 balance — Himel must top up to use Claude API directly.

---

## Important File Locations

| File | Purpose |
|------|---------|
| `MARK-FACTORY-BLUEPRINT.md` | Full 14-module pipeline spec |
| `FACTORY-ADDENDUM.md` | Addendum v2.1: self-evolving acquisition system |
| `MARK-SOUL-v2.md` | Mark agent identity and rules |
| `MARK-AGENTS-v2.md` | Mark's sub-agent roster |
| `A-SOUL.md` | Agent A security doctrine |
| `LUNA/luna-system-v1/openclaw.json` | Master credential store |
| `LUNA/luna-system-v1/workspace-mark/` | Mark's live workspace |
| `COMPONENT-INDEX.json` | Component library catalog |
| `github/POS_SF/` | CosyPOS app |
| `next-base-*.{tsx,js,css}` | Base Next.js template files |
