# Passive Income Ideas

Updated: 2026-04-12

## Ideas Queue
- [x] AI website audit micro-product for SMBs and agencies
  - Researched: 2026-04-12
  - Brief: `research/passive-income-brief-2026-04-12-ai-website-audit.md`
  - Why first: directly aligned with PixelCartel's website builder, conversion, and automation priorities

- [ ] AI visibility / LLM brand audit for businesses
- [ ] White-label monthly website audit reports for freelancers and small agencies
- [ ] Landing page teardown library + scorecards subscription
