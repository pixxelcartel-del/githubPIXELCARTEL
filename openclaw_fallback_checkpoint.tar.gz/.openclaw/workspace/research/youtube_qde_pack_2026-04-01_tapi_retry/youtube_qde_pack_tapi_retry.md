# YouTube QDE Pack — TranscriptAPI Retry

Created: 2026-04-01T21:53:02.784Z
Inputs: 8 | Unique: 7
TranscriptAPI successes: 1 | fallback-preserved failures: 6

## Claude Code + NoteBookLM = Infinite Memory (6t32nPxeJb8)
Source quality: fallback_existing_fallback_web_summary
URL: https://www.youtube.com/watch?v=6t32nPxeJb8

Quick summary: Shows a workflow where Claude Code orchestrates research and execution while NotebookLM serves as a structured analysis layer, effectively creating a persistent external memory and research engine.

Core ideas:
- Claude Code is positioned as the terminal-side orchestrator that can drive repeatable workflows.
- NotebookLM acts as a specialist analysis layer for extracting insights from docs, tutorials, and reference material.
- Obsidian/local notes are implied as long-term storage for durable knowledge and working style.
- The real leverage comes from chaining orchestration + research + memory into a feedback loop.

Actionable takeaways:
- Treat NotebookLM as a second-brain analysis surface, not just a chat UI.
- Build a repeatable pipeline: ingest sources -> analyze in NotebookLM -> save distilled outputs into local memory vault.
- Use Claude Code to automate collection and formatting of research packets for future agent runs.
- Separate orchestration, analysis, and storage so each component can be swapped without breaking the system.

Tools / skills / resources:
- Claude Code
- NotebookLM
- Obsidian
- research pipeline design
- external memory systems

Routing:
- elon: memory orchestration patterns; terminal-driven automation; research ingestion pipeline design
- sun_tzu: multi-stage workflow decomposition across orchestrator, analyst, and memory layers
- ernest: compress long-form research into stable reusable notes/specs
- luna_memory: store the principle that durable leverage comes from externalized memory + repeatable synthesis loops

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.

## This AI Agent Builds $15K Cinematic Websites on Autopilot (Claude Code + Nanobanana 2) (bUt1WpDlI6E)
Source quality: fallback_existing_metadata_plus_web_summary
URL: https://www.youtube.com/watch?v=bUt1WpDlI6E

Quick summary: Appears to frame a premium website-production workflow where Claude Code handles build/orchestration and Nanobanana 2 contributes visual asset generation for high-ticket cinematic websites.

Core ideas:
- Premium websites can be productized when design generation and implementation are chained tightly.
- AI-assisted visual asset generation lowers the cost of producing cinematic presentation layers.
- Claude Code is being used as the execution/orchestration layer rather than as a pure chatbot.
- The positioning is outcome-first: sell a premium website result, not isolated dev hours.

Actionable takeaways:
- Package cinematic website builds as a premium offer with a fixed production workflow.
- Standardize a pipeline from reference gathering to asset generation to code assembly.
- Create reusable prompt packs and component systems so premium quality is repeatable.
- Validate where visuals need bespoke generation versus reusable templates.

Tools / skills / resources:
- Claude Code
- Nanobanana 2 / Nanobanana Pro 2
- premium website production workflow
- AI image generation for web builds

Routing:
- mark: high-ticket website packaging; cinematic frontend patterns; offerization of premium web builds
- elon: workflow automation for asset->build pipelines; toolchain integration around generated visuals
- sun_tzu: systematize premium website delivery into discrete stages
- ernest: compress the sales promise into a reusable one-page offer framework
- luna_memory: note possible relevance to website-intelligence / theme-factory style premium build workflows

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.

## Claude Code Just Leaked Its Entire Source Code (Here's What's Inside) (wGtOMkoi35s)
Source quality: fallback_existing_fallback_web_summary
URL: https://www.youtube.com/watch?v=wGtOMkoi35s

Quick summary: Summarizes lessons from the accidental Claude Code source leak, focusing on how production-grade agent systems handle memory skepticism, risk classification, subagents, persistent instruction reinjection, and background maintenance.

Core ideas:
- Useful agent performance comes as much from orchestration architecture as from model quality.
- Memory should be treated as a hint to verify, not as unquestioned truth.
- Background consolidation matters because memory accumulates noise and contradictions over time.
- Risk-classified actions and human checkpoints are core to safe autonomy.
- Parallel subagents with scoped context are a practical scaling pattern.

Actionable takeaways:
- Adopt skeptical-memory checks before agents act on stored facts.
- Build an idle-time consolidation routine that merges, prunes, and resolves conflicting notes.
- Use explicit LOW/MEDIUM/HIGH risk classes for approvals and autonomous execution.
- Keep persistent instruction files re-inserted each turn so agent behavior does not drift.
- Use isolated workers for parallel tasks instead of one giant shared context.

Tools / skills / resources:
- Claude Code architecture
- risk classification
- background consolidation / autoDream-style maintenance
- subagent orchestration
- persistent instruction files

Routing:
- elon: agent architecture patterns; skeptical memory design; risk gating; background maintenance loops
- sun_tzu: parallel worker-agent decomposition and orchestration guardrails
- ernest: compress architecture patterns into a minimal operating doctrine
- luna_memory: store the verified principle that memory hygiene + risk gating are first-class agent features

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.

## Claude Code + Firecrawl Browser JUST changed the Internet Forever (h6TLo5u_fME)
Source quality: fallback_existing_fallback_web_summary
URL: https://www.youtube.com/watch?v=h6TLo5u_fME

Quick summary: Covers how pairing Claude Code with Firecrawl Browser gives agents persistent browsing sessions, structured extraction, and interactive website control, enabling authenticated multi-step web tasks.

Core ideas:
- The normal web is hostile to agents because it is built for humans, sessions, clicks, and dynamic UIs.
- Persistent browser profiles and structured page extraction make web automation far more reliable.
- Natural-language interaction layered over browsing reduces friction for agentic web work.
- Agent browsing is most valuable for workflows like research, lead enrichment, monitoring, and authenticated task execution.

Actionable takeaways:
- Use browser-backed data collection when static scraping is insufficient.
- Prefer structured LLM-ready extraction over raw HTML to reduce token waste.
- Reserve authenticated browsing for legitimate, durable workflows like research, internal ops, and lead enrichment.
- Design web agents around persistent sessions and resumable tasks.

Tools / skills / resources:
- Claude Code
- Firecrawl Browser
- Firecrawl MCP
- interactive browsing endpoints
- structured extraction

Routing:
- mark: possible use for competitive website analysis and structured asset gathering
- elon: browser automation architecture; session persistence; structured web extraction pipelines
- sun_tzu: route browsing-capable agents only where authenticated multi-step interaction is required
- ernest: compress use cases into a decision rubric for when browser agents are warranted
- luna_memory: store that persistent browser state is now a practical capability in agent workflows

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.

## Claude Code + Drawbridge Builds Websites By Sight (NEW Plugin) (K0j_ADBkN9I)
Source quality: fallback_existing_fallback_web_summary
URL: https://www.youtube.com/watch?v=K0j_ADBkN9I

Quick summary: Explains a visual-annotation workflow where Drawbridge lets users mark up live interfaces and hand those precise visual instructions to Claude Code for implementation.

Core ideas:
- Visual feedback is far more precise than long text descriptions when fixing UI issues.
- Annotations, screenshots, and bounded regions let AI understand intent at the interface layer.
- Different operating modes (step, batch, yolo) map to different trust/autonomy levels.
- This lowers the barrier for non-technical collaborators to direct frontend changes.

Actionable takeaways:
- Use screenshot-first feedback loops for frontend revisions and QA.
- Choose approval modes based on task risk and collaborator trust.
- Build product/design review workflows around visual markup instead of verbose tickets.
- Treat visual annotation as a bridge between design intent and code execution.

Tools / skills / resources:
- Claude Code
- Drawbridge
- visual annotation workflows
- frontend QA by screenshot
- step/batch/yolo execution modes

Routing:
- mark: visual product iteration; faster website QA/revision loops; non-technical stakeholder collaboration
- elon: plugin integration patterns; mode-based approval architecture for code changes
- sun_tzu: choose autonomy mode by task risk and workflow stage
- ernest: compress visual review loop into a standard operating playbook
- luna_memory: store that screenshot-native revision loops can reduce product iteration friction

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.

## Claude Code + Kaparthy’s AutoResearch = GOD MODE (vXylQqxsGX0)
Source quality: TranscriptAPI_verified
Transcript chars: 43565
URL: https://youtube.com/watch?v=vXylQqxsGX0

Quick summary: If you're using claude code without auto research, you might be leaving money on the table. So, in this video, I'm going to show you new strategy from Andre Kapi that could not only just improve any metric in your business, but also save you hours and get you light years ahead of your competitors. And if you don't know who I am, my name is Jack Roberts. I built and saw my last tech startup 60,000 customers and now I run an AI automation business. So, if you haven't already, grab that coffee and let's dive straight in.

Core ideas:
- Use explicit metrics and feedback loops instead of subjective judgment.
- Feed the system richer context before asking it to optimize.
- Use browser-backed collection when APIs are missing or UI state matters.
- Prefer visual annotation and interface-level feedback for UI iteration.

Actionable takeaways:
- explicit metrics and feedback loops instead of subjective judgment.
- Feed the system richer context before asking it to optimize.
- browser-backed collection when APIs are missing or UI state matters.
- visual annotation and interface-level feedback for UI iteration.

Tools / skills / resources:
- claude code
- Claude code
- Google Sheets
- notion

Routing:
- mark: use for UX/content experiments on landing pages and product funnels
- elon: build experiment harnesses and metric-driven refinement loops
- sun_tzu: orchestrate propose->run->score->retain cycles across domains
- ernest: compress each experiment into compact learnings for future runs
- luna_memory: store the core doctrine: improvement requires measurable closed loops

## AntiGravity + Figma builds Insane Mobile Apps (NEW Skill) (n3o8MgaNRE4)
Source quality: fallback_existing_partial_transcript_from_web
URL: https://www.youtube.com/watch?v=n3o8MgaNRE4

Quick summary: Shows how connecting AntiGravity/Claude Code-style agents to Figma MCP enables AI-assisted mobile app design using community templates, editable layered files, and direct handoff-ready specs.

Core ideas:
- Figma is valuable not only for design creation but for layered, editable handoff artifacts.
- Connecting agents directly to Figma means humans can direct outcomes without mastering the full tool.
- Figma community templates dramatically accelerate app concepting and quality baselines.
- MCP-mediated tool access turns design software into part of the agent toolchain.

Actionable takeaways:
- Use Figma community assets as high-quality starting points instead of designing from a blank canvas.
- Keep output layered and editable so later dev/design passes stay efficient.
- Authenticate and verify MCP tool access early before prompting large design tasks.
- Route mobile-app concept generation through Figma when handoff quality matters.

Tools / skills / resources:
- AntiGravity
- Claude Code
- Figma
- Figma MCP server
- community templates
- layer-based design handoff

Routing:
- mark: mobile app design systems; template-led product design; handoff-friendly layered artifacts
- elon: MCP setup/auth flows and toolchain integration with design software
- sun_tzu: sequence setup->auth->template search->design generation->handoff validation
- ernest: compress design workflow into a reusable launch checklist
- luna_memory: store that direct Figma connectivity is a meaningful multiplier for mobile product work

Note: TranscriptAPI result not available in local results for this video during this retry; preserved prior downstream packet.
