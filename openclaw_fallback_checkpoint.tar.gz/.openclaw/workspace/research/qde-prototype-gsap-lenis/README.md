# QDE Prototype — GSAP + Lenis + Container Queries

Created: 2026-04-16 UTC

## Purpose
First autonomous self-improvement build from `QDE-TRACKER.md`.

This prototype tests a reusable premium motion section built around:
- GSAP `ScrollTrigger`
- Lenis smooth scroll integration
- CSS container queries for component-level responsiveness
- `prefers-reduced-motion` fallback

## What it demonstrates
- A pinned scroll narrative section with stacked cards
- One scrubbed timeline that transitions cards in sequence
- Internal card layout that changes based on the card's own width
- Native fallback behavior when reduced motion is enabled

## Why this matters for PixC
This is a good house primitive for:
- service storytelling
- process sections
- case-study reveals
- premium landing page narrative blocks

## Run locally
From this folder:

```bash
python3 -m http.server 8016
```

Then open:

```text
http://127.0.0.1:8016
```

## Recommendation
Keep this as a reusable reference and promote the motion stack into a shared PixC section starter.
Use Lenis selectively, not blindly, and preserve native scroll behavior for reduced-motion users.
