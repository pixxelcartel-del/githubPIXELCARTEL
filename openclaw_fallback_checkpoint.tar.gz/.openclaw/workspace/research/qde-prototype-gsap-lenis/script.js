const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (!prefersReducedMotion) {
  gsap.registerPlugin(ScrollTrigger);

  const lenis = new Lenis({
    smoothWheel: true,
    lerp: 0.12,
  });

  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((time) => {
    lenis.raf(time * 1000);
  });
  gsap.ticker.lagSmoothing(0);

  const cards = gsap.utils.toArray('.story-card');

  gsap.set(cards, {
    yPercent: (index) => index * 7,
    scale: (index) => 1 - index * 0.04,
    rotate: (index) => index * -2,
    opacity: (index) => (index === 0 ? 1 : 0.72),
    transformOrigin: '50% 80%',
  });

  const timeline = gsap.timeline({
    defaults: {
      ease: 'none',
    },
    scrollTrigger: {
      trigger: '.cards-section',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
      pin: '.pin-wrap',
      anticipatePin: 1,
    },
  });

  cards.forEach((card, index) => {
    if (index === cards.length - 1) return;

    const nextCard = cards[index + 1];
    const label = `step-${index}`;

    timeline
      .addLabel(label)
      .to(card, {
        yPercent: -26,
        rotate: 6,
        scale: 0.9,
        opacity: 0.18,
        duration: 1,
      }, label)
      .to(nextCard, {
        yPercent: index * 1.2,
        scale: 1,
        rotate: 0,
        opacity: 1,
        duration: 1,
      }, label)
      .to(cards.slice(index + 1), {
        yPercent: (_cardIndex, target) => {
          const actualIndex = cards.indexOf(target);
          return Math.max(0, (actualIndex - (index + 1)) * 7);
        },
        scale: (_cardIndex, target) => {
          const actualIndex = cards.indexOf(target);
          return 1 - Math.max(0, actualIndex - (index + 1)) * 0.04;
        },
        duration: 1,
      }, label);
  });

  window.addEventListener('beforeunload', () => {
    lenis.destroy();
    ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
  });
}
