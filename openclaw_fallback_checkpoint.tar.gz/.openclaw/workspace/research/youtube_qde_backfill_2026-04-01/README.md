# YouTube QDE Backfill Pack

Existing distilled pack: /home/himel/.openclaw/workspace/research/youtube_qde_pack_2026-04-01T22-15-41-142Z_distilled_qde_pack
Backfill pack: /home/himel/.openclaw/workspace/research/youtube_qde_backfill_2026-04-01

Result JSONs found: 47
Already covered by existing distilled pack: 7
Backfilled in this pack: 40
Aligned after backfill: True
