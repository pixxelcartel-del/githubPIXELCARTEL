# OpenClaw Agent Finds Ugly Websites → $5,000 Builds

Video ID: QiHXlY1EaB4
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/QiHXlY1EaB4.json

## Quick summary
Focuses on agent system: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send with workflows around agent workflow: scrape google maps, qualify leads, redesign websites, deploy websites using OpenClaw: agent platform.

## Distilled ideas
- Agent System: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send
- Redesign Process: uses AI agents to transform websites into fully redesigned sites
- Qualification Criteria: outdated visual designs, table layouts, basic or flat typography, cluttered layout
- Tools Used: ['Appify', 'Playrite', 'Verscell']
- Agent Workflow: scrape Google Maps, qualify leads, redesign websites, deploy websites

## Actionable takeaways
- Agent Workflow: scrape Google Maps, qualify leads, redesign websites, deploy websites
- Automation: agent can automate the entire process, including outreach
- Agent System: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send
- Redesign Process: uses AI agents to transform websites into fully redesigned sites
- Qualification Criteria: outdated visual designs, table layouts, basic or flat typography, cluttered layout

## Tools/resources
- OpenClaw: agent platform
- Claw Code: agent platform
- Appify: tool for extracting and scraping multiple websites and platforms
- Playrite: free tool for taking full page screenshots and assessing them visually
- Verscell: tool for deploying websites completely for free
- Robolabs: visual layer for viewing and presenting agent systems to clients
- Taste Skill: open-sourced design system for creating beautiful websites

## Why it matters
- Useful for premium website production, frontend systems, and productized web delivery.

## Routing guidance
### Mark Zuckerberg
- Agent System: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send
- Redesign Process: uses AI agents to transform websites into fully redesigned sites

### Elon Musk
- Agent Workflow: scrape Google Maps, qualify leads, redesign websites, deploy websites
- Automation: agent can automate the entire process, including outreach
- Agent System: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send

### Sun Tzu
- Agent Workflow: scrape Google Maps, qualify leads, redesign websites, deploy websites
- Automation: agent can automate the entire process, including outreach
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Agent System: scrapes a city for businesses with ugly websites, redesigns them from scratch, and hands you a batch of polished designs ready to send

### Luna memory
- Useful for premium website production, frontend systems, and productized web delivery.
