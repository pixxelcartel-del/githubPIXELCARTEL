# Antigravity now Clones and Edits $1M-Brand Videos

Video ID: lsm3LvwhR48
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/lsm3LvwhR48.json

## Quick summary
Focuses on cloning and editing videos with workflows around setting up ai agents using Anti-gravity.

## Distilled ideas
- Cloning and editing videos
- Using AI agents for video creation
- Setting up folder organization for AI agents
- Teaching AI agents to analyze input videos
- Creating prompts for AI agents

## Actionable takeaways
- Setting up AI agents
- Teaching AI agents to analyze input videos
- Creating prompts for AI agents
- Using Air Table for visualizing and tracking prompts and results
- Automating video creation with AI agents

## Tools/resources
- Anti-gravity
- Google
- Air Table
- Nano Banana Pro
- Cling 2.6
- Gemini API
- Sonnet 4.5
- Gemini Tree Flash

## Why it matters
- Market relevance: The era of creative AI agents is now here

## Routing guidance
### Mark Zuckerberg
- Cloning and editing videos
- Using AI agents for video creation

### Elon Musk
- Setting up AI agents
- Teaching AI agents to analyze input videos
- Cloning and editing videos

### Sun Tzu
- Setting up AI agents
- Teaching AI agents to analyze input videos
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Cloning and editing videos

### Luna memory
- Market relevance: The era of creative AI agents is now here
