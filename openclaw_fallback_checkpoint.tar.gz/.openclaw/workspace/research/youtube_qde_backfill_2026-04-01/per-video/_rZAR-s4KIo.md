# How to Sign AI Workflow Clients (0 Followers)

Video ID: _rZAR-s4KIo
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/_rZAR-s4KIo.json

## Quick summary
Focuses on cold outreach with workflows around cold outreach workflow using LinkedIn.

## Distilled ideas
- Cold outreach
- Referrals
- Partnerships
- Trojan horse method
- Borrowing trust and authority from partners

## Actionable takeaways
- Cold outreach workflow
- Referral workflow
- Trojan horse method workflow
- Four-step framework: offer first, validate with volume, monitor data, and adjust
- Cold outreach

## Tools/resources
- LinkedIn
- Facebook groups
- Email
- School communities
- YouTube channels
- Instagram
- Reddit
- Apollo

## Why it matters
- Market relevance: 92% of B2B buyers trust referrals from people they know

## Routing guidance
### Mark Zuckerberg
- No primary routing signal; secondary relevance only.

### Elon Musk
- Cold outreach workflow
- Referral workflow
- Cold outreach

### Sun Tzu
- Cold outreach workflow
- Referral workflow
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Cold outreach

### Luna memory
- Market relevance: 92% of B2B buyers trust referrals from people they know
