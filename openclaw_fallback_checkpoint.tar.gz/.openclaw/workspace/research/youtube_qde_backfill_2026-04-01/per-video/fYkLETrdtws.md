# Create 10-minute AI Character Videos in ONE Click (InfiniteTalk x n8n Full Guide 🥚)

Video ID: fYkLETrdtws
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/fYkLETrdtws.json

## Quick summary
Prior scrape packet detected; distilled from structured intelligence fields in the result JSON.

## Distilled ideas
- No structured intelligence fields beyond metadata; manual review may still help.

## Actionable takeaways
- Review underlying transcript/source packet and extract a stable workflow before routing.

## Tools/resources
- No explicit tools/resources captured in the prior scrape packet.

## Why it matters
- Relevant as part of the historical AI workflow/tooling research backlog.

## Routing guidance
### Mark Zuckerberg
- Visual/product workflow review

### Elon Musk
- Systems/automation review

### Sun Tzu
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Compress this packet into a one-page operating note.

### Luna memory
- Relevant as part of the historical AI workflow/tooling research backlog.
