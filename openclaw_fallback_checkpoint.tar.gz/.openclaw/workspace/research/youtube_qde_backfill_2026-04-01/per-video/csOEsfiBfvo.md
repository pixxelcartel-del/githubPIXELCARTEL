# AntiGravity + Spline Builds Insane 3D Websites

Video ID: csOEsfiBfvo
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/csOEsfiBfvo.json

## Quick summary
Focuses on using ai agents to build websites without writing code with workflows around using ai agents to automate website building using Spline.

## Distilled ideas
- Using AI agents to build websites without writing code
- Integrating 3D elements into websites
- Using Spline to create 3D assets
- Using anti-gravity to build and deploy websites
- Using skills to integrate Spline with anti-gravity

## Actionable takeaways
- Using AI agents to automate website building
- Using skills to automate integration of Spline with anti-gravity
- Using anti-gravity to automate deployment of websites
- Using AI agents to build websites without writing code
- Integrating 3D elements into websites

## Tools/resources
- Spline
- Anti-gravity
- Cloud code
- Codeex
- 21st.dev
- Forms free
- Web three forms
- Spline community assets

## Why it matters
- Useful for premium website production, frontend systems, and productized web delivery.

## Routing guidance
### Mark Zuckerberg
- Using AI agents to build websites without writing code
- Integrating 3D elements into websites

### Elon Musk
- Using AI agents to automate website building
- Using skills to automate integration of Spline with anti-gravity
- Using AI agents to build websites without writing code

### Sun Tzu
- Using AI agents to automate website building
- Using skills to automate integration of Spline with anti-gravity
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Using AI agents to build websites without writing code

### Luna memory
- Useful for premium website production, frontend systems, and productized web delivery.
