# Stop Learning n8n in 2026...Learn THIS Instead

Video ID: ZeJXI2MAhj0
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/ZeJXI2MAhj0.json

## Quick summary
Focuses on using natural language to describe automation workflows with workflows around building automations that check for new youtube videos and send key highlights using n8n.

## Distilled ideas
- Using natural language to describe automation workflows
- Building automations using drag-and-drop platforms like n8n
- Utilizing Agentic workflows for easier automation building
- Implementing AI automation in waves, starting with chatbots and progressing to more complex workflows
- Using tools like Cloud Code and Trigger.dev for building automations

## Actionable takeaways
- Building automations that check for new YouTube videos and send key highlights
- Creating automations that research companies and provide structured briefs
- Using Agentic workflows to automate tasks and provide outputs
- Using natural language to describe automation workflows
- Building automations using drag-and-drop platforms like n8n

## Tools/resources
- n8n
- make.com
- Zapier
- Cloud Code
- Trigger.dev
- ChatBT
- Agentic
- ClickUp

## Why it matters
- Strong signal for reusable automation and agent pipeline design.

## Routing guidance
### Mark Zuckerberg
- Using natural language to describe automation workflows
- Building automations using drag-and-drop platforms like n8n

### Elon Musk
- Building automations that check for new YouTube videos and send key highlights
- Creating automations that research companies and provide structured briefs
- Using natural language to describe automation workflows

### Sun Tzu
- Building automations that check for new YouTube videos and send key highlights
- Creating automations that research companies and provide structured briefs
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- Using natural language to describe automation workflows

### Luna memory
- Strong signal for reusable automation and agent pipeline design.
