# NEW Nano Banana 2 + Claude Code = $10k Websites

Video ID: q0TgUtj6vIs
Source JSON: /home/himel/.openclaw/workspace/skills/youtube-full/results/q0TgUtj6vIs.json

## Quick summary
Focuses on website building: using cloud code and claude code to build professional websites with workflows around building a website: using cloud code and claude code to automate the process using Cloud Code: a platform for building websites.

## Distilled ideas
- website building: using Cloud Code and Claude Code to build professional websites
- animation creation: using Nano Banana to generate images and Cling to animate them
- video to website: using a skill to turn a video into a premium scroll-driven animated website
- building a website: using Cloud Code and Claude Code to automate the process
- deploying a website: using GitHub and Versel to automate the deployment process

## Actionable takeaways
- building a website: using Cloud Code and Claude Code to automate the process
- deploying a website: using GitHub and Versel to automate the deployment process
- website building: using Cloud Code and Claude Code to build professional websites
- animation creation: using Nano Banana to generate images and Cling to animate them
- video to website: using a skill to turn a video into a premium scroll-driven animated website

## Tools/resources
- Cloud Code: a platform for building websites
- Claude Code: an AI assistant for building websites
- Nano Banana: a tool for generating images
- Cling: a tool for animating images
- GitHub: a platform for storing code
- Versel: a platform for deploying code
- Cloud Code: offers a free version of Visual Studio Code
- GitHub: offers free accounts

## Why it matters
- Useful for premium website production, frontend systems, and productized web delivery.

## Routing guidance
### Mark Zuckerberg
- website building: using Cloud Code and Claude Code to build professional websites
- animation creation: using Nano Banana to generate images and Cling to animate them

### Elon Musk
- building a website: using Cloud Code and Claude Code to automate the process
- deploying a website: using GitHub and Versel to automate the deployment process
- website building: using Cloud Code and Claude Code to build professional websites

### Sun Tzu
- building a website: using Cloud Code and Claude Code to automate the process
- deploying a website: using GitHub and Versel to automate the deployment process
- Turn this into a staged SOP with approval boundaries.

### Ernest Hemingway
- website building: using Cloud Code and Claude Code to build professional websites

### Luna memory
- Useful for premium website production, frontend systems, and productized web delivery.
