# AntiGravity + Figma builds Insane Mobile Apps (NEW Skill)

Video ID: n3o8MgaNRE4
Author: RoboNuggets

## Quick summary
Shows how to connect Figma’s MCP server to an agent workflow so the agent can inspect templates, generate mobile UI concepts, push editable layered designs into Figma, preview them locally on phone, and package them as an Android APK with Flutter.

## Distilled core ideas
- Figma’s MCP turns design tooling into an agent-controllable environment rather than a manual handoff tool.
- Starting from strong community templates massively improves output quality and speed.
- Real layered design files matter because they remain editable and developer-friendly.
- Local browser/mobile preview closes the gap between generated mockups and usable product validation.
- Packaging web-like builds into installable apps can compress design-to-prototype cycles dramatically.

## Actionable takeaways
- Connect design tools directly to agents where possible instead of treating design as an offline phase.
- Prompt agents to search adjacent template categories, not only exact vertical matches.
- Bake design-quality instructions into a dedicated skill so outputs use real imagery/icons and feel production-grade.
- Preview every build on actual phones before packaging or deployment.
- Use Flutter or similar wrappers to turn fast prototypes into testable app binaries quickly.

## Tools / frameworks / resources mentioned
- Figma MCP server
- AntiGravity
- Claude Code
- Figma Community templates
- iOS/Material design kits
- local dev server over Wi-Fi
- Flutter
- APK packaging

## Why it matters
Major pattern for Mark when moving from web experiences into mobile product prototyping and high-speed concept validation.
