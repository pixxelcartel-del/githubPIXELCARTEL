# Claude Code + Kaparthy’s AutoResearch = GOD MODE

Video ID: vXylQqxsGX0
Author: Jack Roberts

## Quick summary
Explains an iterative optimization loop inspired by Andrej Karpathy’s AutoResearch repo: choose a measurable objective, collect data automatically, let the agent propose changes, and repeat based on results.

## Distilled core ideas
- Compounding iteration beats one-shot optimization; maintain a log of experiments and outcomes.
- Only optimize metrics that are objective, machine-readable, and frequent enough to yield feedback.
- Context quality drives optimization quality; agents need business, customer, and domain data to avoid generic suggestions.
- When no API exists, browser automation plus Notion/Sheets-style handoff layers can still create a measurement loop.
- Knowledge bases from experts and voice-of-customer data can materially sharpen agent suggestions.

## Actionable takeaways
- Pick one measurable bottleneck metric first rather than trying to optimize everything at once.
- Build per-project folders containing business context, survey data, historical metrics, and experiment logs.
- Automate data ingestion through APIs when possible, browser scraping when necessary.
- Run small controlled changes before radical rewrites so the loop stays interpretable.
- Feed agents expert corpora and customer language before asking for optimization proposals.

## Tools / frameworks / resources mentioned
- Andrej Karpathy AutoResearch GitHub repo
- Claude Code / Claude co-work
- Anti-gravity IDE
- Pinecone vector DB
- Notion
- Google Sheets
- browser automation / Chrome Claude extension
- Skool analytics example

## Why it matters
Excellent operating model for Elon/Sun Tzu on continuous improvement loops across offers, pages, onboarding, content, and internal systems.
