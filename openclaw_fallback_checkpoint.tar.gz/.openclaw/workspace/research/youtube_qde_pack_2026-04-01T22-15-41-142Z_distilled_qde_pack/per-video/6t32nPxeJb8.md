# Claude Code + NoteBookLM = Infinite Memory

Video ID: 6t32nPxeJb8
Author: Jack Roberts

## Quick summary
Shows how to connect Claude Code/Claude co-work to Google NotebookLM so NotebookLM becomes a low-cost external memory and asset-generation layer for long-running projects.

## Distilled core ideas
- Claude’s weak point is session amnesia and expensive context reuse; NotebookLM can act as persistent retrieval-backed memory.
- Use Claude to create/query NotebookLM notebooks rather than stuffing huge files into context.
- NotebookLM can generate downstream assets like podcasts, infographics, video briefs, and research summaries from accumulated project knowledge.
- A wrap-up workflow can store major session outputs into a “brain” notebook for later semantic recall.
- Project instructions can force Claude to consult the external notebook for strategy questions, effectively adding lightweight long-term memory.

## Actionable takeaways
- Create a dedicated NotebookLM “brain” notebook per major domain or person.
- After large sessions, run a wrap-up step that stores summary, decisions, todos, and rationale into NotebookLM.
- Use NotebookLM as the retrieval layer for strategy/history instead of repeatedly loading giant docs into Claude context.
- Add project-level instruction snippets that tell Claude when to query the notebook before answering.
- Use NotebookLM for free or low-cost asset generation when turning source material into client-facing deliverables.

## Tools / frameworks / resources mentioned
- Claude Code
- Claude co-work/Projects
- Google NotebookLM
- GitHub repo/script for auth bridge
- Wrap-up skill / markdown skill files
- RAG / semantic retrieval pattern

## Why it matters
Directly relevant to memory architecture, context-cost reduction, and session continuity for any agentic operating system.
