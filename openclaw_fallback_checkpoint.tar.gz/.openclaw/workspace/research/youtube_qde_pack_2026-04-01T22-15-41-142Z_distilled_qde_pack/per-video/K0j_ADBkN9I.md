# Claude Code + Drawbridge Builds Websites By Sight (NEW Plugin)

Video ID: K0j_ADBkN9I
Author: Jay E | RoboNuggets

## Quick summary
Shows a visual feedback loop where a browser extension lets users annotate UI elements directly and Claude Code reads structured tasks plus screenshots to make precise design fixes.

## Distilled core ideas
- Text-only prompting is a poor interface for visual correction work; direct annotation closes the intent gap.
- Drawbridge converts visual comments into structured markdown/JSON tasks with screenshots, coordinates, and HTML context.
- Batch/step/YOLO modes create different balances between control and autonomy.
- Visual task queues make agentic UI work easier for non-developers and easier to supervise.
- The future agent interface is increasingly visual, not just terminal/IDE based.

## Actionable takeaways
- Add annotation-driven review loops to website/app build systems.
- Store visual feedback as standardized task artifacts instead of ad hoc screenshots in chat.
- Use step mode for sensitive polish passes and batch/YOLO for routine cleanup.
- Expose agent internals through a more visual command center when collaborating with non-technical stakeholders.
- Bridge screenshots with DOM/HTML context to improve fix precision.

## Tools / frameworks / resources mentioned
- Drawbridge Chrome extension
- Claude Code
- Markdown task files
- JSON metadata with bounding regions
- Telegram-linked long-running session
- visual command center / rubric console

## Why it matters
Directly applicable to Mark’s frontend workflow and to any human-in-the-loop design correction system.
