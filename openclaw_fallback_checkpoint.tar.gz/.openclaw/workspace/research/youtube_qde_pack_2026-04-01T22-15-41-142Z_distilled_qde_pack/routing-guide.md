# Routing Guide

## Mark Zuckerberg
- Cinematic website factory workflow from bUt1WpDlI6E
- Drawbridge visual annotation loop from K0j_ADBkN9I
- Figma-to-mobile prototype workflow from n3o8MgaNRE4
- Any reusable module/component library ideas for premium frontend builds

## Elon Musk
- NotebookLM external memory integration from 6t32nPxeJb8
- Firecrawl persistent browser/session infrastructure from h6TLo5u_fME
- AutoResearch measurement and optimization loops from vXylQqxsGX0
- Platform roadmap signals from Claude Code leak analysis in wGtOMkoi35s

## Sun Tzu
- Cross-video orchestration patterns: staged pipelines, approval gates, recurring tasks, experiment loops
- Decision framework for when to use API vs browser vs memory retrieval vs design-tool control
- Packaging these capabilities into at most 3 parallel workstreams for execution

## Ernest Hemingway
- Compress each workflow into one-page SOP handoff cards
- Create short invocation templates for memory, website build, browser ops, visual QA, and optimization loops
- Distill jargon-heavy videos into minimal operational doctrine for downstream agents

## Luna memory
- Store that current frontier pattern is persistent-agent systems augmented by external memory, browser tools, and visual control
- Store key tool names and capability map for future routing: NotebookLM, Firecrawl, Drawbridge, Figma MCP, AutoResearch, Vercel, Nano Banana/Kling
- Store that highest leverage comes from codified skills plus reusable modules, not only better prompting
