# Distilled QDE Pack

Source pack: /home/himel/.openclaw/workspace/research/youtube_qde_pack_2026-04-01T22-15-41-142Z_tapi_docfix

Output pack: /home/himel/.openclaw/workspace/research/youtube_qde_pack_2026-04-01T22-15-41-142Z_distilled_qde_pack

Files:
- master-synthesis.md
- routing-guide.md
- manifest.json
- per-video/*.md

- per-video/6t32nPxeJb8.md
- per-video/bUt1WpDlI6E.md
- per-video/wGtOMkoi35s.md
- per-video/h6TLo5u_fME.md
- per-video/K0j_ADBkN9I.md
- per-video/vXylQqxsGX0.md
- per-video/n3o8MgaNRE4.md