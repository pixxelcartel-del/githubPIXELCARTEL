# Competitor Analysis
Luna auto-updates this during research runs.

## PixC Competitors
TBD — first run pending.
