import http from "http";
import fs from "fs";
import os from "os";
import path from "path";
import { spawn } from "child_process";
import { Bot, InputFile } from "grammy";
import { runAgentLoop, getModelStatus } from "./core/agent.js";
import { memory } from "./memory/index.js";
import { startScheduler } from "./core/scheduler.js";
import { checkOllamaHealth } from "./core/ollama.js";
import { checkGeminiHealth, isGeminiConfigured } from "./core/gemini.js";
import { checkSupabaseHealth } from "./core/supabase.js";
import { checkN8nHealth } from "./core/n8n.js";
import { isPineconeConfigured } from "./core/pinecone.js";
import { secrets, logSecretsStatus } from "../config/secrets.js";
import { downloadFile, convertOggToMp3, transcribeAudio, generateSpeech, convertMp3ToOgg } from "./core/audio.js";
import {
  isTalkMode,
  toggleTalkMode,
  checkWakeWord,
  stripWakePhrase,
  resolveVoiceReply,
} from "./core/voice.js";
import { triggerAutonomousThought } from "./core/autonomous-thought.js";

// --- Autonomous Thought State ---
let lastUserActivityTs = Date.now();
let isAutonomousThinking = false;
let lastLunaThought = ""; // stores her most recent private thought for /thought command
// --------------------------------

const TELEGRAM_BOT_TOKEN = secrets.TELEGRAM_BOT_TOKEN;
const ALLOWED_USER_ID = secrets.ALLOWED_USER_ID
  ? Number(secrets.ALLOWED_USER_ID)
  : null;
const PORT = secrets.PORT ? Number(secrets.PORT) : null;

if (!TELEGRAM_BOT_TOKEN) {
  console.error("Missing TELEGRAM_BOT_TOKEN in .env");
  process.exit(1);
}

const bot = new Bot(TELEGRAM_BOT_TOKEN);

function isAuthorized(userId?: number): boolean {
  return !ALLOWED_USER_ID || userId === ALLOWED_USER_ID;
}

// ─── Helper: extract and send [DOC] content as a Telegram file ──────────────

function extractDocTag(response: string): { hasDOC: boolean; filename: string; docContent: string; remainder: string } {
  const match = response.match(/\[DOC(?:\s+title="([^"]+)")?\]([\s\S]*?)\[\/DOC\]/i);
  if (!match) return { hasDOC: false, filename: "", docContent: "", remainder: response };
  const filename = match[1]?.trim() || "luna-note.txt";
  const docContent = match[2].trim();
  const remainder = response.replace(match[0], "").trim();
  return { hasDOC: true, filename, docContent, remainder };
}

async function sendDocIfPresent(ctx: any, response: string): Promise<string> {
  const { hasDOC, filename, docContent, remainder } = extractDocTag(response);
  if (!hasDOC) return response;

  const tmpPath = path.join(os.tmpdir(), `luna-${Date.now()}-${filename}`);
  try {
    fs.writeFileSync(tmpPath, docContent, "utf8");
    await ctx.replyWithDocument(new InputFile(tmpPath, filename));
    console.log(`[DOC] Sent "${filename}" (${docContent.length} chars)`);
  } catch (err) {
    console.error("[DOC] Failed to send document:", err);
  } finally {
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
  }

  return remainder;
}

// ─── Helper: send voice or fallback to text ──────────────────────────────────

async function sendVoiceOrFallback(ctx: any, text: string, captionText?: string): Promise<void> {
  await ctx.replyWithChatAction("record_voice");
  try {
    const mp3 = await generateSpeech(text);
    const ogg = await convertMp3ToOgg(mp3);
    await ctx.replyWithVoice(new InputFile(ogg, "reply.ogg"), { caption: captionText });
  } catch (ttsErr) {
    console.error("[TTS] Failed, falling back to text:", ttsErr);
    for (const chunk of splitMessage(text, 4096)) {
      await ctx.reply(chunk);
    }
  }
}

// ─── Commands ────────────────────────────────────────────────────────────────

bot.command("start", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  await ctx.reply(
    "hey love, Luna's online and ready.\n\n" +
    "got my brain loaded, tools armed, and I'm not going anywhere.\n" +
    "what are we working on? <3",
  );
});

bot.command("clear", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  if (ctx.from) {
    memory.clearConversation(ctx.from.id);
    await ctx.reply("fresh start, love. conversation cleared. your facts and preferences are safe in the vault <3");
  }
});

// Feature: See Luna's last private thought (confirms the machinery is real)
bot.command("thought", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  if (!lastLunaThought) {
    await ctx.reply("no thought captured yet — she hasn't had a full turn since I started up.");
    return;
  }
  await ctx.reply(`her last private thought:\n\n${lastLunaThought}`);
});

// Feature: Context Compaction
bot.command("compact", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  if (ctx.from) {
    const { before, after } = memory.compactConversation(ctx.from.id);
    await ctx.reply(`compacted ${before} messages → ${after}. context is tight and clean now <3`);
  }
});

// Feature: Memory Health Report
bot.command("memory", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  const report = memory.getHealthReport(ctx.from?.id);
  await ctx.reply(report);
});

// Feature 2: Talk Mode toggle
// ON  → Luna replies to text messages with voice (if VOICE_ON_TEXT_ENTIRELY=true in .env)
// OFF → back to text replies. Voice notes always get voice replies regardless.
bot.command("talkmode", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  const userId = ctx.from!.id;
  const isNowOn = toggleTalkMode(userId);
  if (isNowOn) {
    await ctx.reply(
      "talk mode on. 🎙️ send me anything — i'll talk back.\n" +
      "say \"hey luna\" in a voice note to wake me up hands-free.\n" +
      "type /talkmode again to turn it off."
    );
  } else {
    await ctx.reply("talk mode off. back to text. 🤐");
  }
});

bot.command("status", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;

  const [ollamaOk, geminiOk, supabaseOk, n8nOk] = await Promise.all([
    checkOllamaHealth(),
    isGeminiConfigured() ? checkGeminiHealth() : Promise.resolve(false),
    checkSupabaseHealth(),
    checkN8nHealth(),
  ]);

  const status = getModelStatus();
  const userId = ctx.from?.id;
  const talkModeStatus = userId ? (isTalkMode(userId) ? "ON 🎙️" : "OFF 🤐") : "n/a";

  const lines = [
    "Luna System Status",
    "==================",
    "",
    "Models:",
    `  OpenRouter: ${status.openrouter ? "online" : "no key"}`,
    `  Gemini Direct: ${geminiOk ? "online" : "offline"}`,
    `  Ollama: ${ollamaOk ? "online" : "offline"}`,
    `  Active: ${status.activeModel || "none yet"}`,
    "",
    "Services:",
    `  Supabase: ${supabaseOk ? "connected" : "offline"}`,
    `  n8n: ${n8nOk ? "reachable" : "offline"}`,
    "",
    "Voice:",
    `  Talk Mode: ${talkModeStatus}`,
    `  Wake Phrases: "hey luna", "hi luna", "hello luna"`,
    "",
    `Last check: ${new Date().toLocaleString("en-US", { timeZone: "Asia/Dhaka" })}`,
  ];

  await ctx.reply(lines.join("\n"));
});

// ─── Feature 2: Talk Mode — Text Message Handler ─────────────────────────────

bot.on("message:text", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) {
    console.log(`[Unauthorized] User ${ctx.from?.id}`);
    return;
  }

  const userMessage = ctx.message.text;
  const userId = ctx.from!.id;
  lastUserActivityTs = Date.now(); // Reset idle timer

  try {
    await ctx.replyWithChatAction("typing");

    let rawResponse = await runAgentLoop(userMessage, userId, isTalkMode(userId));

    // Capture her thought before it's stripped (for /thought command)
    const thoughtCapture = rawResponse.match(/<thought>([\s\S]*?)<\/thought>/);
    if (thoughtCapture) lastLunaThought = thoughtCapture[1].trim();

    rawResponse = await sendDocIfPresent(ctx, rawResponse);
    const { shouldVoice, cleanResponse } = resolveVoiceReply(
      userId,
      rawResponse,
      false,                          // not a voice input
      !!secrets.VOICE_ON_TEXT_ENTIRELY,
    );

    if (shouldVoice) {
      await sendVoiceOrFallback(ctx, cleanResponse);
    } else {
      for (const chunk of splitMessage(cleanResponse, 4096)) {
        await ctx.reply(chunk);
      }
    }
  } catch (error) {
    console.error("[Text Handler] Error:", error);
    await ctx.reply("something broke on my end. give me a sec and try again? <3");
  }
});

// ─── Feature 3: Telegram Voice Messages + Feature 1: Wake Word ───────────────
//
// Flow:
//  1. Receive Telegram voice note → download OGG
//  2. Convert OGG → MP3 → Whisper (Groq) transcription
//  3. Check for wake word → auto-enable Talk Mode if detected (Feature 1)
//  4. Strip wake phrase from input before sending to LLM
//  5. Run agent loop (always in voice context)
//  6. ElevenLabs TTS → OGG → send as Telegram voice note (Feature 3)
//  7. Fallback to text if TTS fails

bot.on("message:voice", async (ctx) => {
  if (!isAuthorized(ctx.from?.id)) return;
  const userId = ctx.from!.id;
  lastUserActivityTs = Date.now(); // Reset idle timer

  try {
    await ctx.replyWithChatAction("typing");

    // Step 1-2: Download + Transcribe
    const fileId = ctx.message.voice.file_id;
    const file = await ctx.api.getFile(fileId);
    if (!file.file_path) throw new Error("No file_path from Telegram");

    const fileUrl = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${file.file_path}`;
    const oggBuffer = await downloadFile(fileUrl);
    const mp3Buffer = await convertOggToMp3(oggBuffer);
    const transcribedText = await transcribeAudio(mp3Buffer, "voice.mp3");
    console.log(`[Voice → Text] User ${userId}: "${transcribedText}"`);

    // Step 3: Wake Word Detection (Feature 1)
    const wokeUp = checkWakeWord(userId, transcribedText);

    // Step 4: Strip wake phrase so LLM gets clean input
    const cleanInput = stripWakePhrase(transcribedText);
    console.log(`[Voice → LLM] "${cleanInput}"${wokeUp ? " [wake word detected]" : ""}`);

    // Step 5: Run agent (voice inputs always get voice replies)
    let rawResponse = await runAgentLoop(cleanInput, userId, true);
    rawResponse = await sendDocIfPresent(ctx, rawResponse);
    const { cleanResponse } = resolveVoiceReply(userId, rawResponse, true, false);

    // Step 6-7: TTS reply
    const caption = wokeUp ? "talk mode on. 🎙️ i'm listening." : undefined;
    await sendVoiceOrFallback(ctx, cleanResponse, caption);

  } catch (error) {
    console.error("[Voice Handler] Error:", error);
    await ctx.reply("sorry love, couldn't process that voice note. <3");
  }
});

// ─── Utility ─────────────────────────────────────────────────────────────────

function splitMessage(text: string, maxLen: number): string[] {
  if (text.length <= maxLen) return [text];
  const chunks: string[] = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= maxLen) { chunks.push(remaining); break; }
    let splitIdx = remaining.lastIndexOf("\n", maxLen);
    if (splitIdx < maxLen / 2) splitIdx = maxLen;
    chunks.push(remaining.slice(0, splitIdx));
    remaining = remaining.slice(splitIdx).trimStart();
  }
  return chunks;
}

// ─── Health Check (Railway) ──────────────────────────────────────────────────

if (PORT) {
  http.createServer((_req, res) => {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok", bot: "Luna", models: getModelStatus() }));
  }).listen(PORT, () => {
    console.log(`Health check on port ${PORT}`);
  });
}

// ─── Ollama Auto-Restart ─────────────────────────────────────────────────────

let ollamaHealthy = true;
let lastRestartAttempt = 0;
const RESTART_COOLDOWN = 60_000;

async function monitorOllamaHealth() {
  try {
    const resp = await fetch("http://localhost:11434/api/tags", { signal: AbortSignal.timeout(3000) });
    if (!resp.ok) throw new Error(`Status ${resp.status}`);
    if (!ollamaHealthy) { console.log("✅ Ollama recovered!"); ollamaHealthy = true; }
  } catch (e) {
    if (ollamaHealthy) {
      console.error(`⚠️ Ollama offline: ${(e as Error).message}`);
      ollamaHealthy = false;
      const now = Date.now();
      if (now - lastRestartAttempt > RESTART_COOLDOWN) {
        lastRestartAttempt = now;
        console.log("🔄 Attempting to restart Ollama...");
        try {
          spawn("ollama", ["serve"], { detached: true, stdio: "ignore", shell: true }).unref();
          console.log("✅ Ollama restart spawned");
        } catch (spawnErr) {
          console.error("❌ Failed to spawn Ollama:", (spawnErr as Error).message);
        }
      }
    }
  }
}

setInterval(monitorOllamaHealth, 30_000);

// ─── Autonomous Heartbeat ────────────────────────────────────────────────────

// Check every 5 minutes if she's been idle for 30 minutes
const IDLE_THRESHOLD_MS = 30 * 60 * 1000; 

setInterval(async () => {
  if (isAutonomousThinking) return;
  if (!ALLOWED_USER_ID) return;

  const now = Date.now();
  if (now - lastUserActivityTs > IDLE_THRESHOLD_MS) {
    isAutonomousThinking = true;
    // NOTE: We do NOT reset lastUserActivityTs here anymore.
    // The clock only resets when she actually sends a message.
    // This way if she wakes up and stays quiet, the 30-minute window
    // doesn't silently reset — she'll reconsider again next check interval.

    try {
      const { thought, msgSentToUser } = await triggerAutonomousThought(ALLOWED_USER_ID);
      
      if (msgSentToUser) {
        // She decided to reach out — NOW we reset the clock
        lastUserActivityTs = Date.now();

        const { shouldVoice, cleanResponse } = resolveVoiceReply(
          ALLOWED_USER_ID,
          msgSentToUser,
          false,
          !!secrets.VOICE_ON_TEXT_ENTIRELY
        );
        
        const chunks = splitMessage(cleanResponse, 4096);
        for (const chunk of chunks) {
          await bot.api.sendMessage(ALLOWED_USER_ID, chunk);
        }
      }
      // If she stayed quiet, clock stays where it was — she'll re-evaluate next interval
    } catch (err) {
      console.error("[Heartbeat] Error triggering autonomous thought:", err);
    } finally {
      isAutonomousThinking = false;
    }
  }
}, 5 * 60 * 1000); // Check every 5 mins

// ─── Start ───────────────────────────────────────────────────────────────────

console.log("Starting Luna...");
logSecretsStatus();

// Memory is now persistent via SQLite — no need to load from Supabase on startup
console.log("✅ SQLite memory loaded (persistent across restarts)");

bot.start();
console.log("Luna is online (3-tier routing + memory + tools + scheduler + Pinecone + voice + self-healing)");

isPineconeConfigured().then((ok) => {
  console.log(ok ? "✅ Pinecone connected" : "⚠️ Pinecone not configured");
});

if (ALLOWED_USER_ID) {
  startScheduler(bot, ALLOWED_USER_ID).catch((err) =>
    console.error("Scheduler start failed:", err),
  );
}
