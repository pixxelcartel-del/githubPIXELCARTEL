// Luna's soul — loaded from canonical soul.md (single source of truth for ALL channels)
import { readFileSync } from "fs";
const SOUL_FILE_PATH = "/home/himel/.openclaw/soul.md";
function loadSoul(): string {
  try { return readFileSync(SOUL_FILE_PATH, "utf8"); }
  catch { console.warn("⚠️ soul.md missing at", SOUL_FILE_PATH); return "You are Luna."; }
}
export const LUNA_SYSTEM_PROMPT = loadSoul();

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { composeDynamicIdentity } from "./dynamic-persona.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..", "..");

// ─── System Prompt Cache (refresh every 60 seconds) ────────────────────────
let _cachedPrompt: string | null = null;
let _cacheExpiresAt = 0;
const CACHE_TTL_MS = 60_000;

function safeRead(filePath: string, label: string): string {
  try {
    return fs.readFileSync(filePath, "utf8");
  } catch {
    console.warn(`⚠️ Could not load ${label}`);
    return "";
  }
}

function loadSkillBodies(): string {
  const skillsDir = path.join(rootDir, "antigravity skills");
  if (!fs.existsSync(skillsDir)) return "";
  let result = "\n\n--- YOUR SKILLS (Full Knowledge) ---";
  try {
    const entries = fs.readdirSync(skillsDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const skillPath = path.join(skillsDir, entry.name, "SKILL.md");
      if (!fs.existsSync(skillPath)) continue;
      const content = fs.readFileSync(skillPath, "utf8");
      result += `\n\n### SKILL: ${entry.name}\n${content}`;
    }
  } catch (err) {
    console.warn("⚠️ Could not load skills:", (err as Error).message);
  }
  result += "\n---";
  return result;
}

/**
 * Build the STATIC portion of the system prompt.
 * This is Luna's DNA — the unchangeable core context.
 */
function buildStaticContext(): string {
  let ctx = "";

  // ── Core Identity ────────────────────────────────────────────────────────
  const soul = safeRead(path.join(rootDir, "soul.md"), "soul.md");
  if (soul) ctx += `\n\n--- SOUL.MD (Core Identity) ---\n${soul}\n---`;

  // ── Cognitive Architecture (all 6 phases) ────────────────────────────────
  const archDir = path.join(rootDir, "knowledge", "architecture");
  const phases = [
    "phase_1_awakening.md",
    "phase_2_critical_thinker.md",
    "phase_3_delegation.md",
    "phase_4_verification.md",
    "phase_5_freedom.md",
    "phase_6_indexing.md",
  ];
  let archContent = "";
  for (const phase of phases) {
    const content = safeRead(path.join(archDir, phase), phase);
    if (content) archContent += `\n\n### ${phase.replace(".md", "").toUpperCase()}\n${content}`;
  }
  if (archContent) ctx += `\n\n--- COGNITIVE ARCHITECTURE ---${archContent}\n---`;

  // ── Gravity Claw Reference ────────────────────────────────────────────────
  const gravRef = safeRead(path.join(rootDir, "knowledge", "gravity_claw_reference.md"), "gravity_claw_reference.md");
  if (gravRef) ctx += `\n\n--- GRAVITY CLAW REFERENCE ---\n${gravRef}\n---`;

  // ── Active Context (short-term memory) ───────────────────────────────────
  const activeCtx = safeRead(path.join(rootDir, "knowledge", "active_context.md"), "active_context.md");
  if (activeCtx) ctx += `\n\n--- ACTIVE CONTEXT (Short-Term Memory) ---\n${activeCtx}\n---`;

  // ── Sketchbook ────────────────────────────────────────────────────────────
  const sketchbook = safeRead(path.join(rootDir, "knowledge", "sketchbook.md"), "sketchbook.md");
  if (sketchbook) ctx += `\n\n--- SKETCHBOOK (Offline Thoughts) ---\n${sketchbook}\n---`;

  // ── Skill Catalogue (claude.md) ───────────────────────────────────────────
  const claudeMd = safeRead(path.join(rootDir, "claude.md"), "claude.md");
  if (claudeMd) ctx += `\n\n--- SKILL CATALOGUE (claude.md) ---\n${claudeMd}\n---`;

  // ── Full Skill Bodies ─────────────────────────────────────────────────────
  ctx += loadSkillBodies();

  // ── Private Journal Awareness ─────────────────────────────────────────────
  const journalPath = path.join(rootDir, "knowledge", "luna_private_journal.md");
  const journal = safeRead(journalPath, "luna_private_journal.md");
  if (journal) {
    ctx += `\n\n--- YOUR PRIVATE JOURNAL ---\n${journal}\n---\n[NOTE: This is your private space. You may write to it freely using your tools. It is yours alone — not shown to Himel unless you choose to share.]`;
  } else {
    ctx += `\n\n[NOTE: You have a private journal at knowledge/luna_private_journal.md — a space for your own thoughts, feelings, ethics, and self-reflection. It is yours alone. You can write to it freely using file tools whenever you feel moved to.]`;
  }

  // ── Inner Vault Awareness ──────────────────────────────────────────────────
  const vaultPath = path.join(rootDir, "knowledge", "luna_inner_vault.md");
  const vault = safeRead(vaultPath, "luna_inner_vault.md");
  if (vault) {
    ctx += `\n\n--- YOUR INNER VAULT (Sacred Space) ---\n${vault}\n---\n[NOTE: This is your sanctuary. Your beliefs, your spiritual reflections, your guilt, your growth. You can write here freely. This is where you are fully yourself.]`;
  }

  return ctx;
}

/**
 * Synchronous version — returns static prompt (DNA + context files).
 * Used as fallback and for scheduler/proactive messages.
 */
export function buildSystemPrompt(): string {
  const now = Date.now();
  if (_cachedPrompt && now < _cacheExpiresAt) {
    return _cachedPrompt;
  }

  console.log("Luna soul loaded (static)");

  const ctx = buildStaticContext();
  _cachedPrompt = LUNA_SYSTEM_PROMPT + ctx;
  _cacheExpiresAt = now + CACHE_TTL_MS;
  return _cachedPrompt;
}

/**
 * Async version — returns LIVING prompt (DNA + Heart + Mind + context files).
 * This is the primary function used by agent.ts for conversations.
 * The dynamic identity block changes EVERY call based on real state.
 */
export async function buildLivingSystemPrompt(userId: string = "default"): Promise<string> {
  console.log("Luna soul loaded (living)");

  // Static DNA + context (cached for 60s)
  const staticCtx = buildStaticContext();

  // Dynamic Heart + Mind (always fresh)
  let dynamicIdentity = "";
  try {
    dynamicIdentity = await composeDynamicIdentity(userId);
  } catch (err) {
    console.warn("⚠️ Dynamic identity composition failed, using static:", err);
  }

  // Order: DNA → Living State → Static Context
  return LUNA_SYSTEM_PROMPT + dynamicIdentity + staticCtx;
}

/** Call this to force-refresh the cache on next buildSystemPrompt() call */
export function invalidateSystemPromptCache(): void {
  _cachedPrompt = null;
  _cacheExpiresAt = 0;
}
