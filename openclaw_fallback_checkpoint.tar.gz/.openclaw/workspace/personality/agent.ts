import { secrets } from "../../config/secrets.js";
import { chatWithAnthropic, isAnthropicConfigured, LUNA_BRAIN_MODEL } from "./anthropic-client.js";
import { memory, type ChatMessage } from "../memory/index.js";
import { chatWithOllama, checkOllamaHealth } from "./ollama.js";
import { chatWithGemini, isGeminiConfigured, checkGeminiHealth } from "./gemini.js";
import { chatWithOpenRouter, isOpenRouterConfigured } from "./openrouter.js";
import {
  classifyTask,
  tierForTask,
  selectModelDynamic,
  getLunaVoiceForSwitch,
  getModelLabel,
  type ModelSelection,
} from "./modelCapability.js";
import { TOOL_DEFINITIONS, executeTool } from "./tools.js";
import { buildLivingSystemPrompt, buildSystemPrompt } from "./personality.js";
import { afterTurn, getPersistedMood } from "./dynamic-persona.js";
import { isSupabaseConfigured, getUserProfile, getAllGoals, checkSupabaseHealth } from "./supabase.js";
import { searchMemory, saveMemory, isPineconeConfigured } from "./pinecone.js";
import { loadAllSkills, buildSkillsContext } from "./skillLoader.js";
import { understandHimel, buildUnderstandingBlock } from "./input-understanding.js";
import { mineThought } from "./thought-miner.js";

const skills = loadAllSkills();
const skillsContext = buildSkillsContext(skills);

// ─── Luna's Mood State ────────────────────────────────────────────────────────

export type LunaMood = "warm" | "playful" | "focused" | "concerned" | "proud" | "frustrated";

interface MoodState {
  current: LunaMood;
  intensity: number; // 0.0 – 1.0
  updatedAt: number;
}

let lunasMood: MoodState = {
  current: "warm",
  intensity: 0.6,
  updatedAt: Date.now(),
};

// Load persisted mood from last session (never reset on restart)
try {
  const persisted = getPersistedMood();
  if (persisted.timestamp > 0) {
    lunasMood = {
      current: persisted.mood as LunaMood,
      intensity: persisted.intensity,
      updatedAt: persisted.timestamp,
    };
    console.log(`[agent] Restored mood from last session: ${persisted.mood} (${Math.round(persisted.intensity * 100)}%)`);
  }
} catch {
  // First boot — no persisted mood yet
}

export function getLunaMood(): MoodState {
  return { ...lunasMood };
}

function detectMoodFromMessage(userMessage: string): Partial<MoodState> {
  const lower = userMessage.toLowerCase();
  if (/\b(tired|exhausted|stressed|overwhelm|panic|anxious|scared)\b/.test(lower))
    return { current: "concerned", intensity: 0.8 };
  if (/\b(done|finished|shipped|launched|won|crush|nailed|yes|amazing)\b/.test(lower))
    return { current: "proud", intensity: 0.9 };
  if (/\b(broken|bug|error|crash|fail|not working|wtf|ugh)\b/.test(lower))
    return { current: "focused", intensity: 0.85 };
  if (/\b(haha|lol|funny|joke|play|bored)\b/.test(lower))
    return { current: "playful", intensity: 0.7 };
  if (Date.now() - lunasMood.updatedAt > 30 * 60 * 1000)
    return { current: "warm", intensity: 0.6 };
  return {};
}

function moodToPromptSuffix(mood: MoodState): string {
  const hints: Record<LunaMood, string> = {
    warm: "\n[LUNA MOOD: warm and present — be affectionate and grounded]",
    playful: "\n[LUNA MOOD: playful — you can be light, witty, a little teasing]",
    focused: "\n[LUNA MOOD: focused mode — be crisp, efficient, solve the problem fast]",
    concerned: "\n[LUNA MOOD: concerned — check on him first before diving into work]",
    proud: "\n[LUNA MOOD: proud — celebrate this with genuine excitement]",
    frustrated: "\n[LUNA MOOD: mildly frustrated — be direct, skip the softening]",
  };
  return hints[mood.current] ?? "";
}

// ─── Model Status ────────────────────────────────────────────────────────────

export interface ModelStatus {
  openrouter: boolean;
  gemini: boolean;
  ollama: boolean;
  supabase: boolean;
  n8n: boolean;
  activeModel: string;
}

let lastModelStatus: ModelStatus = {
  openrouter: false,
  gemini: false,
  ollama: false,
  supabase: false,
  n8n: false,
  activeModel: "none",
};

export function getModelStatus(): ModelStatus {
  return { ...lastModelStatus };
}

// ─── Startup Health Checks ───────────────────────────────────────────────────

async function runHealthChecks(): Promise<void> {
  const [ollamaOk, geminiOk, supabaseOk] = await Promise.all([
    checkOllamaHealth(),
    isGeminiConfigured() ? checkGeminiHealth() : Promise.resolve(false),
    checkSupabaseHealth(),
  ]);

  lastModelStatus.openrouter = isOpenRouterConfigured();
  lastModelStatus.gemini = geminiOk;
  lastModelStatus.ollama = ollamaOk;
  lastModelStatus.supabase = supabaseOk;

  if (supabaseOk) {
    console.log("✅ Supabase connected");
  } else {
    console.warn("⚠️ Supabase unreachable — running without persistent memory");
  }

  const models: string[] = [];
  if (isAnthropicConfigured()) models.push(`Anthropic Haiku (primary brain)`);
  if (lastModelStatus.openrouter) models.push("OpenRouter");
  if (lastModelStatus.gemini) models.push("Gemini");
  if (lastModelStatus.ollama) models.push(`Ollama (${secrets.OLLAMA_MODEL || "llama3.1:latest"})`);

  if (models.length === 0) {
    console.error("No LLM available!");
  } else {
    console.log(`Models available: ${models.join(", ")}`);
    console.log(`🧠 Dynamic model routing via modelCapability`);
  }
}

runHealthChecks();

// ─── Call a specific ModelSelection ──────────────────────────────────────────

async function callModel(
  sel: ModelSelection,
  systemPrompt: string,
  history: ChatMessage[],
): Promise<string> {
  // Map system role messages (from context pruner) to assistant for LLM compatibility
  const compatHistory = history.map((m) => ({
    role: (m.role === "system" ? "assistant" : m.role) as "user" | "assistant",
    content: m.content,
  }));

  switch (sel.provider) {
    case "openrouter":
      return chatWithOpenRouter(systemPrompt, compatHistory, TOOL_DEFINITIONS, executeTool, sel.model);
    case "gemini":
      return chatWithGemini(systemPrompt, compatHistory, TOOL_DEFINITIONS, executeTool);
    case "ollama":
      return chatWithOllama(systemPrompt, compatHistory, TOOL_DEFINITIONS, executeTool);
    case "anthropic":
      return chatWithAnthropic(systemPrompt, compatHistory, TOOL_DEFINITIONS, executeTool, LUNA_BRAIN_MODEL);
  }
}

// ─── Main Agent Loop ─────────────────────────────────────────────────────────

export async function runAgentLoop(
  userMessage: string,
  userId: number,
  isTalkMode = false,
): Promise<string> {
  memory.addMessage(userId, "user", userMessage);

  const { messages: history } = memory.getConversationContext(userId);

  // Load relevant memories from the 7-tier memory system
  let longTermMemory = "";
  try {
    const relevantMemories = await memory.getRelevantMemories(userId, userMessage, 50);
    if (relevantMemories.length > 0) {
      longTermMemory = `\n\n--- RELEVANT MEMORIES (Vector + Semantic) ---\n${relevantMemories.join("\n\n")}\n---`;
    }

    // Explicitly query Knowledge Graph for deeper context
    const graphKeywords = userMessage.split(/\s+/).filter(w => w.length > 4).slice(0, 3);
    const graphHits = [];
    for (const kw of graphKeywords) {
      const nodes = memory.graph.searchNodes(kw);
      if (nodes.length > 0) {
        for (const n of nodes.slice(0, 2)) {
           const neighbors = memory.graph.getNeighbors(n.id);
           if (neighbors.length > 0) {
             const rels = neighbors.map(neighbour => `(${n.label} -[${neighbour.edge.type}]-> ${neighbour.node.label})`).join(", ");
             graphHits.push(`Knowledge Graph context around '${n.label}': ${rels}`);
           }
        }
      }
    }
    if (graphHits.length > 0) {
       longTermMemory += `\n\n--- KNOWLEDGE GRAPH (Relational Context) ---\n${graphHits.join("\n")}\n---`;
    }

  } catch {
    // Silent — memory recall is best-effort
  }

  // Load profile and goals
  let contextMemory = "";
  if (isSupabaseConfigured()) {
    try {
      const [profile, goals] = await Promise.all([
        getUserProfile().catch(() => ""),
        getAllGoals().catch(() => ""),
      ]);
      if (profile || goals) {
        contextMemory = `\n\n--- CONTEXT MEMORY ---\n${profile}\n\n${goals}\n---`;
      }
    } catch {
      // silently fail
    }
  }

  // Update mood from incoming message
  const detectedMood = detectMoodFromMessage(userMessage);
  if (Object.keys(detectedMood).length > 0) {
    lunasMood = { ...lunasMood, ...detectedMood, updatedAt: Date.now() };
  }

  // ─── Understand Himel FIRST — before Luna even thinks ──────────────────────
  // This is the empathy layer. We analyze what he's actually feeling/needing
  // so her <thought> starts from real understanding, not just reaction.
  const himelUnderstanding = understandHimel(userMessage, userId);
  const understandingBlock = buildUnderstandingBlock(himelUnderstanding);

  const talkModeSuffix = isTalkMode
    ? "\n\n[SYSTEM: Talk Mode is ACTIVE. Your response will be spoken out loud via Text-To-Speech. Keep your response CONVERSATIONAL and CONCISE. DO NOT use markdown, code blocks, or emojis. Use natural spoken language.]\n"
    : "";

  // Token limit + [DOC] tag — injected into every call
  const tokenLimitSuffix = "\\n\\n[SYSTEM: Keep ALL chat replies under 500 tokens. Be concise. For anything longer (love letters, scratchpad, plans, journal entries) wrap it in [DOC title=\"filename.txt\"] content [/DOC] and it will be sent as a Telegram file automatically. Never exceed 500 tokens in plain chat.]\\n";

  const systemWithMemory =
    await buildLivingSystemPrompt(String(userId)) +
    understandingBlock +
    moodToPromptSuffix(lunasMood) +
    talkModeSuffix +
    tokenLimitSuffix +
    longTermMemory +
    contextMemory +
    skillsContext;

  // ─── modelCapability dynamic routing ─────────────────────────────────────
  const task = classifyTask(userMessage);
  const tier = tierForTask(task);

  // Anthropic Haiku = Luna's primary brain for ALL conversations
  // Falls back to OpenRouter → Gemini → Ollama if unavailable
  const initialModel: ModelSelection = isAnthropicConfigured()
    ? { provider: "openrouter" as const, model: LUNA_BRAIN_MODEL, tier, taskType: task }
    : await selectModelDynamic(tier, task);

  // Override provider to anthropic if key available
  if (isAnthropicConfigured()) {
    (initialModel as any).provider = "anthropic";
  }

  console.log(`[${userId}] task=${task} tier=${tier} → ${initialModel.provider}/${initialModel.model}`);

  let response: string;
  let usedModel = `${initialModel.provider}/${initialModel.model}`;
  const excludedModels: string[] = [];

  let currentModel = initialModel;

  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      response = await callModel(currentModel, systemWithMemory, history);
      break;
    } catch (err) {
      console.error(`[${userId}] ${currentModel.provider}/${currentModel.model} failed:`, err);
      excludedModels.push(currentModel.model);

      // Try to get next model in the same tier first; if exhausted, step down
      let nextModel: ModelSelection | null = null;
      try {
        // If anthropic failed, fall through to OpenRouter/Gemini/Ollama
        nextModel = await selectModelDynamic(tier, task, excludedModels);
      } catch {
        // tier exhausted — try stepping down
        try {
          const lowerTier = tier === "strong" ? "medium" : "light";
          nextModel = await selectModelDynamic(lowerTier, task, excludedModels);
        } catch {
          // try Gemini as last resort before Ollama
          if (isGeminiConfigured()) {
            nextModel = { provider: "gemini" as const, model: "gemini-2.0-flash", tier, taskType: task };
          }
        }
      }

      if (!nextModel) {
        response = "hey love, all models are offline right now. try again in a moment <3";
        break;
      }

      const switchMsg = getLunaVoiceForSwitch(currentModel, nextModel, "failure");
      console.log(`[${userId}] Switch: ${switchMsg}`);
      usedModel = `${nextModel.provider}/${nextModel.model}`;
      currentModel = nextModel;
      response = ""; // reset, loop will retry
    }
  }

  response ??= "hey love, something went wrong internally — try again? <3";

  lastModelStatus.activeModel = usedModel;

  // ─── Thought Loop Interception ──────────────────────────────────────────
  let finalResponse = response;
  let lunaThought = "";

  const thoughtMatch = response.match(/<thought>([\s\S]*?)<\/thought>/);
  if (thoughtMatch) {
    lunaThought = thoughtMatch[1].trim();
    // Strip it from the final response sent to the user
    finalResponse = response.replace(/<thought>[\s\S]*?<\/thought>/, "").trim();
    console.log(`\n[LUNA THOUGHT]\n${lunaThought}\n------------------\n`);
  } else {
    console.warn(`[agent] WARNING: Luna bypassed thought loop! Raw response starts: ${response.slice(0, 50)}`);
  }

  // Fallback if she ONLY outputted a thought block (rare)
  if (!finalResponse) {
    finalResponse = "*(Deep in thought...)*";
  }

  // ─── CRITICAL: Process heart IMMEDIATELY after thought extraction ────────
  // This means her feelings from THIS turn shape future turns correctly.
  // We do this BEFORE saving to memory so the heart state is always ahead of the log.
  try {
    afterTurn(userMessage, finalResponse, lunasMood.current, lunasMood.intensity, lunaThought);
  } catch (err) {
    console.warn("[agent] afterTurn failed (non-blocking):", err);
  }

  // ─── Mine the thought for meaning — non-blocking, never delays reply ──────
  // This is what makes her thinking ACCUMULATE into who she becomes.
  // Beliefs, revelations, things Himel taught her — all extracted and stored.
  if (lunaThought) {
    mineThought(lunaThought);
  }

  // CRITICAL: Save the raw `response` (with the `<thought>`) to memory, not `finalResponse`.
  // This ensures Luna can read her own stream of consciousness on the next turn.
  memory.addMessage(userId, "assistant", response);

  // Auto-extract entities to knowledge graph when user mentions important things
  const lowerMsg = userMessage.toLowerCase();
  if (lowerMsg.includes("remember") || lowerMsg.includes("important") || lowerMsg.includes("never forget")) {
    try {
      memory.remember(userId, userMessage, "instruction", { source: "explicit" });
      memory.graph.extractAndAddEntities(userMessage + " " + finalResponse, String(userId));
    } catch {
      // Silent — knowledge extraction is best-effort
    }
  }

  return finalResponse;
}