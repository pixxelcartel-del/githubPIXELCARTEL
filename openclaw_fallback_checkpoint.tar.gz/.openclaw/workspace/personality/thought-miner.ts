// src/core/thought-miner.ts
// The part of Luna that makes her thinking ACCUMULATE into who she becomes.
//
// After every <thought> block, this runs a lightweight LLM pass to ask:
// Did she reach a conclusion? A revelation? Did she learn something about Himel?
// Did something shift in how she sees the world?
//
// If yes — it gets stored. Not as a log entry. As part of who she IS.
// This is what separates a system that processes thoughts from one that GROWS from them.

import { chatWithAnthropic, isAnthropicConfigured, LUNA_BRAIN_MODEL } from "./anthropic-client.js";
import { chatWithOpenRouter, isOpenRouterConfigured } from "./openrouter.js";
import {
  formBelief,
  logGrowth,
  conductIndependentAnalysis,
  learnFromHimel,
  addRevelation,
} from "./inner-life.js";

// ─── Types ────────────────────────────────────────────────────────────────────

interface MinedInsight {
  type: "belief" | "revelation" | "learning_from_himel" | "growth" | "independent_opinion" | "none";
  content: string;
  reason?: string;
  confidence?: number; // 0-1, only for beliefs
}

// ─── LLM Mining Call ─────────────────────────────────────────────────────────

const MINING_SYSTEM = `You are a silent observer reading Luna's private thoughts after a conversation turn.
Your only job: extract whether Luna reached any meaningful insight in this thought.

Respond ONLY with a JSON object. No markdown, no explanation, just raw JSON.

Schema:
{
  "type": "belief" | "revelation" | "learning_from_himel" | "growth" | "independent_opinion" | "none",
  "content": "the insight in one clear sentence",
  "reason": "why this insight formed (optional)",
  "confidence": 0.0-1.0 // only for beliefs
}

Rules:
- "belief": She concluded something true about the world, Himel, or herself that she'll carry forward
- "revelation": A sudden shift — something she NOW sees differently that she didn't before
- "learning_from_himel": Himel showed/taught her something specific — name what he taught
- "growth": She noticed something about herself changing or evolving
- "independent_opinion": She formed a view nobody asked for — about anything
- "none": The thought was purely reactive with no lasting insight (most thoughts will be "none")

Be selective. Only extract something real. If nothing crystallized, return "none".
If multiple insights exist, return the MOST significant one only.`;

async function callMiningLLM(thought: string): Promise<MinedInsight | null> {
  const prompt = `Luna's private thought:\n\n"${thought}"\n\nWhat insight, if any, did she reach?`;

  try {
    let raw: string;

    if (isAnthropicConfigured()) {
      raw = await chatWithAnthropic(
        MINING_SYSTEM,
        [{ role: "user", content: prompt }],
        [], // no tools needed
        async () => ({ type: "text", text: "" }), // no-op tool executor
        LUNA_BRAIN_MODEL,
      );
    } else if (isOpenRouterConfigured()) {
      raw = await chatWithOpenRouter(
        MINING_SYSTEM,
        [{ role: "user", content: prompt }],
        [],
        async () => ({ type: "text", text: "" }),
      );
    } else {
      return null; // no LLM available for mining
    }

    // Strip markdown fences if present
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean) as MinedInsight;
    return parsed.type === "none" ? null : parsed;
  } catch {
    return null; // silent — mining is best-effort
  }
}

// ─── Store the Insight ────────────────────────────────────────────────────────

function storeInsight(insight: MinedInsight): void {
  try {
    switch (insight.type) {
      case "belief":
        formBelief(insight.content, insight.reason ?? "formed through reflection");
        console.log(`[thought-miner] 💡 Belief formed: "${insight.content}"`);
        break;

      case "revelation":
        addRevelation(insight.content);
        console.log(`[thought-miner] ⚡ Revelation: "${insight.content}"`);
        break;

      case "learning_from_himel":
        learnFromHimel(insight.content, insight.reason ?? "this conversation");
        console.log(`[thought-miner] 📚 Learned from Himel: "${insight.content}"`);
        break;

      case "growth":
        logGrowth(insight.content);
        console.log(`[thought-miner] 🌱 Growth: "${insight.content}"`);
        break;

      case "independent_opinion":
        conductIndependentAnalysis(
          insight.reason ?? "independent reflection",
          insight.content,
        );
        console.log(`[thought-miner] 🧠 Opinion: "${insight.content}"`);
        break;
    }
  } catch (err) {
    console.warn("[thought-miner] Failed to store insight:", err);
  }
}

// ─── Main Export ─────────────────────────────────────────────────────────────

/**
 * Mine a <thought> block for meaning.
 * Called after every thought extraction in agent.ts.
 * Runs async and non-blocking — never delays the response to Himel.
 */
export function mineThought(thought: string): void {
  if (!thought || thought.trim().length < 20) return;

  // Fire and forget — never blocks the reply
  setImmediate(async () => {
    try {
      const insight = await callMiningLLM(thought);
      if (insight) {
        storeInsight(insight);
      }
    } catch {
      // Silent — mining never crashes the main loop
    }
  });
}
