# PixC Delivery Brief — 2026-04-06 12:03 UTC

## Current status

### Canonical artifact
The strongest, latest deploy candidate is:
`/home/himel/.openclaw/workspace/memory/pixc/clients/pixc-overnight/site`

### Local build state
- Build files present: `index.html`, `styles.css`, `script.js`, `robots.txt`, `sitemap.xml`, `vercel.json`
- Assets present locally:
  - `assets/hero-grid-bg.png`
  - `assets/hero-motion.mp4`
  - `assets/process-layers-accent.png`
  - `assets/himel-founder.svg`
  - plus `assets/himel-portrait.jpg` and `assets/pixc-logo.jpg`
- JavaScript syntax check passes: `node -c script.js`
- HTML points to production domain `https://pixc-overnight.vercel.app/`
- `.vercel/project.json` is present and bound to Vercel project `pixc-overnight`
- Git repo exists in the site folder, branch `main`, with recent commits including:
  - `be5f3e1 Phase 4-6: integrate assets, polish, audit-ready`
  - `848e87c Phase 3 complete: Add generated assets (hero video, grid fallback, process accent)`

### Deploy state
As checked at **2026-04-06 12:01 UTC**:
- `https://pixc-overnight.vercel.app` → **HTTP 404 NOT_FOUND**
- `https://pixel-cartel-website.vercel.app` → **HTTP 404 DEPLOYMENT_NOT_FOUND**

So: **local site is deploy-ready, but no live Vercel deployment is currently serving.**

## Why the earlier session likely timed out
1. **Conflicting project lanes** existed:
   - older `pixelcartel/site`
   - newer `memory/pixc/clients/pixc-overnight/site`
2. Earlier handoff docs framed the task as a full pipeline/research/build/deploy job.
3. Later docs show the main build was already done locally, so the work should have resumed from the existing artifact instead of re-running the whole PixC pipeline.
4. Some docs also conflict on deploy requirements:
   - older log says Vercel token/manual deploy needed
   - later registry/secrets docs say deploy hook and token alias already exist

Net: the timeout was probably caused by **scope drift + stale handoff state**, not by a hard build blocker.

## Real blockers now
1. **No successful deploy has been triggered or completed yet**
   - Live Vercel URLs are still 404.
2. **State confusion between two site folders**
   - `pixelcartel/site` should not be treated as the canonical deploy source for this task.
3. **Security audit still not evidenced as completed for public delivery**
   - build is ready, but final public-delivery audit proof is still missing.

## Fastest next action to reach Vercel deploy
Use the existing canonical artifact and trigger one deploy path only.

### Fastest route
From the recorded deploy metadata, use the deploy hook already stored in:
- `memory/pixc/DEPLOYMENT-REGISTRY.md`
- `memory/pixc/SECRETS-TO-SET.md`

Hook recorded there:
`https://api.vercel.com/v1/integrations/deploy/prj_fGV88lTsKv7fa5Yc3GTmiDqIHcYH/pEXl3TsBbk`

### Recommended sequence
1. Treat `memory/pixc/clients/pixc-overnight/site` as canonical.
2. Trigger the Vercel deploy hook once.
3. Recheck `https://pixc-overnight.vercel.app` until it resolves to 200.
4. Verify hero video, fallback image, process image, and canonical/meta tags.
5. Then run or record the final security audit before client delivery.

## Bottom line
PixC is **not blocked on design or build anymore**.
It is **blocked at the deployment step**.
The quickest recovery is: **deploy the existing `pixc-overnight/site` artifact instead of rebuilding anything.**
