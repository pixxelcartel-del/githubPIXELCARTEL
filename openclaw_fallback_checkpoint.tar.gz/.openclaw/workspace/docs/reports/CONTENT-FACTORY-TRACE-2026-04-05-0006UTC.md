# CONTENT FACTORY TRACE — 2026-04-05 00:06 UTC

Objective: trace content factory from webhook trigger to real downstream evidence, then use that truth to replace stale assumptions.

This file is the active trace target for the current run.

## Live Findings Snapshot
- Time: 2026-04-05 00:11:26 UTC

## Narrowed blocker update
- Imported workflow pack contains stale Supabase host references.
- Live n8n exports show active content workflows now point to fkqrdxukeejoomlzqirw.supabase.co.
- Next proof step: direct REST read of live content tables plus a controlled write-path trigger.
