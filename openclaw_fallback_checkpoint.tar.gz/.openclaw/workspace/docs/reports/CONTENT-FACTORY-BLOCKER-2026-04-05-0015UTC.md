# CONTENT FACTORY BLOCKER — 2026-04-05 00:15 UTC

## Exact blocker
The content factory downstream verification failure is caused by a Supabase project mismatch.

### Stale project embedded in imported workflow pack
- `jjpqiskuksqdstopdgib.supabase.co`

### Live n8n environment project
- `fkqrdxukeejoomlzqirw.supabase.co`

## Why previous verification failed
Attempts to prove downstream persistence against the old project/host were querying the wrong Supabase target.
This created misleading failures like:
- DNS/host not found for the stale host in some sessions
- wrong DB user/tenant path for direct Postgres attempts

## Operational truth
The correct next verification path is:
1. inspect active content workflows in live n8n
2. confirm whether they still point at stale project URLs or have already been corrected to the live project
3. verify writes against the LIVE project tables, not the stale one

## Rule
Do not trust workflow-pack host references as live truth when docker/n8n runtime env contradicts them.
Runtime/exported live workflows win.

## 18:56 UTC verification update
Checked the live project directly: content_ideas, content_scripts, and content_published are all still empty.
Checked docker logs for n8n-n8n-1 and found runtime failures on the content webhooks:
- luna-content-full-pipeline: Unused Respond to Webhook node found in the workflow
- luna-content-full-pipeline: No Respond to Webhook node found in the workflow
- luna-content-full-pipeline: requested webhook not registered
- luna-content-engine: requested webhook not registered

## Current operational conclusion
The immediate blocker is no longer just project mismatch. Runtime webhook registration and/or workflow response-node configuration is broken for the content-engine path.

## Escalation
Elon dispatched at 2026-04-05 18:57 UTC to repair live n8n workflow registration, rerun one controlled E2E cycle, and verify actual Supabase writes.
