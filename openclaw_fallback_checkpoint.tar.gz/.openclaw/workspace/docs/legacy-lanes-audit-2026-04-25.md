# Legacy Lanes Audit — 2026-04-25

## Live Runtime Truth

Verified from `/home/himel/.openclaw/openclaw.json`:
- Active agent ids: `luna`, `main`, `ernest`, `sun-tzu`, `elon`, `mark`, `a`
- Default workspace: `~/.openclaw/workspace`
- Active bindings point webchat and telegram to `luna`, with an extra webchat binding for `main`

This means Atlas/Nova/Cipher/Oracle are not part of the live runtime lineup.

## What the legacy lanes are currently doing

### 1. Historical identity and memory residue
Legacy names still appear in:
- old daily memory files
- archived build notes
- project handoff docs
- long-form design docs
- old task logs

Those references are historical, not live routing.

### 2. Documentation drift in active control files
Before repair, active files like these still contained stale routing:
- `/home/himel/.openclaw/workspace/TOOLS.md`
- `/home/himel/.openclaw/workspace/HEARTBEAT.md`
- `/home/himel/.openclaw/workspace/USER.md`
- `/home/himel/.openclaw/workspace/TASKS.md`

These created prompt-level drift even though runtime config had already moved on.

### 3. Physical artifact storage under legacy paths
The biggest real blocker is `workspace-atlas`, which still contains named assets such as:
- `mission-control`
- historical n8n gateway references in docs and notes
- backup exclusions and secret notes pointing at atlas-named paths

No currently running process was found using those paths during inspection, but the files still exist and some docs/secrets reference them.

### 4. Legacy agent folders on disk
These still exist on disk:
- `/home/himel/.openclaw/agents/atlas`
- `/home/himel/.openclaw/agents/nova`
- `/home/himel/.openclaw/agents/cipher`
- `/home/himel/.openclaw/agents/oracle`
- `/home/himel/.openclaw/workspace-atlas`
- `/home/himel/.openclaw/workspace-nova`
- `/home/himel/.openclaw/workspace-cipher`
- `/home/himel/.openclaw/workspace-oracle`

These are ghosts on disk, not live registered runtime agents.

## Required Current Agentic Lineup

Canonical Phase-1 lineup should be:
- `luna` — primary user-facing operating lane
- `ernest` — compression / synthesis / editorial reduction
- `sun-tzu` — orchestration / planning / research synthesis / strategy
- `elon` — engineering / implementation / deployment / git / infra
- `mark` — websites / frontend / product / content execution
- `a` — security / audit / adversarial review

`main` currently exists in runtime and bindings, but it is a legacy auxiliary lane and should not be treated as the primary identity lane unless config intentionally keeps it.

## Routing Alignment Needed

Prompt/control-file routing should resolve as:
- engineering, infra, code, deploy, git → `elon`
- website, frontend, design, most content execution → `mark`
- strategy, research synthesis, business decomposition → `sun-tzu`
- security / risk / hardening → `a`
- bulky summarization / reduction → `ernest`

## Bootstrap Resolution

The workspace was not actually fresh. Bootstrap failed conceptually because a stale first-contact bootstrap file remained after identity had already been established.

Resolution applied:
- `BOOTSTRAP.md` converted from false fresh-start prompt into a resolved bootstrap record
- canonical identity remains Luna + Himel
- future runs should stop treating this workspace as a blank slate

## Safe Removal Conditions For Legacy Lanes

Do not physically prune legacy directories until all live-reference classes are clean:
1. active control files no longer route to legacy names
2. no config files or service templates depend on legacy paths
3. no secrets or operational notes still point at required runtime assets there
4. any still-needed artifacts from `workspace-atlas` are migrated or archived intentionally

## Automation Added

Created:
- `/home/himel/.openclaw/workspace/scripts/prune-legacy-lanes.sh`

Current behavior:
- scans for active references to legacy agent/workspace paths
- refuses to prune if references still exist
- archives legacy paths into timestamped `/home/himel/.openclaw/backups/legacy-lanes-*` when clean

This is the right behavior for now because it prevents breaking hidden dependencies.

## Next Repair Pass

1. clean remaining live control files under both `workspace` and `workspace-main`
2. inspect `workspace-atlas` for assets that must be migrated, renamed, or intentionally archived
3. clean operational docs/secrets that still point to atlas path when they should point elsewhere
4. rerun the prune script
5. archive legacy lanes once the scan returns clean
