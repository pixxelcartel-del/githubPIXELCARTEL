# Content engine system plan

Implementation target: concrete enough for Claude Code to build without guessing architecture.

## Goal

Build a production-ready content engine on top of the existing Luna n8n workflows so the system can:

1. ingest ideas, links, transcripts, and prompts,
2. research and score opportunities,
3. generate content packs,
4. route outputs to review,
5. schedule approved posts,
6. log every run and artifact in Supabase,
7. keep the automation recoverable, auditable, and idempotent.

## Current foundation already present

Verified workflow building blocks in n8n:
- `luna-pipeline-research`
- `luna-pipeline-content`
- `luna-pipeline-saas`
- `luna-viral-content`
- `luna-content-scheduler`
- `luna-web-scrape`
- `luna-search-summarize`
- `luna-supabase-write`
- `luna-supabase-query`
- `luna-telegram-send`

These are enough to form a v1 content engine if they are wired around a shared data model and promoted behind a single intake contract.

## Non-negotiable design rules

- **No silent writes.** Every state change must be stored in Supabase with `created_at`, `updated_at`, `status`, and `run_id`.
- **Idempotent by key.** Retries must not create duplicate ideas, briefs, drafts, or scheduled posts.
- **Human approval before publish.** v1 can draft and schedule, but should not auto-publish unless a specific channel is flagged as trusted.
- **Single source of truth = Supabase.** n8n is orchestration only.
- **Workflow inputs/outputs must be typed JSON contracts.** No ad-hoc field names between workflows.
- **Every outbound integration wrapped in a gateway node or helper workflow.** Easier rotation, rate-limits, and auditing.

## System architecture

### 1. Intake layer

Purpose: normalize raw content opportunities into a single `content_ideas` table.

Sources:
- manual webhook submission,
- Telegram bot handoff,
- scraped URLs,
- search summaries,
- meeting notes,
- SaaS/research pipeline outputs.

Primary workflow:
- `luna-content-intake` (new)

Responsibilities:
- accept input payload,
- compute deterministic dedupe key,
- store source record,
- attach metadata,
- enqueue research if needed.

Suggested webhook contract:

```json
{
  "source_type": "telegram|manual|scrape|meeting|research|saas",
  "source_ref": "optional external id",
  "title": "optional raw title",
  "raw_text": "optional body",
  "url": "optional source url",
  "topic": "optional topic",
  "target_channel": "x|linkedin|blog|email|multi",
  "priority": "low|normal|high",
  "requested_by": "user or system",
  "metadata": {}
}
```

Idempotency key:
- `sha256(source_type + source_ref + normalized_url + normalized_title + raw_text[:500])`

### 2. Research layer

Purpose: turn a raw idea into a researched brief.

Primary workflow:
- reuse `luna-pipeline-research`

Responsibilities:
- fetch/extract source material,
- summarize the input,
- score novelty, timeliness, and relevance,
- produce angle options,
- decide whether to discard, hold, or promote to draft.

Output contract:

```json
{
  "idea_id": "uuid",
  "research_status": "complete",
  "summary": "...",
  "core_claims": ["..."],
  "supporting_points": ["..."],
  "risks": ["factual uncertainty", "weak source"],
  "angles": [
    {"label": "contrarian", "score": 0.72},
    {"label": "practical", "score": 0.84}
  ],
  "recommended_angle": "practical",
  "audience": "founders",
  "cta": "reply/book/demo/read more",
  "confidence": 0.81
}
```

### 3. Draft generation layer

Purpose: generate platform-specific assets from one approved brief.

Primary workflows:
- reuse `luna-pipeline-content`
- reuse `luna-viral-content`
- add `luna-content-render` (new)

Responsibilities:
- create long-form draft,
- create short-form social variants,
- create hook bank,
- create headline bank,
- create CTA options,
- optionally create image prompt / thumbnail prompt.

Output artifacts per idea:
- 1 master brief,
- 1 canonical long-form draft,
- 3–5 short-form variants,
- 5 hooks,
- 3 CTAs,
- 1 metadata object for scheduling.

### 4. Review layer

Purpose: keep human-in-the-loop before scheduling or publish.

Primary workflow:
- `luna-content-review-queue` (new)

Responsibilities:
- push draft summary to Telegram or another operator inbox,
- include approve / reject / revise actions,
- write decision back to Supabase,
- on approve -> schedule,
- on revise -> reopen drafting with notes.

Review message payload should include:
- title,
- one-line summary,
- risk flags,
- target channel,
- preferred publish window,
- deep link to full draft,
- action tokens.

### 5. Scheduling layer

Purpose: turn approved content into platform queue records.

Primary workflow:
- reuse `luna-content-scheduler`

Responsibilities:
- choose schedule window,
- avoid collisions,
- enforce per-channel daily caps,
- store final queue record,
- notify on successful queue placement.

Rules:
- X: max 3/day
- LinkedIn: max 1/day
- Blog: max 1/day
- Email: max 1/day
- never schedule two items for same channel within 90 minutes unless explicitly overridden.

### 6. Publish/execution layer

Purpose: optional v2. For v1, scheduling is enough.

Suggested workflows:
- `luna-publish-x`
- `luna-publish-linkedin`
- `luna-publish-blog`
- `luna-publish-email`

For now these can remain stubs that read `scheduled_posts` rows with `status='approved'` and `publish_mode='manual'` or `publish_mode='auto'`.

## Supabase schema Claude Code should implement

### `content_ideas`

```sql
create table if not exists content_ideas (
  id uuid primary key default gen_random_uuid(),
  dedupe_key text unique not null,
  source_type text not null,
  source_ref text,
  url text,
  title text,
  raw_text text,
  topic text,
  target_channel text,
  priority text default 'normal',
  status text not null default 'new',
  requested_by text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
```

### `content_research`

```sql
create table if not exists content_research (
  id uuid primary key default gen_random_uuid(),
  idea_id uuid not null references content_ideas(id) on delete cascade,
  run_id text not null,
  summary text,
  core_claims jsonb not null default '[]'::jsonb,
  supporting_points jsonb not null default '[]'::jsonb,
  risks jsonb not null default '[]'::jsonb,
  angles jsonb not null default '[]'::jsonb,
  recommended_angle text,
  audience text,
  cta text,
  confidence numeric,
  status text not null default 'complete',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists content_research_idea_run_uidx on content_research (idea_id, run_id);
```

### `content_drafts`

```sql
create table if not exists content_drafts (
  id uuid primary key default gen_random_uuid(),
  idea_id uuid not null references content_ideas(id) on delete cascade,
  research_id uuid references content_research(id) on delete set null,
  run_id text not null,
  draft_type text not null,
  channel text not null,
  title text,
  body text not null,
  hooks jsonb not null default '[]'::jsonb,
  ctas jsonb not null default '[]'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  status text not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists content_drafts_run_type_channel_uidx on content_drafts (idea_id, run_id, draft_type, channel);
```

### `content_reviews`

```sql
create table if not exists content_reviews (
  id uuid primary key default gen_random_uuid(),
  draft_id uuid not null references content_drafts(id) on delete cascade,
  reviewer text,
  decision text not null,
  notes text,
  decided_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);
```

### `scheduled_posts`

```sql
create table if not exists scheduled_posts (
  id uuid primary key default gen_random_uuid(),
  draft_id uuid not null references content_drafts(id) on delete cascade,
  channel text not null,
  publish_mode text not null default 'manual',
  scheduled_for timestamptz,
  status text not null default 'queued',
  platform_ref text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
```

### `workflow_runs`

```sql
create table if not exists workflow_runs (
  id uuid primary key default gen_random_uuid(),
  run_id text unique not null,
  workflow_name text not null,
  entity_type text,
  entity_id uuid,
  status text not null,
  error text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
```

## n8n workflow implementation plan

### New workflows Claude Code should create

1. `luna-content-intake`
   - Webhook trigger
   - Normalize payload
   - Generate dedupe key
   - Supabase upsert into `content_ideas`
   - Branch:
     - if existing approved draft exists -> stop
     - else -> call `luna-pipeline-research`

2. `luna-content-review-queue`
   - Trigger from draft completion
   - Read draft + research summary
   - Send review packet to Telegram
   - Wait for approval/reject/revise callback
   - Write to `content_reviews`

3. `luna-content-render`
   - Internal callable workflow
   - Input: idea + research + target channels
   - Output: rows in `content_drafts`

4. `luna-content-orchestrator`
   - Cron or manual trigger
   - Pull pending ideas
   - Batch by priority
   - Route to research/draft/review/schedule

### Existing workflows to adapt

- `luna-pipeline-research`
  - ensure output matches the `content_research` contract
  - ensure it writes status back to `content_ideas`

- `luna-pipeline-content`
  - ensure it writes to `content_drafts`
  - support multi-channel generation from one brief

- `luna-content-scheduler`
  - read approved drafts from Supabase
  - write to `scheduled_posts`
  - enforce per-channel spacing rules

- `luna-supabase-query` and `luna-supabase-write`
  - standardize them as internal helper workflows with strict payload schemas

## Contract boundaries between workflows

### Research input

```json
{
  "idea_id": "uuid",
  "title": "...",
  "raw_text": "...",
  "url": "...",
  "target_channel": "multi",
  "metadata": {}
}
```

### Draft input

```json
{
  "idea_id": "uuid",
  "research_id": "uuid",
  "audience": "founders",
  "recommended_angle": "practical",
  "channels": ["x", "linkedin", "blog"],
  "brand_rules": {
    "tone": "sharp, useful, non-fluffy",
    "banned_phrases": ["unlock", "game changer"],
    "cta_style": "direct"
  }
}
```

### Review callback input

```json
{
  "draft_id": "uuid",
  "decision": "approve|reject|revise",
  "notes": "optional reviewer note",
  "reviewer": "telegram:username"
}
```

## Error handling

Claude Code should implement these patterns everywhere:

- generate `run_id` at workflow start,
- write a `workflow_runs` row at start and finish,
- wrap external API calls with retry policy,
- on hard failure set `status='failed'` and preserve payload snapshot,
- on duplicate dedupe key, treat as success and attach to existing entity,
- never drop payloads on parse errors; store them in `content_ideas.metadata.raw_payload`.

## Rate limit policy

- OpenAI: batch prompts when generating multi-channel variants.
- Telegram: one summary message per review item, edits instead of repeated sends when possible.
- Supabase: prefer single upserts with JSON payloads over many small writes.
- Web scraping: apply per-domain throttling.

## Security model

- Keep API keys only in n8n credentials or `.env`, never in workflow JSON committed to git.
- Strip secrets from all logs.
- Validate inbound webhook signatures for any public intake endpoint.
- Review queue actions must use signed callback tokens with expiry.
- Supabase service-role key only for server-side workflows; never expose to client artifacts.
- Maintain allowlist of publish destinations before any auto-publish mode is enabled.

## Claude Code task list

1. Create SQL migrations for the five core tables plus indexes.
2. Create a shared TypeScript file with the JSON contracts used by workflows.
3. Add n8n workflow JSON for the four new workflows.
4. Refactor existing research/content/scheduler workflows to use the contracts.
5. Add helper functions for dedupe-key generation and status transitions.
6. Add Telegram review action handlers.
7. Add a smoke-test script that:
   - inserts a sample idea,
   - runs research,
   - generates drafts,
   - requests review,
   - approves one draft,
   - schedules it.
8. Export all final workflow JSON to a tracked directory for reproducible restore.

## Definition of done

The content engine is v1-complete when:
- a single webhook can create a content idea,
- the idea is researched automatically,
- at least 2 channel variants are generated,
- a human can approve via review queue,
- the approved variant is written to `scheduled_posts`,
- every step is queryable in Supabase by `idea_id` and `run_id`,
- rerunning the same intake payload does not create duplicates.
