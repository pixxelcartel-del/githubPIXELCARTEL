# Skills to add and audit

Purpose: identify the highest-value AgentSkills/automation skills to add or tighten around the Luna + n8n + content stack.

## Priority order

### 1. Add: `n8n-live-ops`

**Why:** there is already enough workflow surface area that Luna needs a dedicated operational skill for inventory, activation checks, import/export hygiene, and gateway diagnosis.

**What it should cover**
- snapshot live workflows,
- distinguish canonical vs duplicate imports,
- verify active/inactive state,
- inspect gateway logs and health,
- verify credential presence without leaking secrets,
- export reproducible workflow packs,
- document blockers in a standard format.

**Suggested references**
- n8n docs: <https://docs.n8n.io/>
- n8n REST API: <https://docs.n8n.io/api/>
- n8n self-hosting: <https://docs.n8n.io/hosting/>

**Security notes**
- Never dump raw credential values.
- Mask tokens, emails, webhook secrets, and service-role keys.
- Do not auto-activate workflows after import without explicit verification.
- Treat duplicate workflow imports as a possible integrity issue, not just clutter.

---

### 2. Add: `supabase-ops`

**Why:** the content engine depends on Supabase as the system of record. There should be a skill that handles schema checks, migration hygiene, query verification, RLS review, and connectivity diagnosis.

**What it should cover**
- migrations,
- idempotent upserts,
- RLS policy auditing,
- service-role vs anon key usage,
- indexing checks,
- failure triage for DNS/network/auth/schema errors.

**Suggested references**
- Supabase docs: <https://supabase.com/docs>
- Postgres functions/extensions in Supabase: <https://supabase.com/docs/guides/database>
- RLS guide: <https://supabase.com/docs/guides/auth/row-level-security>

**Security notes**
- Service-role key must never be pasted into docs, logs, or chat output.
- Any skill action that writes migrations should avoid destructive SQL unless explicitly approved.
- RLS bypass paths should be clearly annotated.

---

### 3. Add: `content-engine-builder`

**Why:** the plan now exists, but Claude Code/Luna would benefit from a dedicated build skill that knows the content-engine schema, workflow contracts, review gates, and idempotency rules.

**What it should cover**
- generating workflow JSON,
- generating Supabase migrations,
- drafting channel-specific prompts,
- review queue design,
- scheduling policy enforcement,
- run logging and auditability.

**Suggested references**
- n8n docs: <https://docs.n8n.io/>
- Supabase docs: <https://supabase.com/docs>
- OpenAI platform docs: <https://platform.openai.com/docs>

**Security notes**
- Never hardcode API keys into workflow JSON.
- Avoid prompt templates that include secrets or private customer data.
- Require human approval before enabling auto-publish behaviors.

---

### 4. Add: `telegram-ops`

**Why:** Telegram is already present in the workflow set for notifications and likely review routing. A dedicated skill should standardize bot setup, callback handling, message editing, and safe operator actions.

**What it should cover**
- bot token validation,
- send/edit/delete policies,
- review callbacks,
- inline approval flows,
- chat/channel routing,
- rate-limit-aware notification batching.

**Suggested references**
- Telegram Bot API: <https://core.telegram.org/bots/api>

**Security notes**
- Bot tokens must always be masked.
- Review callbacks should be signed and expire quickly.
- Approval actions must verify actor identity where possible.

---

### 5. Add: `gmail-send-safe`

**Why:** there is already a `luna-send-email` and `luna-invoice` workflow. Email deserves a tighter delivery skill with stronger safety rails.

**What it should cover**
- OAuth credential verification,
- safe-send rules,
- recipient allowlists for test mode,
- attachment policy,
- invoice/email drafting with dry-run support.

**Suggested references**
- Gmail API docs: <https://developers.google.com/gmail/api>

**Security notes**
- Default to draft mode or allowlisted recipients in testing.
- Never expose OAuth refresh tokens.
- Log message metadata, not full sensitive bodies, unless explicitly requested.

## Existing skills to audit now

### `n8n-workflow-automation`
Location:
- `~/.openclaw/skills/n8n-workflow-automation/SKILL.md`

Why audit it:
- It is relevant to this system, but it appears focused on generating workflow JSON generally. It should be checked for:
  - idempotency guidance,
  - operational restore/import guidance,
  - duplicate workflow detection,
  - credential hygiene,
  - human review gates.

Audit questions:
- Does it clearly separate build-time workflow generation from live-instance operations?
- Does it warn against storing secrets in exported workflow JSON?
- Does it encode retry/backoff and audit logging by default?

### `mcporter`
Location:
- `~/.npm-global/lib/node_modules/openclaw/skills/mcporter/SKILL.md`

Why audit it:
- Useful for direct MCP tool/server work, but it can become a powerful escape hatch if it encourages arbitrary server calls without guardrails.

Audit questions:
- Does it properly warn before external writes?
- Does it distinguish read-only inspection from mutating operations?
- Does it avoid leaking config secrets in generated examples?

### `qmd`
Location:
- `~/.openclaw/skills/qmd/SKILL.md`

Why audit it:
- Strong fit for research retrieval and content idea search, but it should be checked for privacy boundaries and indexing scope.

Audit questions:
- Does it default to least-privileged indexing?
- Does it explain how to exclude secrets, env files, and exported credentials?
- Can it support retrieval for the content engine without indexing sensitive runtime artifacts?

### `web-search-exa`
Location:
- `~/.openclaw/skills/web-search-exa/SKILL.md`

Why audit it:
- Important for research workflows, but web research needs sourcing discipline.

Audit questions:
- Does it encourage citation capture and source provenance?
- Does it distinguish fresh news from evergreen references?
- Does it warn against copying copyrighted content into drafts verbatim?

## Skills I would not add yet

### `auto-publisher`
Not yet.

Reason:
- The current system is still not fully live.
- Workflows are inactive.
- Gateway health is blocked.
- Human review should stay mandatory until the data layer and review queue are stable.

### `credential-rotator`
Not yet.

Reason:
- Useful later, but premature right now.
- Rotating working credentials without complete operational visibility could break the system faster than it helps.

## Recommended skill directory structure for new additions

For each new skill:

```text
skill-name/
  SKILL.md
  references/
    docs.md
    examples.md
  scripts/
    smoke-test.sh
    helpers.py
```

## Required standards for every new skill

1. Explicit read-only vs mutating mode.
2. Secret redaction rules.
3. Retry and rate-limit guidance.
4. Idempotency expectations.
5. Rollback or recovery section.
6. Clear “when not to use this skill” section.
7. Links to authoritative vendor docs.

## Highest-value immediate next move

If only one new skill gets created first, make it:

**`n8n-live-ops`**

Reason:
- it directly addresses the current blocker set,
- it would institutionalize the live inventory workflow,
- it would prevent future duplicate imports,
- it would make the gateway failure mode diagnosable in one place.

## Current security callouts tied to this system

- The gateway is not healthy because port `3456` is already in use; any future skill touching gateway lifecycle should detect port conflicts before restart loops.
- Workflow exports/imports can create duplicate IDs or duplicate logical workflows; any n8n skill must compare by both **name** and **ID set**.
- Supabase verification from this session previously hit DNS resolution issues; skills should distinguish auth failures from network failures.
- Email, Telegram, and OpenAI integrations all require credential masking by default.
