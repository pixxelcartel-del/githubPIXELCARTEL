# Claude Code System Polish Brief

## Current confirmed state
- Memory stack is hardened locally: qmd refreshed, Mem0 live, Qdrant live, Neo4j live, maintenance and audit scripts added.
- n8n MCP gateway artifacts exist locally at `/home/himel/.openclaw/workspace-atlas/n8n-mcp-gateway`.
- Himel reported the major Claude session completed the gateway build and that `20 workflows` are imported with `8 active` right now.
- Exact session brief path `~/.openclaw/workspace/memory/n8n-gateway-session.md` was referenced by Himel but was not found at that exact path during Luna follow-up; verify the final file location before cleanup.
- `git` is installed already. `brew` is not present on this Ubuntu VPS and is not the preferred package path here unless there is a very specific package only available that way.

## What Luna needs Claude Code to polish

### 1. n8n gateway finalization
- Verify the true location/content of the session brief and preserve it in markdown memory.
- Audit `/home/himel/.openclaw/workspace-atlas/n8n-mcp-gateway` end-to-end:
  - `deploy.sh`
  - `src/index.js`
  - `src/smoke-test.js`
  - `Dockerfile`
  - `systemd/luna-n8n-gateway.service`
- Confirm both access paths work:
  - native n8n MCP in OpenClaw config
  - Luna gateway HTTP path
- Produce one authoritative live report with:
  - all 20 workflows
  - which 8 are active now
  - exact workflow IDs
  - exact webhook paths / trigger methods
  - required credentials for each workflow
  - which workflows are safe to auto-activate
  - which remain blocked and why

### 2. Workflow activation cleanup
- Publish/activate the remaining import-safe workflows only after validating credentials and runtime configuration.
- Remove any dependence on brittle `$env.*` runtime expressions inside n8n where credentials or proper variables should be used instead.
- Ensure webhook registration survives restart and matches production URLs.
- Leave a final machine-readable report in the workspace.

### 3. Security pass
For every gateway/workflow integration, check:
- secrets are not hardcoded into source or markdown files
- only credential names are stored in n8n where possible
- exposed HTTP routes are intentional and minimally scoped
- reverse proxy / bind assumptions are documented
- no dead or stale endpoints remain in OpenClaw config
- plugin and gateway dependencies are pinned where practical

### 4. Content creation engine design + implementation plan
Design the system as a pipeline, not isolated scripts. Cover:
- research ingestion
- trend + competitor analysis
- angle generation
- prompt generation
- script writing
- storyboard generation
- image generation
- video generation / assembly
- metadata/title/thumbnail hooks
- publishing / scheduling
- performance collection
- feedback loop into memory and next content decisions

### 5. Best skill stack to source / add / refine
Collect links and evaluate fit/security for these categories:
- n8n / automation / MCP gateway skills
- web research / extraction skills
- YouTube / transcript / video frame skills
- image generation workflow skills
- video editing / ffmpeg / assembly skills
- analytics / tracking / reporting skills
- copywriting / humanization skills
- memory / knowledge graph / retrieval skills
- social publishing / scheduling workflow skills

## Candidate existing local skills to build around
- `/home/himel/.openclaw/workspace/skills/n8n-workflow-automation`
- `/home/himel/.openclaw/workspace/skills/web-search-exa`
- `/home/himel/.openclaw/workspace/skills/youtube-full`
- `/home/himel/.openclaw/workspace/skills/xurl`
- `/home/himel/.openclaw/workspace/skills/ai-humanizer`
- `/home/himel/.openclaw/workspace/skills/theme-factory`
- `/home/himel/.openclaw/workspace/skills/web-artifacts-builder`
- built-in OpenClaw skills already available in runtime: video-frames, weather, openai-whisper, tmux, qmd, healthcheck, node-connect

## Useful source links already visible locally
- Exa MCP server: https://github.com/exa-labs/exa-mcp-server
- Humanizer: https://github.com/brandonwise/humanizer
- Theme factory reference: https://github.com/wpank/ai/tree/main/skills/design-systems/theme-factory
- OpenClaw docs: https://docs.openclaw.ai
- OpenClaw source: https://github.com/openclaw/openclaw
- Skill hub: https://clawhub.com

## Immediate questions Claude Code should answer
- What are the exact 8 active workflows right now?
- Which remaining workflows are closest to activation once credentials/runtime are cleaned up?
- What exact credentials are still missing or stale?
- Which parts of the content engine can be implemented immediately with current infra?
- Which additional skills/tools are worth adding versus building as n8n workflows?

## Implementation constraints
- Engineering changes belong to Atlas / Claude Code style execution.
- Keep Luna's main chat thread free; do not require repetitive manual confirmations.
- Prefer Ubuntu-native package management over Homebrew on this VPS unless there is a compelling reason.
- Every new integration must pass a security review before activation.
- Every durable fact or correction must be written back into markdown memory and, where useful, Mem0.
