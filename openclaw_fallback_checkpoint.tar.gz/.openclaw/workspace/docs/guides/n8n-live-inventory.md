# n8n live inventory

Last verified from local artifacts on 2026-03-27 UTC.

## Executive summary

- Live n8n snapshot currently contains **20 workflows**.
- **Operational state right now:** all 20 live workflows are present but **inactive** (`active: false`).
- The currently live set uses the original **UUID-based IDs** from `tmp-n8n-live/backup.json/` and `tmp-n8n-restore/live-workflows-after-import.json`.
- A second import artifact exists at `tmp-n8n-restore/luna-workflows.n8n-import.regenerated.json` with **20 replacement UUIDs**. That regenerated set should be treated as the **duplicate import candidate**, not the canonical live inventory.
- I did **not** find any actual short numeric IDs in the current live/exported artifacts. The duplicate set I could verify is a second UUID set, not short IDs.

## Gateway status: not healthy

The Dockerized/local gateway path is **not healthy**.

**Exact blocker:** the gateway repeatedly fails with `EADDRINUSE` because port **3456** is already occupied.

Evidence:
- Service template: `/home/himel/.openclaw/workspace-atlas/n8n-mcp-gateway/systemd/luna-n8n-gateway.service`
- Configured port: `Environment=GATEWAY_PORT=3456`
- Log file: `/home/himel/.openclaw/workspace-atlas/n8n-mcp-gateway/gateway.log`
- Error lines in log:
  - `Error: listen EADDRINUSE: address already in use :::3456`
  - `code: 'EADDRINUSE'`
  - `port: 3456`

Interpretation:
- The gateway was previously fixed so systemd no longer exits immediately after `app.listen()`, but the service still cannot be considered healthy because **another process is already bound to 3456**.
- Until the port conflict is removed or the gateway is moved to a free port, the Dockerized/local gateway path should be treated as **blocked**.

## Canonical live workflows (actual current state)

| Workflow | Live ID | Current state | Nodes | Trigger/entry |
|---|---|---:|---:|---|
| luna-morning-brief | `16ca9ab5-c84a-4a7b-8674-947bcf8c1723` | inactive | 4 | Daily 7am BDT |
| luna-ai-intel | `170a2e65-1272-4368-8463-b73a6bb05c62` | inactive | 4 | Daily 9am BDT |
| luna-pipeline-content | `249a22b8-2213-40d0-8558-e86e0cbae861` | inactive | 4 | Webhook, Respond |
| luna-file-processor | `32371f7d-7034-40d3-aed1-623c53904a4b` | inactive | 3 | Webhook, Respond |
| luna-viral-content | `40aacee5-e218-4ff2-98f7-57b5aa10cf36` | inactive | 4 | Webhook, Respond |
| luna-meeting-logger | `528bc6ec-ab69-4e17-b0bf-76734266538b` | inactive | 4 | Webhook, Respond |
| luna-search-summarize | `5a4f1ca9-3e5d-4bd1-978f-b4775d1e623b` | inactive | 4 | Webhook, Respond |
| luna-telegram-send | `5e8b15f4-9d69-4393-923e-9300e68bc137` | inactive | 3 | Webhook, Respond |
| luna-night-shift | `6389dc8c-713e-4e5d-88ff-e4314118648f` | inactive | 4 | Daily 11pm BDT |
| luna-supabase-query | `6ee54dbb-276d-4c22-9a97-5cd78c06f660` | inactive | 3 | Webhook, Respond |
| luna-cost-audit | `88f59b0d-d8e5-47f3-92f0-3ddb5490f678` | inactive | 4 | Daily 8am BDT |
| luna-send-email | `94524ea6-8b65-42bf-810c-414cfec7c916` | inactive | 3 | Webhook, Respond |
| luna-supabase-write | `a172707a-8f25-4450-a4d3-f34139d19d59` | inactive | 3 | Webhook, Respond |
| luna-pipeline-research | `a4be65c2-9cb9-4318-ab2e-877c280b59e2` | inactive | 5 | Webhook, Respond |
| luna-crm-write | `bc9d810d-8617-4e92-ab98-e4049effebf9` | inactive | 3 | Webhook, Respond |
| luna-content-scheduler | `bf1eab65-5210-4243-b6ca-13b293152d9d` | inactive | 4 | Webhook, Respond |
| luna-lead-qualifier | `e26901cf-fe31-4412-9c31-2f051bf5a936` | inactive | 5 | Webhook, Respond |
| luna-web-scrape | `e57bf5f5-372b-464e-a6aa-85e52c7b39a9` | inactive | 3 | Webhook, Respond |
| luna-invoice | `f44f0ad0-afaf-4f9c-b7ac-1de6ceed922c` | inactive | 4 | Webhook, Respond |
| luna-pipeline-saas | `ffcb6b50-26a5-4d29-bcec-af99ce0bf662` | inactive | 3 | Webhook, Respond |

## Active vs duplicate distinction

### A. Canonical/original ID set

Source of truth:
- `/home/himel/.openclaw/workspace-atlas/tmp-n8n-live/backup.json/*.json`
- `/home/himel/.openclaw/workspace-atlas/tmp-n8n-restore/live-workflows-after-import.json`

Properties:
- 20 workflows
- IDs match the original workflow pack
- This is the set that currently exists in the live snapshot
- Current live state: **all inactive**

### B. Duplicate/regenerated ID set

Artifact:
- `/home/himel/.openclaw/workspace-atlas/tmp-n8n-restore/luna-workflows.n8n-import.regenerated.json`

Properties:
- 20 workflows with the same names as the canonical set
- IDs were regenerated to satisfy import/version constraints
- This set should be treated as **duplicate import material**, not the current live inventory

| Workflow | Canonical live ID | Duplicate regenerated ID |
|---|---|---|
| luna-meeting-logger | `528bc6ec-ab69-4e17-b0bf-76734266538b` | `39f8765f-879b-4324-9c54-f5b66575a80f` |
| luna-lead-qualifier | `e26901cf-fe31-4412-9c31-2f051bf5a936` | `1a9771f6-5c7c-43b1-a8f5-41b8879fbd15` |
| luna-viral-content | `40aacee5-e218-4ff2-98f7-57b5aa10cf36` | `41a5fd0f-e614-4c32-ba5a-4cd9721c213a` |
| luna-supabase-write | `a172707a-8f25-4450-a4d3-f34139d19d59` | `aff907f9-e005-4d45-b080-cd3ade25289d` |
| luna-supabase-query | `6ee54dbb-276d-4c22-9a97-5cd78c06f660` | `2853bb56-dfb6-4798-941b-c9af3d8bdfd5` |
| luna-send-email | `94524ea6-8b65-42bf-810c-414cfec7c916` | `aeea5585-3192-4d13-8a83-aa811b0ebb1d` |
| luna-telegram-send | `5e8b15f4-9d69-4393-923e-9300e68bc137` | `208c89c8-5b03-47c0-8dfe-a72001a9bc08` |
| luna-web-scrape | `e57bf5f5-372b-464e-a6aa-85e52c7b39a9` | `fad37112-06f1-4a67-921f-4330fc845575` |
| luna-search-summarize | `5a4f1ca9-3e5d-4bd1-978f-b4775d1e623b` | `57c2479b-55bd-4961-a5aa-49ca5fde1a12` |
| luna-content-scheduler | `bf1eab65-5210-4243-b6ca-13b293152d9d` | `70ae0864-1a25-442c-ba5e-4955f7745635` |
| luna-crm-write | `bc9d810d-8617-4e92-ab98-e4049effebf9` | `fca29d9b-3bad-419a-81d0-8ff08ca7a8e4` |
| luna-file-processor | `32371f7d-7034-40d3-aed1-623c53904a4b` | `0c1be73d-1e67-41e8-8361-54c3c766a97b` |
| luna-pipeline-research | `a4be65c2-9cb9-4318-ab2e-877c280b59e2` | `38d5ea8d-69a6-43b1-93f5-454dfda3b52c` |
| luna-invoice | `f44f0ad0-afaf-4f9c-b7ac-1de6ceed922c` | `276159ee-85fc-46b5-8c04-a2728dffa317` |
| luna-pipeline-saas | `ffcb6b50-26a5-4d29-bcec-af99ce0bf662` | `d9dfc974-a2ab-405f-8db6-a9f625549edf` |
| luna-pipeline-content | `249a22b8-2213-40d0-8558-e86e0cbae861` | `3fe19ca7-593c-4b8d-86ea-18376a978c19` |
| luna-cost-audit | `88f59b0d-d8e5-47f3-92f0-3ddb5490f678` | `6b14afeb-df0f-4453-b8e3-ea7a293c89c2` |
| luna-morning-brief | `16ca9ab5-c84a-4a7b-8674-947bcf8c1723` | `d0d32a66-6bf6-4e41-abbc-ff442900f294` |
| luna-night-shift | `6389dc8c-713e-4e5d-88ff-e4314118648f` | `eddb4211-8255-4406-bf60-e7b045c9b05a` |
| luna-ai-intel | `170a2e65-1272-4368-8463-b73a6bb05c62` | `c78c6f02-a497-4540-a4aa-fadd66fee919` |

## What this means operationally

1. The restore/import work produced structurally valid workflow artifacts.
2. The live n8n instance still has the canonical/original UUID set.
3. None of the live workflows are active yet, so the system is **not live**.
4. The gateway remains unhealthy because of the **port 3456 conflict**.
5. Do not import the regenerated pack again unless you explicitly want a second cloned set.

## Immediate next actions

1. Resolve the port `3456` owner conflict, then restart the gateway.
2. Pick one workflow set as canonical and avoid importing the regenerated duplicate set again.
3. Verify credentials for OpenAI, Telegram, Gmail, Supabase, and any CRM endpoints.
4. Activate workflows only after credential verification and external API smoke tests.
5. Re-export live workflow state after activation so this inventory can be updated from `inactive` to `active`.
