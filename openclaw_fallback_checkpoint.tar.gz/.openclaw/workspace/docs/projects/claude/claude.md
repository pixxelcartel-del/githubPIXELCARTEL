# Luna System — Claude Code Project

## Who you are working for
Himel is the founder of PixC (PixelCartel). You are working inside Luna's workspace on his VPS.

## System layout
- VPS: srv1184131.hstgr.cloud (Ubuntu 24.04, Hostinger KVM2)
- This workspace: /home/himel/.openclaw/workspace/
- Config (all API keys): /home/himel/.openclaw/openclaw.json
- n8n: http://localhost:5678 | API key at env.N8N_API_KEY in openclaw.json
- Supabase live project: env.SUPABASE_URL = https://fkqrdxukeejoomlzqirw.supabase.co
- Qdrant: http://localhost:6333
- Neo4j: bolt://localhost:7687 (user: neo4j, pass: luna-graph-2026)
- Ollama: http://localhost:11434
- Gateway: port 18789

## Agent hierarchy (Phase 1A — canonical)
Luna → Ernest Hemingway (APG/compression) → Sun Tzu (orchestrator)
  → Elon Musk (engineering) [Ada, Dennis, Grace]
  → Mark Zuckerberg (websites/frontend) [Dieter, John, Larry]
  → 'A' Anonymous (security) [Fox, Aegis]

## Agent workspaces
- Luna: ~/.openclaw/workspace/
- Ernest + Sun Tzu: ~/.openclaw/workspace-sun-tzu/
- Elon: ~/.openclaw/workspace-elon/
- Mark: ~/.openclaw/workspace-mark/
- 'A': ~/.openclaw/workspace-a/

## Rules
- Never hardcode secrets. All secrets live in openclaw.json env block, reference as $env.KEY_NAME
- Always verify changes worked before reporting done
- Keep reports factual and concise — they get forwarded to Himel
- If something is broken, fix root cause not symptoms
- Log significant changes to /home/himel/.openclaw/workspace/memory/ with today's date
