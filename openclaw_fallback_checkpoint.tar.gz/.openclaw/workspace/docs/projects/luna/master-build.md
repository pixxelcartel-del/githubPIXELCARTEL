# LUNA_MASTER_BUILD

Last updated: 2026-04-01 18:39 UTC

## What Luna is right now
Luna is running as an OpenClaw-based autonomous AI operating system for Himel.
Primary chat agent: Luna
Primary baseline routing model: anthropic/claude-haiku-4-5
Fallback for stable direct/main chat when needed: openai-codex/gpt-5.4
Background/sub-agent support: anthropic/claude-haiku-4-5
Heartbeat/local utility model: ollama/llama3.2:3b

Canonical hierarchy:
- Luna
- Ernest Hemingway
- Sun Tzu
- Elon Musk
- Mark Zuckerberg
- 'A' Anonymous

Canonical source rule:
- AGENTS.md is the live roster
- Newer Phase docs override stale summaries until reconciled
- Legacy names Atlas/Nova/Cipher/Oracle remain compatibility labels only in old notes/workspaces

## Infrastructure snapshot
Host: srv1184131.hstgr.cloud
OS: Ubuntu 24.04
Public IP: 72.62.69.94
Tailscale IP: 100.80.74.21
Domain: pixelcartel.cloud
Gateway: local mode on port 18789

Core services expected live:
- OpenClaw gateway
- n8n via Docker + Traefik
- Qdrant
- Neo4j
- Ollama

## Memory architecture
Live layers:
- Workspace markdown memory in /home/himel/.openclaw/workspace/memory
- MEMORY.md as curated long-term state
- Mem0 plugin with Qdrant + Neo4j + Ollama embeddings
- Daily WAL log files in memory/YYYY-MM-DD.md

Operational rules already enforced in control files:
- Search memory before answering from prior context
- Write important corrections/decisions to memory quickly
- Keep main Luna session free; dispatch heavy work out
- Never show raw sub-agent output to Himel

## n8n state
Status baseline from latest verified notes:
- 20/20 workflows active
- 12/12 core webhooks live
- Public URL: https://n8n.srv1184131.hstgr.cloud
- Local URL: http://localhost:5678

Critical constraint:
- Full UUID webhook URLs must be used; short paths 404

Known drift still present:
- luna-thought-miner short webhook responds live
- luna-mood-persist short webhook still returns 404 live even though the workflow is active and its webhook node now shows a webhookId in the live export
- luna-autonomous-thought is now verified from live n8n and exported into the workspace snapshot
- The biggest remaining drift is no longer workflow visibility; it is production webhook registration for luna-mood-persist

## Mission Control state
Mission Control exists locally on port 3000 but current MVP is still considered inadequate.
Priority order remains:
1. Tasks page
2. Team
3. Office
4. Remaining pages

Known outstanding items:
- visual polish redeploy/verification
- harden login with a real stored password

## Content engine state
Foundation is live.
Working pieces documented as present:
- trend analysis
- content full pipeline
- voiceover
- scheduler
- performance tracker

Still missing / not fully built:
- image generation pipeline
- video assembly pipeline
- auto-publishing to YouTube/TikTok/Instagram
- thumbnail generation
- A/B testing hooks

## Authentication / account follow-up
Still flagged from rebuild aftermath:
- Luna GitHub PAT needs refresh
- Google OAuth for lunazeeblack@gmail.com needs re-auth
- Gmail-powered email/invoice workflows remain placeholders until OAuth is repaired

## Backup / recovery state
Nightly GitHub backup exists for luna-system-v1.
Auto-recovery rules for n8n webhook restore are documented.
Main lesson preserved from March rebuild:
- off-VPS backups are mandatory

## Highest-priority open work
1. Repair production webhook registration for luna-mood-persist despite the workflow being active and exported
2. Complete keep/archive/delete cleanup pass for dirty project tree
3. Keep qmd indexing and embedding maintenance current
4. Harden Mission Control login and redeploy verified UI polish
5. Replace email/invoice noOp paths once Google OAuth is restored

## What changed today
- Canonical hierarchy drift was corrected in root control files and memory docs
- Personality/proactiveness docs were corrected to reflect real live drift instead of false green status
- Live personality workflows were exported into workspace/incoming/personality-workflows/live-personality-workflows-2026-04-01.json
- This master build file was recreated because it was missing while TASKS.md still expected it to exist

## Current truth summary
The system is broadly operational again after the rebuild, but a few important pieces are still in "documented vs actually verified" territory. The biggest remaining gap is reconciling personality automation workflows in live n8n with the workspace artifacts so the build state is fully trustworthy end to end.
