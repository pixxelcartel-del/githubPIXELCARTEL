# ASSET LIBRARY — Luna's Resource Catalog
Auto-maintained. Updated after every scraping run.

Last harvest: 2026-04-11 UTC

## Categories
### spline-3d
| name | quality | tags | local_path | date |
|------|---------|------|-----------|------|
| Spline Examples Library | GOLD | official, templates, physics, ui, remixable | https://spline.design/examples | 2026-04-11 |
| Spline Community | GOLD | official, community, trending, popular, inspiration | https://community.spline.design/ | 2026-04-11 |
| Spline 3D Websites Solution Page | SILVER | official, website-use-case, production, embed | https://spline.design/solutions/3d-websites | 2026-04-11 |

### dribbble-design
| name | quality | palette | layout | date |
|------|---------|---------|--------|------|
| VM: 3D Website Concept Using Framer & Spline | SILVER | editorial/high-contrast | landing page concept | 2026-04-11 |
| VELVET Landingpage - Spline 3D Concept | SILVER | premium/dark | product landing page | 2026-04-11 |
| 3D Character with Spline - Landing page concept | SILVER | teal/neutral | character-led hero | 2026-04-11 |

### awwwards-interactions
| name | technique | score | source_url | date |
|------|-----------|-------|-----------|------|
| Awwwards 3D Collection | 3D interaction benchmark set | 90 | https://www.awwwards.com/websites/3d/ | 2026-04-11 |
| Awwwards Interactive Collection | interaction patterns benchmark set | 84 | https://www.awwwards.com/websites/interactive/ | 2026-04-11 |
| 3D Websites Design Inspiration: Spline | hero scene framing benchmark | 72 | https://3dwebsites.design/website/spline | 2026-04-11 |

### prompts
| name | type | use_case | content_preview | date |
|------|------|----------|-----------------|------|

### n8n-templates
| name | trigger | workflows | date |
|------|---------|-----------|------|

## Notes
- Official Spline sources were prioritized for remixable assets and web-ready scenes.
- Dribbble entries were kept as visual references only, not implementation truth.
- Awwwards entries were captured as benchmark pools for future QDE scoring and PixC inspiration.

## Usage
Luna auto-indexes new assets here after every scraping run.
Cross-referenced with QDE-TRACKER.md for quality signals.
Available to all agents via memory_search('asset library').
