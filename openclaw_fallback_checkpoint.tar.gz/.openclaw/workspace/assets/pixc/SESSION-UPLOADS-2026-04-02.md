# Session Uploads — 2026-04-02

These assets were provided directly in-session by Himel and should be treated as canonical PixC assets for the current build unless replaced later.

## Canonical assets
- Himel photo: provided in-session on 2026-04-02 11:22 UTC
- PixC logo: provided in-session on 2026-04-02 11:22 UTC

## Usage guidance
- Use the uploaded Himel photo for founder/personal-brand trust sections, about modules, and social proof framing where appropriate.
- Use the uploaded PixC logo as the canonical brand mark for navigation, hero branding, favicon/source prep, and brand card references.

## Note
The raw binary image files came through the active session context rather than SCP. They are available to Luna in-session for analysis and implementation decisions.
