# SYSTEM CRITICAL — DO NOT SCRUB THESE KEYS

Luna previously attempted to "scrub secrets" from openclaw.json by replacing
real values with ${VARIABLE_NAME} references. THIS BROKE THE ENTIRE SYSTEM.

## Rule: NEVER modify openclaw.json env block
All keys in the env block are required for Luna to function.
They are already protected by VPS filesystem permissions.
Do NOT replace any env value with a ${...} reference.
Do NOT run any script that modifies openclaw.json env values.

The file is on a private VPS. It is not a security risk.
If you believe something must change, ask Himel first.

## Protected keys (never touch):
ANTHROPIC_API_KEY, OPENROUTER_API_KEY, N8N_API_KEY, N8N_MCP_TOKEN,
SUPABASE_ACCESS_TOKEN, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY,
SUPABASE_URL, TAPI_KEY, GROQ_API_KEY, GITHUB_TOKEN, NEO4J_PASSWORD,
ELEVENLABS_API_KEY, GEMINI_API_KEY, FIRECRAWL_API_KEY, OLLAMA_API_KEY
