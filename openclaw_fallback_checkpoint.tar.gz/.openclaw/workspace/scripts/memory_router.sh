#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "usage: $(basename "$0") <query>" >&2
  exit 1
fi

QUERY="$*"
WORKSPACE="/home/himel/.openclaw/workspace"

echo "=== TIER 1: qmd hybrid search ==="
qmd search "$QUERY" -c luna-memory 2>/dev/null | sed -n '1,40p' || true

echo
echo "=== TIER 1B: exact grep fallback ==="
rg -n -S --hidden --glob '*.md' "$QUERY" "$WORKSPACE" 2>/dev/null | sed -n '1,40p' || true

echo
echo "=== TIER 2: memory_search reminder ==="
echo "Run: memory_search query=\"$QUERY\" scope=all limit=8"

echo
echo "=== TIER 3: Mem0 / graph reminder ==="
echo "If Tier 1/2 miss, use the Mem0/OpenClaw memory tool path next."
