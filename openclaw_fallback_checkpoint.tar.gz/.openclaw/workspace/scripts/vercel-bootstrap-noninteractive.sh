#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <project_dir> [project_name]" >&2
  exit 1
fi

PROJECT_DIR="$1"
PROJECT_NAME="${2:-}"

if ! command -v vercel >/dev/null 2>&1; then
  echo "vercel CLI not found" >&2
  exit 1
fi

VERCEL_TOKEN_EFFECTIVE="${VERCEL_TOKEN:-${VERCEL_API_TOKEN:-}}"
if [ -z "$VERCEL_TOKEN_EFFECTIVE" ]; then
  echo "VERCEL_TOKEN or VERCEL_API_TOKEN is not set" >&2
  exit 1
fi

cd "$PROJECT_DIR"

if [ ! -d .vercel ]; then
  echo "Linking project non-interactively..."
  if [ -n "$PROJECT_NAME" ]; then
    vercel link --yes --token "$VERCEL_TOKEN_EFFECTIVE" || true
  else
    vercel link --yes --token "$VERCEL_TOKEN_EFFECTIVE" || true
  fi
else
  echo ".vercel already exists; skipping link"
fi

echo "Deploying production build..."
vercel deploy --prod --yes --token "$VERCEL_TOKEN_EFFECTIVE"

echo
if [ -f .vercel/project.json ]; then
  echo "Linked project metadata:"
  cat .vercel/project.json
fi

echo
cat <<'EOF'
Next manual step after bootstrap:
1. Create a Vercel Deploy Hook in project settings for the production branch
2. Store hook URL in memory/pixc/DEPLOYMENT-REGISTRY.md
3. Use n8n/webhook trigger for routine redeploys after that
EOF
