#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: $0 <image_url> <prompt> [std|pro]" >&2
  exit 1
fi

WAVESPEED_API_KEY_EFFECTIVE="${WAVESPEED_API_KEY:-${WAVESPEED_API_TOKEN:-}}"
if [ -z "$WAVESPEED_API_KEY_EFFECTIVE" ]; then
  echo "WAVESPEED_API_KEY or WAVESPEED_API_TOKEN is not set" >&2
  exit 1
fi

IMAGE_URL="$1"
PROMPT="$2"
TIER="${3:-std}"

if [ "$TIER" = "pro" ]; then
  ENDPOINT="https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-pro/image-to-video"
else
  ENDPOINT="https://api.wavespeed.ai/api/v3/kwaivgi/kling-v3.0-std/image-to-video"
fi

curl -fsS -X POST "$ENDPOINT" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${WAVESPEED_API_KEY_EFFECTIVE}" \
  -d "{\"image\":$(printf '%s' "$IMAGE_URL" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),\"prompt\":$(printf '%s' "$PROMPT" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),\"duration\":5,\"cfg_scale\":0.5,\"shot_type\":\"customize\",\"enable_audio\":false}"
