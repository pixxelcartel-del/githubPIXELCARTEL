#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <deploy_hook_url>" >&2
  exit 1
fi

HOOK_URL="$1"
curl -fsS -X POST "$HOOK_URL"
