#!/bin/bash
# Usage: neo4j-query.sh "MATCH (n) RETURN n"
QUERY="${1:-MATCH (n) RETURN labels(n)[0] as label, count(n) as cnt}"
docker exec neo4j cypher-shell -u neo4j -p luna-graph-2026 "$QUERY"
