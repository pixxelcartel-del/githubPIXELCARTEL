import json
import urllib.request
import copy
from pathlib import Path

OPENCLAW = json.load(open('/home/himel/.openclaw/openclaw.json'))
API_KEY = OPENCLAW['env']['N8N_API_KEY']
SUPABASE_URL = OPENCLAW['env']['SUPABASE_URL'].rstrip('/')
SUPABASE_SERVICE_ROLE_KEY = OPENCLAW['env']['SUPABASE_SERVICE_ROLE_KEY']
BASE = 'http://localhost:5678/api/v1'
HEADERS = {'X-N8N-API-KEY': API_KEY, 'Content-Type': 'application/json'}
WORKDIR = Path('/home/himel/.openclaw/workspace')
BACKUP_DIR = WORKDIR / 'incoming' / 'workflow-backups-2026-04-05-content-factory-fix'
BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def api(method, path, data=None):
    body = None if data is None else json.dumps(data).encode()
    req = urllib.request.Request(f'{BASE}{path}', data=body, headers=HEADERS, method=method)
    with urllib.request.urlopen(req) as r:
        raw = r.read()
        return json.loads(raw) if raw else None


def list_workflows():
    return api('GET', '/workflows?limit=100')['data']


def get_workflow_by_name(name):
    for wf in list_workflows():
        if wf['name'] == name:
            return api('GET', f"/workflows/{wf['id']}")
    raise KeyError(name)


def save_backup(wf):
    (BACKUP_DIR / f"{wf['name']}.{wf['id']}.json").write_text(json.dumps(wf, indent=2))


def update_workflow(wf):
    payload = {
        'name': wf['name'],
        'nodes': wf['nodes'],
        'connections': wf['connections'],
        'settings': wf.get('settings') or {},
    }
    return api('PUT', f"/workflows/{wf['id']}", payload)


def reactivate(wf_id):
    try:
        api('POST', f'/workflows/{wf_id}/deactivate', {})
    except Exception:
        pass
    api('POST', f'/workflows/{wf_id}/activate', {})


supabase_headers = [
    {'name': 'apikey', 'value': SUPABASE_SERVICE_ROLE_KEY},
    {'name': 'Authorization', 'value': f'Bearer {SUPABASE_SERVICE_ROLE_KEY}'},
    {'name': 'Prefer', 'value': 'return=representation'},
    {'name': 'Content-Type', 'value': 'application/json'},
]


def webhook_node(node_id, response_mode='responseNode', path=''):
    return {
        'parameters': {'httpMethod': 'POST', 'path': path, 'responseMode': response_mode, 'options': {}},
        'id': node_id,
        'name': 'Webhook',
        'type': 'n8n-nodes-base.webhook',
        'typeVersion': 2,
        'position': [240, 300],
    }


def respond_node(node_id, body_expr):
    return {
        'parameters': {'respondWith': 'json', 'responseBody': body_expr, 'options': {}},
        'id': node_id,
        'name': 'Respond',
        'type': 'n8n-nodes-base.respondToWebhook',
        'typeVersion': 1.4,
        'position': [1080, 300],
    }


def code_node(node_id, name, js, pos):
    return {
        'parameters': {'mode': 'runOnceForAllItems', 'jsCode': js},
        'id': node_id,
        'name': name,
        'type': 'n8n-nodes-base.code',
        'typeVersion': 2,
        'position': pos,
    }


def http_json_node(node_id, name, url, json_body_expr, pos):
    return {
        'parameters': {
            'method': 'POST',
            'url': url,
            'sendHeaders': True,
            'specifyHeaders': 'keypair',
            'headerParameters': {'parameters': copy.deepcopy(supabase_headers)},
            'sendBody': True,
            'contentType': 'json',
            'specifyBody': 'json',
            'jsonBody': json_body_expr,
            'options': {},
        },
        'id': node_id,
        'name': name,
        'type': 'n8n-nodes-base.httpRequest',
        'typeVersion': 4.2,
        'position': pos,
    }


# 1) luna-trend-analysis
wf = get_workflow_by_name('luna-trend-analysis')
save_backup(wf)
wf['nodes'] = [
    webhook_node('trend-webhook', 'responseNode', 'luna-trend-analysis'),
    code_node('trend-build', 'Build Trend Record', r'''
const raw = $input.first().json;
const body = raw.body && Object.keys(raw.body).length ? raw.body : raw;
const topic = body.topic || 'untitled topic';
const platform = body.platform || 'youtube';
const format = body.format || 'short';
const slug = topic.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'topic';
return [{ json: {
  topic,
  angle: `Fast take on ${topic}`,
  platform,
  format,
  trend_score: 78,
  competitor_data: {
    source: 'local-fallback',
    hooks: [`Why ${topic} is popping now`, `3 angles on ${topic}`],
    gaps: ['clear hook', 'tighter CTA', 'faster pacing'],
    dedupe_key: `${platform}:${slug}`
  },
  status: 'trend_analyzed'
}}];
''', [500, 300]),
    http_json_node('trend-save', 'Save Trend Data', f'{SUPABASE_URL}/rest/v1/content_ideas', '={{ $json }}', [760, 300]),
    respond_node('trend-respond', '={{ JSON.stringify({status: "complete", workflow: "luna-trend-analysis", row: $json[0] || $json}) }}'),
]
wf['connections'] = {
    'Webhook': {'main': [[{'node': 'Build Trend Record', 'type': 'main', 'index': 0}]]},
    'Build Trend Record': {'main': [[{'node': 'Save Trend Data', 'type': 'main', 'index': 0}]]},
    'Save Trend Data': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
}
update_workflow(wf)
reactivate(wf['id'])

# 2) luna-content-full-pipeline
wf = get_workflow_by_name('luna-content-full-pipeline')
save_backup(wf)
wf['nodes'] = [
    webhook_node('full-webhook', 'responseNode', 'luna-content-full-pipeline'),
    code_node('full-build', 'Build Script Brief', r'''
const raw = $input.first().json;
const body = raw.body && Object.keys(raw.body).length ? raw.body : raw;
const topic = body.topic || 'untitled topic';
const platform = body.platform || 'youtube';
const format = body.format || 'short';
const audience = body.audience || 'general';
const title = `${topic} — ${platform} ${format}`;
const hook = `Stop scrolling: ${topic} in 30 seconds.`;
const script = [
  hook,
  `Point 1: what changed about ${topic}.`,
  `Point 2: the practical takeaway for ${audience}.`,
  'CTA: follow for the next build.'
].join('\n');
const storyboard = [
  {scene: 1, visual: `Bold title card for ${topic}`, voiceover: hook, duration_s: 3},
  {scene: 2, visual: 'Show the core insight', voiceover: `Here is the signal behind ${topic}.`, duration_s: 7},
  {scene: 3, visual: 'Contrast before vs after', voiceover: 'This is why it matters right now.', duration_s: 7},
  {scene: 4, visual: 'Three bullet summary', voiceover: 'Compress it into three takeaways.', duration_s: 7},
  {scene: 5, visual: 'CTA end card', voiceover: 'Follow for the next breakdown.', duration_s: 6},
];
return [{ json: {
  title,
  hook,
  script,
  storyboard,
  metadata: {
    hashtags: [`#${topic.replace(/[^a-zA-Z0-9]+/g, '') || 'Topic'}`, '#content'],
    thumbnail_concept: `${topic} with high-contrast text`,
    thumbnail_prompt: `Cinematic thumbnail for ${topic}, high contrast, bold typography`,
    publish_time: body.publish_time || new Date(Date.now() + 3600_000).toISOString(),
    platform,
    audience,
    format,
    source: 'local-fallback'
  },
  status: 'brief_ready'
}}];
''', [520, 300]),
    http_json_node('full-save', 'Save to Supabase', f'{SUPABASE_URL}/rest/v1/content_scripts', '={{ $json }}', [790, 300]),
    respond_node('full-respond', '={{ JSON.stringify({status: "complete", workflow: "luna-content-full-pipeline", row: $json[0] || $json}) }}'),
]
wf['connections'] = {
    'Webhook': {'main': [[{'node': 'Build Script Brief', 'type': 'main', 'index': 0}]]},
    'Build Script Brief': {'main': [[{'node': 'Save to Supabase', 'type': 'main', 'index': 0}]]},
    'Save to Supabase': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
}
update_workflow(wf)
reactivate(wf['id'])

# 3) luna-content-scheduler
wf = get_workflow_by_name('luna-content-scheduler')
save_backup(wf)
wf['nodes'] = [
    webhook_node('sched-webhook', 'responseNode', 'luna-content-scheduler'),
    code_node('sched-build', 'Build Published Record', r'''
const raw = $input.first().json;
const body = raw.body && Object.keys(raw.body).length ? raw.body : raw;
const scheduleTime = body.schedule_time || new Date(Date.now() + 3600_000).toISOString();
const scriptId = body.script_id || null;
const platform = body.platform || 'youtube';
return [{ json: {
  script_id: scriptId,
  platform,
  post_url: body.post_url || `scheduled://${platform}/${scriptId || 'pending'}`,
  published_at: scheduleTime,
  performance: {
    status: 'scheduled',
    content: body.content || null,
    requested_schedule_time: scheduleTime,
    media_url: body.media_url || null
  },
  feedback_captured: false
}}];
''', [520, 300]),
    http_json_node('sched-save', 'Save Published Record', f'{SUPABASE_URL}/rest/v1/content_published', '={{ $json }}', [800, 300]),
    respond_node('sched-respond', '={{ JSON.stringify({status: "scheduled", workflow: "luna-content-scheduler", row: $json[0] || $json}) }}'),
]
wf['connections'] = {
    'Webhook': {'main': [[{'node': 'Build Published Record', 'type': 'main', 'index': 0}]]},
    'Build Published Record': {'main': [[{'node': 'Save Published Record', 'type': 'main', 'index': 0}]]},
    'Save Published Record': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
}
update_workflow(wf)
reactivate(wf['id'])

# 4) luna-content-engine
wf = get_workflow_by_name('luna-content-engine')
save_backup(wf)
wf['nodes'] = [
    webhook_node('engine-webhook', 'responseNode', 'luna-content-engine'),
    code_node('engine-route', 'Route Stage', r'''
const raw = $input.first().json;
const body = raw.body && Object.keys(raw.body).length ? raw.body : raw;
return [{ json: {
  stage: body.stage || 'research',
  topic: body.topic || '',
  idea_id: body.idea_id || null,
  script_id: body.script_id || null,
  platform: body.platform || 'youtube',
  format: body.format || 'short',
  published_id: body.published_id || null,
  performance_data: body.performance_data || {},
  timestamp: new Date().toISOString()
}}];
''', [480, 300]),
    {
        'parameters': {
            'rules': {
                'values': [
                    {'conditions': {'options': {'caseSensitive': True, 'leftValue': '', 'typeValidation': 'strict'}, 'conditions': [{'leftValue': '={{ $json.stage }}', 'rightValue': 'research', 'operator': {'type': 'string', 'operation': 'equals'}}], 'combinator': 'and'}, 'renameOutput': True, 'outputKey': 'research'},
                    {'conditions': {'options': {'caseSensitive': True, 'leftValue': '', 'typeValidation': 'strict'}, 'conditions': [{'leftValue': '={{ $json.stage }}', 'rightValue': 'script', 'operator': {'type': 'string', 'operation': 'equals'}}], 'combinator': 'and'}, 'renameOutput': True, 'outputKey': 'script'},
                    {'conditions': {'options': {'caseSensitive': True, 'leftValue': '', 'typeValidation': 'strict'}, 'conditions': [{'leftValue': '={{ $json.stage }}', 'rightValue': 'image', 'operator': {'type': 'string', 'operation': 'equals'}}], 'combinator': 'and'}, 'renameOutput': True, 'outputKey': 'image'},
                    {'conditions': {'options': {'caseSensitive': True, 'leftValue': '', 'typeValidation': 'strict'}, 'conditions': [{'leftValue': '={{ $json.stage }}', 'rightValue': 'performance', 'operator': {'type': 'string', 'operation': 'equals'}}], 'combinator': 'and'}, 'renameOutput': True, 'outputKey': 'performance'},
                ]
            },
            'options': {'fallbackOutput': 'extra'}
        },
        'id': 'engine-switch',
        'name': 'Stage Router',
        'type': 'n8n-nodes-base.switch',
        'typeVersion': 3.2,
        'position': [700, 300],
    },
    code_node('engine-research', 'Build Research Output', r'''
const i = $input.first().json;
return [{ json: {
  topic: i.topic || 'untitled topic',
  angle: `Primary angle for ${i.topic || 'topic'}`,
  platform: i.platform,
  format: i.format,
  trend_score: 72,
  competitor_data: { source: 'engine-local', hooks: ['strong hook', 'contrast', 'clear CTA'] },
  status: 'researched'
}}];
''', [940, 120]),
    http_json_node('engine-save-idea', 'Save Idea', f'{SUPABASE_URL}/rest/v1/content_ideas', '={{ $json }}', [1180, 120]),
    code_node('engine-script', 'Build Script Output', r'''
const i = $input.first().json;
const topic = i.topic || 'untitled topic';
return [{ json: {
  idea_id: i.idea_id,
  title: `${topic} quick script`,
  hook: `Here is the fastest way to understand ${topic}.`,
  script: `Hook: ${topic}\nValue: three useful points\nCTA: follow for more`,
  storyboard: [
    {scene: 1, visual: 'Hook frame', voiceover: `Here is ${topic}`, duration_s: 3},
    {scene: 2, visual: 'Value bullets', voiceover: 'Three useful points.', duration_s: 12},
    {scene: 3, visual: 'CTA', voiceover: 'Follow for more.', duration_s: 5}
  ],
  metadata: { platform: i.platform, format: i.format, source: 'engine-local' },
  status: 'draft'
}}];
''', [940, 300]),
    http_json_node('engine-save-script', 'Save Script', f'{SUPABASE_URL}/rest/v1/content_scripts', '={{ $json }}', [1180, 300]),
    code_node('engine-image', 'Build Image Asset', r'''
const i = $input.first().json;
return [{ json: {
  script_id: i.script_id,
  asset_type: 'image_prompt',
  asset_url: null,
  asset_data: {
    thumbnail_prompt: `High-contrast thumbnail for ${i.topic || 'topic'}`,
    style: 'cinematic',
    mood: 'urgent',
    composition: 'center subject, bold text'
  },
  status: 'prompt_ready'
}}];
''', [940, 480]),
    http_json_node('engine-save-asset', 'Save Image Asset', f'{SUPABASE_URL}/rest/v1/content_assets', '={{ $json }}', [1180, 480]),
    code_node('engine-performance', 'Build Performance Learning', r'''
const i = $input.first().json;
return [{ json: {
  category: 'content_performance',
  key: `content_learning_${Date.now()}`,
  value: JSON.stringify({ published_id: i.published_id, summary: 'Initial performance snapshot recorded', source: 'engine-local' }),
  metadata: { platform: i.platform, performance_data: i.performance_data || {} }
}}];
''', [940, 660]),
    http_json_node('engine-memory', 'Write to Memory', f'{SUPABASE_URL}/rest/v1/luna_memory_vault', '={{ $json }}', [1180, 660]),
    respond_node('engine-respond', '={{ JSON.stringify({status: "complete", workflow: "luna-content-engine", row: $json[0] || $json}) }}'),
]
wf['connections'] = {
    'Webhook': {'main': [[{'node': 'Route Stage', 'type': 'main', 'index': 0}]]},
    'Route Stage': {'main': [[{'node': 'Stage Router', 'type': 'main', 'index': 0}]]},
    'Stage Router': {
        'research': [[{'node': 'Build Research Output', 'type': 'main', 'index': 0}]],
        'script': [[{'node': 'Build Script Output', 'type': 'main', 'index': 0}]],
        'image': [[{'node': 'Build Image Asset', 'type': 'main', 'index': 0}]],
        'performance': [[{'node': 'Build Performance Learning', 'type': 'main', 'index': 0}]],
        'extra': [[{'node': 'Build Research Output', 'type': 'main', 'index': 0}]],
    },
    'Build Research Output': {'main': [[{'node': 'Save Idea', 'type': 'main', 'index': 0}]]},
    'Save Idea': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
    'Build Script Output': {'main': [[{'node': 'Save Script', 'type': 'main', 'index': 0}]]},
    'Save Script': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
    'Build Image Asset': {'main': [[{'node': 'Save Image Asset', 'type': 'main', 'index': 0}]]},
    'Save Image Asset': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
    'Build Performance Learning': {'main': [[{'node': 'Write to Memory', 'type': 'main', 'index': 0}]]},
    'Write to Memory': {'main': [[{'node': 'Respond', 'type': 'main', 'index': 0}]]},
}
update_workflow(wf)
reactivate(wf['id'])

print('Updated workflows:', ', '.join([
    'luna-trend-analysis',
    'luna-content-full-pipeline',
    'luna-content-scheduler',
    'luna-content-engine',
]))
print(f'Backups saved to {BACKUP_DIR}')
