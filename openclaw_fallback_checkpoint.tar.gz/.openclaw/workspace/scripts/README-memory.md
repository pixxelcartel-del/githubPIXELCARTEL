# Memory scripts

## scripts/memory_router.sh
Cheap-first local memory lookup helper.

Usage:
./scripts/memory_router.sh "supabase blocker"

## scripts/memory_maintenance.sh
Refreshes qmd text index and embeddings.

Usage:
./scripts/memory_maintenance.sh
