#!/usr/bin/env bash
set -euo pipefail

CONFIG="/etc/prometheus/prometheus.yml"
BACKUP="/etc/prometheus/prometheus.yml.bak.$(date +%Y%m%d-%H%M%S)"
BLOCK="$(cat <<'EOB'
  - job_name: 'luna'
    scrape_interval: 5s
    scrape_timeout: 5s
    static_configs:
      - targets: ['localhost:9091']
EOB
)"

if ! command -v sudo >/dev/null 2>&1; then
  echo "sudo is required" >&2
  exit 1
fi

if [[ ! -f "$CONFIG" ]]; then
  echo "Prometheus config not found at $CONFIG" >&2
  exit 1
fi

sudo cp "$CONFIG" "$BACKUP"
echo "Backup written to $BACKUP"

if sudo grep -q "job_name: 'luna'" "$CONFIG"; then
  echo "Luna scrape job already exists in $CONFIG"
else
  printf '\n%s\n' "$BLOCK" | sudo tee -a "$CONFIG" >/dev/null
  echo "Appended Luna scrape job to $CONFIG"
fi

if command -v promtool >/dev/null 2>&1; then
  sudo promtool check config "$CONFIG"
else
  echo "promtool not found, skipping config lint"
fi

if command -v systemctl >/dev/null 2>&1; then
  sudo systemctl reload prometheus
  echo "Prometheus reloaded"
else
  echo "systemctl not found, reload Prometheus manually"
fi

if command -v curl >/dev/null 2>&1; then
  echo "Checking exporter health..."
  curl -fsS http://localhost:9091/metrics | head -10 || true
  echo
  echo "Checking Prometheus target status..."
  curl -fsS "http://localhost:9090/api/v1/query?query=up" || true
else
  echo "curl not found, skipping HTTP verification"
fi

echo
echo "Done. If the final query shows job=\"luna\" with value 1, this P0 is closed."
