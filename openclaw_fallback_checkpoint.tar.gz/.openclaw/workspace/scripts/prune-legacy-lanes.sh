#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/himel/.openclaw"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE_DIR="$ROOT/backups/legacy-lanes-$STAMP"
mkdir -p "$ARCHIVE_DIR"

legacy_paths=(
  "$ROOT/agents/atlas"
  "$ROOT/agents/nova"
  "$ROOT/agents/cipher"
  "$ROOT/agents/oracle"
  "$ROOT/workspace-atlas"
  "$ROOT/workspace-nova"
  "$ROOT/workspace-cipher"
  "$ROOT/workspace-oracle"
)

active_refs=$(grep -RniE 'workspace-atlas|workspace-nova|workspace-cipher|workspace-oracle|agents/atlas|agents/nova|agents/cipher|agents/oracle' \
  "$ROOT/openclaw.json" "$ROOT/workspace" "$ROOT/workspace-main" "$ROOT/workspace-sun-tzu" "$ROOT/workspace-elon" "$ROOT/workspace-mark" "$ROOT/workspace-a" "$ROOT/workspace-ernest" 2>/dev/null || true)

if [[ -n "$active_refs" ]]; then
  echo "Refusing to prune. Active references still exist:"
  echo "$active_refs"
  exit 2
fi

for path in "${legacy_paths[@]}"; do
  if [[ -e "$path" ]]; then
    rel="${path#$ROOT/}"
    mkdir -p "$ARCHIVE_DIR/$(dirname "$rel")"
    mv "$path" "$ARCHIVE_DIR/$rel"
    echo "archived $path -> $ARCHIVE_DIR/$rel"
  else
    echo "missing $path"
  fi
done

echo "done. archived legacy lanes into $ARCHIVE_DIR"
