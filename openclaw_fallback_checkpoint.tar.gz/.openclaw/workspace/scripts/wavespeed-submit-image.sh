#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <prompt> [aspect_ratio] [resolution]" >&2
  exit 1
fi

WAVESPEED_API_KEY_EFFECTIVE="${WAVESPEED_API_KEY:-${WAVESPEED_API_TOKEN:-}}"
if [ -z "$WAVESPEED_API_KEY_EFFECTIVE" ]; then
  echo "WAVESPEED_API_KEY or WAVESPEED_API_TOKEN is not set" >&2
  exit 1
fi

PROMPT="$1"
ASPECT_RATIO="${2:-16:9}"
RESOLUTION="${3:-1k}"

curl -fsS -X POST "https://api.wavespeed.ai/api/v3/google/nano-banana-2/text-to-image" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${WAVESPEED_API_KEY_EFFECTIVE}" \
  -d "{\"prompt\":$(printf '%s' "$PROMPT" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),\"resolution\":\"${RESOLUTION}\",\"aspect_ratio\":\"${ASPECT_RATIO}\",\"output_format\":\"png\",\"enable_sync_mode\":false,\"enable_base64_output\":false,\"enable_web_search\":false,\"enable_image_search\":false}"
