#!/usr/bin/env bash
set -euo pipefail

export NLC_GPU=false
export QMD_GPU=false

cd /home/himel/.openclaw/workspace

echo "=== openclaw memory plugin ==="
openclaw status | sed -n '/Memory/,/Plugin compatibility/p'

echo
echo "=== qmd status ==="
qmd status

echo
echo "=== qdrant collections ==="
curl -sf http://localhost:6333/collections

echo
echo "=== neo4j listening ports ==="
ss -ltn | grep ':7474\|:7687' || true

echo
echo "=== recent memory files ==="
ls -lt memory | sed -n '1,20p'
