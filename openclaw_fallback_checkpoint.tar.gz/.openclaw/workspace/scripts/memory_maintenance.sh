#!/usr/bin/env bash
set -euo pipefail

export NLC_GPU=false
export QMD_GPU=false

if [ -d /workspace ]; then
  WORKSPACE_DIR=/workspace
elif [ -d /home/himel/.openclaw/workspace ]; then
  WORKSPACE_DIR=/home/himel/.openclaw/workspace
else
  echo "[memory] workspace not found" >&2
  exit 1
fi

cd "$WORKSPACE_DIR"

echo "[memory] qmd update"
qmd update

echo "[memory] qmd embed"
qmd embed

echo "[memory] done"
