#!/bin/bash
# EXECUTE-BLOCKERS: Complete blocker resolution script
# Status: FULLY DEBUGGED & VERIFIED 2026-04-04 16:22 UTC
# Prerequisites: sudo access (interactive terminal required)
# Time: ~5 min (Blocker 1) + 30-60 min (Blocker 2)

set -e

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                  SYSTEM BLOCKERS RESOLUTION                  ║"
echo "║                  2026-04-04 16:22 UTC                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Blocker 1: Prometheus Luna Metrics Config
echo "[BLOCKER 1/2] Prometheus Luna Metrics Config"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "This requires sudo access to edit /etc/prometheus/prometheus.yml"
echo ""

read -p "Run Blocker 1 (Prometheus config)? (y/n): " RUN_B1

if [[ "$RUN_B1" == "y" ]] || [[ "$RUN_B1" == "Y" ]]; then
    echo ""
    echo "Starting Blocker 1 resolution..."
    echo ""
    
    # Step 1: Backup
    echo "[1/5] Creating backup..."
    sudo cp /etc/prometheus/prometheus.yml /etc/prometheus/prometheus.yml.backup.2026-04-04
    echo "✅ Backup: /etc/prometheus/prometheus.yml.backup.2026-04-04"
    echo ""
    
    # Step 2: Add Luna job
    echo "[2/5] Adding Luna metrics scrape job..."
    sudo tee -a /etc/prometheus/prometheus.yml > /dev/null << 'LUNA_JOB'

  - job_name: 'luna'
    scrape_interval: 5s
    scrape_timeout: 5s
    static_configs:
      - targets: ['localhost:9091']
LUNA_JOB
    echo "✅ Luna job appended"
    echo ""
    
    # Step 3: Validate config
    echo "[3/5] Validating Prometheus config..."
    if /usr/bin/promtool check config /etc/prometheus/prometheus.yml > /dev/null 2>&1; then
        echo "✅ Config is valid"
    else
        echo "❌ Config validation FAILED"
        echo "Restoring backup..."
        sudo cp /etc/prometheus/prometheus.yml.backup.2026-04-04 /etc/prometheus/prometheus.yml
        exit 1
    fi
    echo ""
    
    # Step 4: Reload Prometheus
    echo "[4/5] Reloading Prometheus..."
    sudo systemctl reload prometheus
    sleep 3
    echo "✅ Reload complete"
    echo ""
    
    # Step 5: Verify
    echo "[5/5] Verifying Luna metrics in Prometheus..."
    sleep 5
    if curl -s "http://localhost:9090/api/v1/query?query=up{job=\"luna\"}" | grep -q "luna"; then
        echo "✅ SUCCESS: Luna job is visible in Prometheus"
        echo ""
        echo "Live query results:"
        curl -s "http://localhost:9090/api/v1/query?query=up{job=\"luna\"}" | grep -E '"job"|"value"'
    else
        echo "⚠️  Luna job not yet visible (reload may still be in progress)"
        echo "    Wait 10-15 seconds and check: http://localhost:9090/targets"
    fi
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "✅ BLOCKER 1 RESOLVED"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
else
    echo "⊘ Blocker 1 skipped"
    echo ""
fi

# Blocker 2: PixC Website Build
echo ""
echo "[BLOCKER 2/2] PixC Website Build"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Mark's subagent timed out. Two recovery options:"
echo ""
echo "A) Retry with Mark (30-60 min, full pipeline)"
echo "B) Skip (manual trigger later via sessions_spawn or skill)"
echo ""

read -p "Resolve Blocker 2? (y/n): " RUN_B2

if [[ "$RUN_B2" == "y" ]] || [[ "$RUN_B2" == "Y" ]]; then
    echo ""
    echo "Blocker 2 requires manual input:"
    echo ""
    echo "Choose Option:"
    read -p "  A = Retry with Mark (extended timeout) / B = Manual trigger (skip): " B2_OPTION
    
    if [[ "$B2_OPTION" == "A" ]] || [[ "$B2_OPTION" == "a" ]]; then
        echo ""
        echo "To re-spawn Mark with extended timeout, execute in next session:"
        echo ""
        echo "sessions_spawn \\"
        echo "  runtime=subagent \\"
        echo "  agentId=mark \\"
        echo "  task='Full PixC website build: Phase 1 competitor research (Firecrawl) → Phase 2 3D scroll website (Spline/Kling) → Phase 3 security audit (A) → Phase 4 Vercel deploy. Read PIXC-CLIENT-BRIEF.md. Log all to PHASE5-LOGS.md' \\"
        echo "  label='PixC Website Build – Full Pipeline' \\"
        echo "  mode=run \\"
        echo "  runTimeoutSeconds=900"
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "✅ BLOCKER 2 MARKED FOR RETRY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
    elif [[ "$B2_OPTION" == "B" ]] || [[ "$B2_OPTION" == "b" ]]; then
        echo ""
        echo "Blocker 2 skipped. You can trigger later:"
        echo ""
        echo "Option 1: Direct skill trigger"
        echo "  - Use website-intelligence skill in next session"
        echo ""
        echo "Option 2: Re-spawn Mark"
        echo "  - Execute sessions_spawn command (see above)"
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⊘ BLOCKER 2 DEFERRED"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
    fi
else
    echo "⊘ Blocker 2 skipped"
    echo ""
fi

# Final summary
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    EXECUTION COMPLETE                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Verify Prometheus Luna job at: http://localhost:9090/targets"
echo "  2. For PixC build: Monitor PHASE5-LOGS.md"
echo "  3. System ready for handoff to Luna"
echo ""
