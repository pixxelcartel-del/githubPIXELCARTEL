#!/bin/bash
# BLOCKER 1: Add Luna metrics to Prometheus config
# Status: DEBUGGED & VERIFIED 2026-04-04 16:20 UTC
# Time: ~5 minutes
# Requirements: sudo access (interactive terminal)

set -e

echo "=========================================="
echo "BLOCKER 1: Prometheus Luna Metrics Config"
echo "=========================================="
echo ""

# Step 1: Backup current config
echo "[Step 1/5] Backing up current Prometheus config..."
sudo cp /etc/prometheus/prometheus.yml /etc/prometheus/prometheus.yml.backup.2026-04-04
echo "✅ Backup saved to: /etc/prometheus/prometheus.yml.backup.2026-04-04"
echo ""

# Step 2: Add Luna job to config
echo "[Step 2/5] Adding Luna metrics scrape job..."
sudo tee -a /etc/prometheus/prometheus.yml > /dev/null << 'LUNA_JOB'

  - job_name: 'luna'
    scrape_interval: 5s
    scrape_timeout: 5s
    static_configs:
      - targets: ['localhost:9091']
LUNA_JOB
echo "✅ Luna job appended to prometheus.yml"
echo ""

# Step 3: Validate config syntax
echo "[Step 3/5] Validating Prometheus config syntax..."
/usr/bin/promtool check config /etc/prometheus/prometheus.yml > /dev/null
echo "✅ Config syntax valid"
echo ""

# Step 4: Reload Prometheus
echo "[Step 4/5] Reloading Prometheus daemon..."
sudo systemctl reload prometheus
sleep 3
echo "✅ Prometheus reloaded"
echo ""

# Step 5: Verify Luna job is being scraped
echo "[Step 5/5] Verifying Luna metrics are now scraped..."
RESULT=$(curl -s "http://localhost:9090/api/v1/query?query=up" | grep -o '"job":"luna"' || echo "NOT_FOUND")

if [[ "$RESULT" == *"luna"* ]]; then
    echo "✅ SUCCESS: Luna job is now visible in Prometheus"
    echo ""
    echo "Verification query:"
    curl -s "http://localhost:9090/api/v1/query?query=up" | grep -E '"job"|"value"' | head -10
    echo ""
    echo "=========================================="
    echo "✅ BLOCKER 1 RESOLVED"
    echo "=========================================="
else
    echo "⚠️  WARNING: Luna job not yet visible in Prometheus"
    echo "   This is normal if Prometheus just reloaded."
    echo "   Wait 10-15 seconds and check again:"
    echo "   curl -s 'http://localhost:9090/api/v1/query?query=up{job=\"luna\"}'"
    echo ""
    echo "   Or check Prometheus targets at: http://localhost:9090/targets"
fi
