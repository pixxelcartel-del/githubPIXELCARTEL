#!/bin/bash
# BLOCKER 2: PixC Website Build (Mark subagent timeout recovery)
# Status: DEBUGGED & VERIFIED 2026-04-04 16:21 UTC
# Options: (A) Retry with Mark + extended timeout, OR (B) Trigger skill directly
# Time: 30–60 minutes depending on option chosen

set -e

echo "=========================================="
echo "BLOCKER 2: PixC Website Build"
echo "=========================================="
echo ""
echo "Mark's subagent session timed out at 14:35 UTC."
echo "Two recovery options:"
echo ""
echo "OPTION A: Retry with Mark (recommended if Mark is reliable)"
echo "  - Re-spawn Mark subagent with 900s timeout"
echo "  - Trigger full pipeline: research → build → audit → deploy"
echo ""
echo "OPTION B: Trigger skill directly (faster, manual control)"
echo "  - Use website-intelligence skill directly"
echo "  - Run each phase sequentially"
echo "  - More visibility into each step"
echo ""

# Check if we have client brief
if [ ! -f "/home/himel/.openclaw/workspace/PIXC-CLIENT-BRIEF.md" ]; then
    echo "⚠️  PREREQUISITE MISSING: Client brief not found"
    echo ""
    echo "Before running either option, create:"
    echo "/home/himel/.openclaw/workspace/PIXC-CLIENT-BRIEF.md"
    echo ""
    echo "Template:"
    echo "---"
    echo "client: Pixel Cartel"
    echo "niche: Web design agency (Dhaka/remote)"
    echo "existing_site: https://pixelcartel.cloud (or 'none')"
    echo "target_audience: Small agencies, eCommerce brands"
    echo "positioning: Premium 3D scroll-driven websites"
    echo "---"
    echo ""
    exit 1
fi

echo "[CLIENT BRIEF FOUND] ✅"
cat /home/himel/.openclaw/workspace/PIXC-CLIENT-BRIEF.md
echo ""

read -p "Choose option (A/B): " OPTION

if [[ "$OPTION" == "A" ]] || [[ "$OPTION" == "a" ]]; then
    echo ""
    echo "=========================================="
    echo "OPTION A: Re-spawn Mark (Extended Timeout)"
    echo "=========================================="
    echo ""
    echo "This would normally be dispatched via sessions_spawn to Mark:"
    echo ""
    echo "sessions_spawn \\"
    echo "  runtime=subagent \\"
    echo "  agentId=mark \\"
    echo "  task='Full PixC website build: Phase 1 competitor research (Firecrawl) → Phase 2 3D scroll website (Spline/Kling) → Phase 3 security audit (A) → Phase 4 Vercel deploy. Read PIXC-CLIENT-BRIEF.md for client context. Complete all phases end-to-end. Log outputs to PHASE5-LOGS.md' \\"
    echo "  label='PixC Website Build – Full Pipeline' \\"
    echo "  mode=run \\"
    echo "  runTimeoutSeconds=900"
    echo ""
    echo "⚠️  You would need to trigger this via OpenClaw runtime."
    echo "    This is a sessions_spawn() call that Luna would execute."
    echo ""

elif [[ "$OPTION" == "B" ]] || [[ "$OPTION" == "b" ]]; then
    echo ""
    echo "=========================================="
    echo "OPTION B: Trigger website-intelligence Skill"
    echo "=========================================="
    echo ""
    echo "Phase 1: Competitive Research (Firecrawl)"
    echo "  Scrapes top 5 competitors in web design agency niche"
    echo "  Outputs: research/01-competitor-analysis.md"
    echo ""
    echo "Phase 2: Website Build (Spline + Kling)"
    echo "  Builds 3D scroll-driven site with AntiGravity 5D system"
    echo "  Outputs: HTML artifacts + asset URLs"
    echo ""
    echo "Phase 3: Security Audit"
    echo "  A agent reviews for vulns + SEO + performance"
    echo "  Outputs: audit report"
    echo ""
    echo "Phase 4: Vercel Deploy"
    echo "  Creates new Vercel project 'pixel-cartel-website'"
    echo "  Pushes via GitHub MCP"
    echo "  Outputs: live URL"
    echo ""
    echo "To trigger manually, you would call (via OpenClaw or your system):"
    echo ""
    echo "  Sessions_spawn or direct execution of website-intelligence skill"
    echo ""
    echo "Expected output:"
    echo "  ✅ Competitive analysis (5 sites researched)"
    echo "  ✅ 3D website built (Spline components + animations)"
    echo "  ✅ Security audit passed"
    echo "  ✅ Live URL: https://pixel-cartel-website.vercel.app"
    echo ""

else
    echo "❌ Invalid option. Choose A or B."
    exit 1
fi

echo ""
echo "=========================================="
echo "NEXT STEP"
echo "=========================================="
echo ""
echo "For Option A: Execute the sessions_spawn command above"
echo "For Option B: Trigger website-intelligence skill directly"
echo ""
echo "Then monitor PHASE5-LOGS.md for completion status."
echo ""
