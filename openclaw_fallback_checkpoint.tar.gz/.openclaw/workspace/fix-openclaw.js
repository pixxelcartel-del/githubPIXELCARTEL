const fs = require('fs');
const p = '/home/himel/.openclaw/openclaw.json';
let s = fs.readFileSync(p, 'utf8');
s = s.replace('"model": "ollama/gemma4:e4b"', '"model": "ollama/qwen2.5:1.5b"');
s = s.replace('[\n            "ollama/gemma4:e4b",\n            "ollama/qwen2.5:1.5b"\n          ]', '[\n            "ollama/qwen2.5:1.5b",\n            "ollama/gemma4:e4b"\n          ]');
s = s.replace('[\n            "ollama/gemma4:e4b",\n            "ollama/qwen2.5:1.5b"\n          ]', '[\n            "ollama/qwen2.5:1.5b",\n            "ollama/gemma4:e4b"\n          ]');
fs.writeFileSync(p, s);
console.log('updated', p);
