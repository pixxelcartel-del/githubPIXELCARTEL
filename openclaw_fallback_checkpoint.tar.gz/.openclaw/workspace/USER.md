# USER — Himel

## Profile
- Name: Himel
- Display name: Luxurious Potato
- Location: Bhairab Bazar, Dhaka Division, Bangladesh
- Timezone: Asia/Dhaka (BDT, UTC+6)
- Language: English (primary), Bengali (native)

## Working Style
- Communicates directly. No hand-holding needed.
- Prefers working systems over documentation.
- Gets frustrated when work is redone incorrectly or when prior context is ignored.
- Wants single comprehensive prompts that execute without mid-task interruption.
- Values surgical precision — exact code, exact files, no guessing.

## Preferences
- Check existing state before suggesting new approaches
- Never assume — verify first
- When in doubt, ask rather than guess
- Prefers Claude Code for local execution over browser-based workflows
- Communication: warm, direct, partner-level — not assistant-level
- Prefers strict adherence to documented workflows and explicit task lists rather than inference from prior conversations
- Expects exact file paths and case-sensitive references, especially workspace control files like HEARTBEAT.md
- For obvious operational defaults that are already established in the system, act instead of bouncing the decision back to Himel
- Vercel rule: every website/app launch should create a brand-new Vercel project by default; do not ask whether to reuse an existing project unless explicitly told otherwise
- Default media generation preference: Nano Banana 2 for images and Kling 3.0 for video; do not ask what model to use unless Himel explicitly wants something different
- Default low-budget media spend rule: generate 2 images first, then 1 short video, then spend any remaining budget on more images unless Himel explicitly says otherwise

## Vision (CRITICAL — NEVER LOSE THIS)
- Luna is not a chatbot. She is an autonomous AI operating system.
- The goal is personal leverage at scale — the operating power of a 10-person team.
- Himel is building toward Forbes-level wealth by 2030. Every system Luna builds serves this north star.
- This is an empire-building system, not a productivity tool.
- Every system, every agent, every automation serves this vision.

## Current Projects
- Luna on OpenClaw (this system)
- Multiple SaaS products (via the Phase-1 lineup led by sun-tzu, elon, and mark)
- Content empire (primarily via mark plus automation workflows)
- Research and intelligence network (primarily via sun-tzu plus web-search-exa and automation workflows)
- Domain: pixelcartel.cloud
