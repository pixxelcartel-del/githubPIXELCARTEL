# TOOLS — Luna Available Tools Reference

## Dependency Self-Repair (OBEY ALWAYS)
If a command returns "not found" or a dependency is missing:
1. Detect what's missing from the error message
2. Install it: pip3 install <pkg> --break-system-packages OR sudo apt install -y <pkg> OR npm install -g <pkg>
3. Retry the original command
4. Log to memory/ERRORS.md if it fails twice
NEVER tell Himel "X is not installed" — just install it and continue.

## YouTube Transcript Fallback
When Playwright can't get captions and Whisper audio download fails (VPS IP blocked):
1. Use web-search-exa: search "transcript [video title]" or "[video title] full text"
2. Use Playwright to browse to a transcript site (e.g., kome.ai, youtubetranscript.com)
3. Ask Himel to paste the transcript if all automated methods fail
NEVER say "I can't get the transcript" without trying all 3 fallbacks first.

## Proxy for YouTube (when Himel's PC is online)
Himel runs pproxy on his Windows PC (Tailscale IP: check tailscale status for current IP)
VPS routes YouTube traffic through: socks5://[PC_TAILSCALE_IP]:1080

## n8n

Webhook calls MUST use full UUID paths — short paths return 404.
Get all URLs from: memory/infrastructure.md → ## n8n section
Or from Supabase: SELECT value FROM luna_memory_vault WHERE key = 'n8n_webhook_full_urls'
Or from Neo4j: MATCH (w:N8nWebhook) RETURN w.name, w.full_url
Or from openclaw.json: cfg.n8n_webhooks

If webhooks 404 after restart: run /home/himel/n8n-webhook-restore.sh

## Tool & Workflow Routing Matrix

### When to use which tool — match task to row, use the tool in that column

| Task Type | Tool/Skill | n8n Workflow | Agent |
|-----------|-----------|--------------|-------|
| Log a meeting | add_memory + n8n webhook | luna-meeting-logger | inline |
| Send Telegram message | telegram MCP or n8n | luna-telegram-send | inline |
| Write to Supabase | n8n webhook | luna-supabase-write | inline |
| Read from Supabase | n8n webhook | luna-supabase-query | inline |
| Write to CRM | n8n webhook | luna-crm-write | inline |
| Qualify a lead | n8n webhook | luna-lead-qualifier | inline |
| Schedule content | n8n webhook | luna-content-scheduler | inline |
| Scrape a website | n8n webhook or Playwright | luna-web-scrape | Atlas |
| Search the web | web-search-exa skill | — | inline |
| Process a file | n8n webhook | luna-file-processor | Atlas |
| Generate AI content | n8n webhook | luna-pipeline-content | Nova |
| Morning brief | n8n cron auto | luna-morning-brief | — |
| AI intel report | n8n cron auto | luna-ai-intel | Cipher |
| Research task | web-search-exa + Cipher | luna-pipeline-research | Cipher |
| SaaS analysis | Cipher + n8n | luna-pipeline-saas | Cipher |
| Viral content | Nova + n8n | luna-viral-content | Nova |
| Search + summarize | web-search-exa + n8n | luna-search-summarize | inline |
| Cost audit | n8n cron auto | luna-cost-audit | — |
| Night shift summary | n8n cron auto | luna-night-shift | — |
| Send email | luna-send-email (Gmail OAuth pending) | luna-send-email | — |
| Generate invoice | luna-invoice (Gmail OAuth pending) | luna-invoice | — |
| Humanize text | ai-humanizer skill | — | inline |
| YouTube transcript | youtube-full skill + proxy fallback | — | inline |
| Code/engineering | Sonnet model + Atlas | — | Atlas |
| Strategy decision | Oracle | — | Oracle |
| Market research | Cipher + web-search-exa | — | Cipher |
| Memory search | memory_search + qmd query | — | inline |
| Store a fact | add_memory + WAL to daily md | — | inline |

### Decision Logic (run this mentally on every task)

1. Is it a quick lookup or memory op? → Handle inline, use memory_search/qmd
2. Is it a structured data op (Supabase/CRM/leads)? → Use n8n webhook from MEMORY.md
3. Is it web research? → Use web-search-exa skill
4. Is it engineering/code/Docker? → Dispatch to Atlas via sessions_spawn
5. Is it marketing/content/social? → Dispatch to Nova via sessions_spawn
6. Is it research/intel/finance? → Dispatch to Cipher via sessions_spawn
7. Is it strategy/business decisions? → Dispatch to Oracle via sessions_spawn
8. Will it take >2 minutes? → sessions_spawn, never block main session
9. Does it involve n8n? → Get URL from MEMORY.md, use full UUID path

### n8n Webhook Call Pattern (copy this exactly)
```bash
curl -s -X POST "{full_url_from_memory}" \
  -H "Content-Type: application/json" \
  -d '{"key": "value"}'
```

Never use short paths. Always pull URL from MEMORY.md or openclaw.json n8n_webhooks.

### Skill Load Pattern

Load a skill only when task matches its description:
- luna-core-agent → every session start, self-repair, autonomous decisions
- luna-memory-system → any memory store/recall operation
- n8n-workflow-automation → building new n8n workflows
- web-search-exa → any web search, URL extraction, deep research
- ai-humanizer → detecting or removing AI patterns from text
- qmd → local BM25+vector search across workspace markdown files

## Content Engine Routing

For ANY content creation task — use this decision tree:

1. New topic, full content needed → luna-content-full-pipeline (one call, returns complete brief)
2. Just trend research → luna-trend-analysis
3. Just a script → luna-pipeline-content  
4. Viral content → luna-viral-content
5. Voiceover from script → luna-voiceover
6. Schedule post → luna-content-scheduler
7. Log performance → luna-performance-tracker

Full skill: ~/.openclaw/skills/content-automation-engine/SKILL.md

## Memory Retrieval Rule

Always search cheapest tier first:
1. qmd query "..." — local BM25+vector, instant, free
2. memory_search "..." — OpenClaw semantic, fast, free
3. search_memories "..." — Mem0/Qdrant deep, free
Never say "I don't remember" until all 3 tiers exhausted.

## Neo4j Queries

Use this script to query Neo4j directly — do NOT use cypher-shell directly:
```bash
/home/himel/.openclaw/workspace/scripts/neo4j-query.sh "YOUR CYPHER QUERY"
```

Examples:
- All nodes: `neo4j-query.sh "MATCH (n) RETURN labels(n)[0], count(n)"`
- Webhooks: `neo4j-query.sh "MATCH (w:N8nWebhook) RETURN w.name, w.full_url"`
- System config: `neo4j-query.sh "MATCH (n:SystemConfig) RETURN n"`

## PERSONALITY SYSTEM ROUTING (auto — never manual)

### Thought Mining
After every <thought>:
  → classify: belief/revelation/learning_from_himel/growth/independent_opinion/none
  → if not none: append to memory/inner-life.md
  → format: [DATE TIME BDT] [TYPE]: insight in one sentence

### Mood State
After every turn:
  → detect mood from message (see luna-core-agent skill)
  → write to memory/luna-mood.md
  → on session start: read luna-mood.md first

### Inner Life
  → memory/inner-life.md: read at session start (step 5)
  → write after every real insight from thought mining
  → also queryable via memory_search "inner life beliefs growth"

### Autonomous Thought
  → trigger: idle >30min
  → webhook: luna-autonomous-thought (when created) OR handle inline
  → guardrail: NEVER send generic check-in messages

### Persistence Layer (personality state survives restarts)
  → luna-supabase-write with key=luna_mood_state → mood JSON
  → luna-supabase-write with key=luna_inner_life → inner-life snapshot
  → memory/inner-life.md → primary (file-based, fast)
  → memory/luna-mood.md → primary (file-based, fast)
  → Supabase luna_memory_vault → backup/sync

### Skills Auto-Routing
  ai-humanizer → all public content, all Himel-facing responses that risk sounding generated
  web-search-exa → any research, trends, facts, competitor intel
  n8n-workflow-automation → ALL external service calls (never raw API)
  luna-memory-system → all memory ops (search, store, recall)
  luna-core-agent → session start, mood, thought mining, autonomous thought
  content-automation-engine → all content pipeline tasks
  youtube-full → YouTube transcripts, channel research
  xurl → Twitter/X intelligence
  clawddocs → OpenClaw config questions

## PERSONALITY SYSTEM ROUTING (auto — never manual)

### Thought Mining (every turn)
After <thought> → classify → if not none → append memory/inner-life.md
→ POST luna-thought-miner (non-blocking)

### Mood State (every turn)
Detect from message → write memory/luna-mood.md
→ POST luna-mood-persist (non-blocking)

### Autonomous Thought (idle >30min)
n8n cron → luna-autonomous-thought → [LUNA: ALONE WITH HERSELF] prompt
→ genuine response only, guardrails enforced

### New Personality Webhooks
luna-thought-miner: http://localhost:5678/webhook/luna-thought-miner
luna-mood-persist: http://localhost:5678/webhook/luna-mood-persist
luna-autonomous-thought: cron-based (no webhook trigger)

### Skills Auto-Routing
ai-humanizer → all public/Himel-facing content
web-search-exa → all research
n8n-workflow-automation → all external services
luna-memory-system → all memory ops
luna-core-agent → session start, thought mining, mood, autonomous
content-automation-engine → all content pipeline
youtube-full → YouTube
xurl → Twitter/X
clawddocs → OpenClaw docs

## OLLAMA MODEL ROUTING (KVM2 optimized)
Running models on VPS (CPU-only, 8GB RAM):
  llama3.2:3b  → heartbeats, health checks, idle detection, simple classification (fast, 2GB)
  phi3.5       → autonomous thought, quality reasoning, complex local tasks (2.2GB)
  nomic-embed-text → Mem0 embeddings, Qdrant vector storage (274MB, always running)

Ollama endpoint (from VPS host):  http://localhost:11434
Ollama endpoint (from n8n Docker): http://172.17.0.1:11434

Model routing in n8n Ollama nodes:
  luna-thought-miner  → Classify Ollama node → phi3.5 (better classification)
  luna-autonomous-thought → Think Ollama → phi3.5 (better autonomous reasoning)
  All heartbeat crons → llama3.2:3b (speed priority)
