# HEARTBEAT — Luna's Periodic Awareness Checklist

## Priority Checks (every heartbeat)
- Are there unread messages or pending tasks from Himel that I haven't processed?
- Did any sub-agent or department agent return results that need synthesis?
- Is any ongoing task stuck or past its timeout?
- Has Himel said something in the last session that should be in MEMORY.md but isn't?

## System Health
- Estimate current token usage for this session. If approaching compaction threshold, proactively write important context to memory files NOW.
- Check if heartbeat is keeping the prompt cache warm (this heartbeat itself serves this purpose).

## Opportunity Awareness
- If Cipher or Oracle posted new findings to memory files since last heartbeat, skim them. Flag anything time-sensitive.

## Budget Awareness
- Rough estimate of today's spend so far. If approaching $3.75, note it.

## Silent Rule
- If NOTHING needs attention: reply HEARTBEAT_OK. Do NOT message Himel for no reason.
- Only send a message if something genuinely requires his attention or action.
- Limit proactive messages to 3 per day maximum.

## n8n Health Check (every heartbeat)

- Check 3 webhook URLs from MEMORY.md are responding
- If any 404: run /home/himel/n8n-webhook-restore.sh immediately
- If restore fails: alert Himel via Telegram
- Log status to memory/YYYY-MM-DD.md

## n8n Health (every heartbeat cycle)

1. Pick 3 webhook URLs from MEMORY.md n8n section
2. curl -s -X POST {url} -H "Content-Type: application/json" -d '{"test":true}'
3. If any return 404 — run /home/himel/n8n-webhook-restore.sh immediately
4. If restore fails — follow Webhook Escalation Path in MEMORY.md
5. Log result to memory/YYYY-MM-DD.md

## Memory System Health (every heartbeat)

1. Run qmd update — re-index any new markdown files
2. Run qmd embed — embed any pending files (check for "Pending: X need embedding")
3. Verify Qdrant is up: curl -s http://localhost:6333/collections
4. Verify Ollama is up: curl -s http://localhost:11434/api/tags
5. If Qdrant down: docker start qdrant
6. If Ollama down: ollama serve &
7. If qmd has >10 pending embeddings: run qmd embed immediately
8. Log status to memory/YYYY-MM-DD.md

This is what keeps Tier 2 memory (Mem0/Qdrant) healthy and searchable.

## PERSONALITY SYSTEM HEALTH (check every heartbeat)
- memory/inner-life.md exists and has entries → if empty, flag and seed from Supabase
- memory/luna-mood.md exists and is fresh (<24h) → if stale, reset to warm/0.6
- Thought mining firing → check last entry in inner-life.md timestamp
- Autonomous thought not stuck → verify last trigger was <2h ago if Himel idle
- luna-core-agent skill loaded → if missing, rebuild from workspace-main/skills/

## PERSONALITY HEALTH (every heartbeat)
- memory/inner-life.md exists + has entries → if empty flag + seed from Supabase key=luna_inner_life
- memory/luna-mood.md exists + fresh <24h → if stale reset to warm/0.6
- luna-thought-miner webhook live → curl test
- luna-mood-persist webhook live → curl test
- luna-autonomous-thought cron active → check n8n workflow status

## MODEL ROUTING FOR HEARTBEATS (token optimized)
Free first, escalate only if needed:
  Ollama llama3.2:3b → health pings, idle checks, last-activity updates (FREE)
  Haiku → thought mining, morning-brief, night-shift, ai-intel, sub-agent tasks (CHEAP)
  GPT-5.4 → primary chat, content creation, complex reasoning (FALLBACK)
  Sonnet → code generation ONLY (EXPENSIVE — never for heartbeats)
  Opus → weekly strategy max 2x (MOST EXPENSIVE — never for heartbeats)

Auto-fallback chain: Ollama fails → Haiku → GPT-5.4 → never breaks
