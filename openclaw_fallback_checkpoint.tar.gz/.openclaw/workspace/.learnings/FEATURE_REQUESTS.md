# Feature Requests

> Capabilities requested but not yet built. Track for future implementation.

---
