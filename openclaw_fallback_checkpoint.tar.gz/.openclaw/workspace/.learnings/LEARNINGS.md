## 2026-04-02 — Dispatch layer correction
Problem: workspace control files still pointed Luna at stale legacy agent ids (Atlas/Nova/Cipher/Oracle) even though the live allowed Phase-1 roster is ernest/sun-tzu/elon/mark/a. This caused invalid dispatch attempts and wasted time.

Correction:
- AGENTS.md updated to make Phase-1 roster canonical
- SOUL.md routing updated to forbid stale ids
- MEMORY.md updated with the correction so Himel does not need to restate obvious defaults
- TASKS.md routing guardrail updated

Rule:
When dispatch fails because of invalid agent ids or stale routing assumptions, fix the control files immediately before retrying.

## 2026-04-02 — Act-first codex cleanup rule
Correction from Himel: do not ask for obvious next moves when Codex auth/runtime is the blocker and the system already has enough information to proceed.

Rule:
- fix broken auth/runtime state directly when possible
- restart/reload the gateway yourself when config/auth cleanup requires it
- only surface a blocker after actually attempting the cleanup path
- for code debugging/review, prefer Codex code-review feature tokens when the Codex lane is healthy
- when main-session context is bloated and runtime repair is pending, flush SESSION-STATE.md / daily memory first, then resume the repair protocol automatically

## 2026-04-20 — Act after realization, do not narrate the correction
Problem: after recognizing that cron/infra work should use cheap or local routing first and that validation belonged in the specialist lane, Luna still narrated the realization instead of immediately dispatching elon and repairing the control trail.

Correction:
- after identifying a routing or delegation mistake, act in the same turn
- engineering and cron/runtime validation goes to elon unless it is truly trivial
- do not use GPT-5.4 for heartbeat-style or background repair work unless the cheaper path has actually failed
- write the correction to control files and learning logs before reporting back

Rule:
When Himel points out a routing or delegation failure, stop talking, patch the control trail, dispatch the right agent, and only then report status.
