# Error Log

> Command failures, exceptions, integration issues. Review during heartbeats.

---

## [ERR-20260327-001] integration_issue
### Summary
n8n workflow import failed because the uploaded JSON lacked required workflow ids for the installed import path.
### Details
During restore of the uploaded Luna workflow pack, n8n 2.12.3 import:workflow failed on workflow_entity.id NOT NULL. The workflow pack omitted id fields, and this n8n version did not auto-generate them during CLI import.
### Action
Transform the workflow pack into n8n's expected import structure with generated workflow IDs and version IDs, then retry import. Preserve the safe backup copy of the local n8n SQLite database before mutation.
### Priority: P1


## [ERR-20260327-002] integration_issue
### Summary
qmd repeatedly attempts a Vulkan-enabled node-llama build before falling back to CPU, adding noisy errors to routine memory maintenance.
### Details
Both qmd status and qmd embed succeed, but node-llama-cpp first tries to build with Vulkan support and emits a long CMake failure because Vulkan libraries/glslc are absent on this VPS. Functional impact is low because qmd falls back and completes on CPU, but the maintenance path is noisy and slower than it should be.
### Action
Patched the local qmd node-llama integration to force CPU and build: never on this VPS, then updated memory maintenance/audit scripts to export CPU-only hints too. Re-ran maintenance successfully with the Vulkan build noise gone.
### Priority: P2

---

## SECURITY: luna-system-v1 Dependency Audit (2026-04-03)

**Issue:** GitHub flagged 19 Dependabot vulnerabilities on luna-system-v1 backup repo.

**Investigation:**
- Scanned 14 package.json files across 4 workspaces
- Analyzed 5 lock files with full npm audit
- Result: **5 actual vulnerabilities** in 2 deployed packages, **14 false positives/dev-only**

**Findings:**
1. **Mission Control (Next.js 14.2.30):** 9 GHSA advisories, mostly DoS/resource exhaustion
   - Fix: Update to 14.2.35 (patch, zero risk, non-breaking)
   - Status: MEDIUM risk (admin dashboard, not public-facing)

2. **Mem0 Extension:** 4 advisories (picomatch dev-only, undici transitive)
   - picomatch: ReDoS in vitest (dev tool, not runtime)
   - undici: HTTP smuggling/decompression DoS (requires crafted responses)
   - Status: LOW-MODERATE runtime risk, safe for continued use with testing

3. **N8N MCP Gateway, YouTube Full, AI Humanizer:** All audit-clean

**Action:** Update Next.js this week. No emergency patching needed. See SECURITY_AUDIT_20260403.md for full details.

**Risk Level:** MODERATE (all fixable, no data breach risks)

[2026-04-20 22:26 UTC] memory-index-refresh cron: /home/himel/.openclaw/workspace/scripts/memory_maintenance.sh failed once with exit 2 after qmd embed, reporting 'line 15: syntax error near unexpected token else'. Verified the script contents/syntax were clean (bash -n / nl / cat -vet) and reran under 'bash -x'; second run completed successfully. Fix notes: no file change needed, likely transient shell/exec parse artifact after the long qmd embed run. Recommend monitoring next cron occurrence; if it recurs, capture raw stderr with 'bash -x' in cron wrapper.

[2026-04-23 12:15 UTC] memory-index-refresh cron: could not execute /home/himel/.openclaw/workspace/scripts/memory_maintenance.sh because cron-side exec policy denied the command before launch. Error: 'Cron runs cannot wait for interactive exec approval' under effective host policy security=allowlist ask=on-miss with stricter approvals from ~/.openclaw/exec-approvals.json. Fix notes: add an explicit allowlist entry for 'bash /home/himel/.openclaw/workspace/scripts/memory_maintenance.sh' or relax trusted local automation to security="full" and ask="off" for this cron path, then rerun the maintenance script non-interactively.
